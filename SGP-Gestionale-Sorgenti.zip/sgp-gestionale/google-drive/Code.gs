/** SGP Drive bridge. Run as the owner. The manifest restricts Drive access to files created by this app. */
const SGP_URL = 'https://ogtyuhgmmdajqqkrakhi.supabase.co';
function doPost(e) {
  try {
    const b=JSON.parse(e.postData.contents||'{}');
    if(typeof b.token!=='string'||typeof b.documentId!=='string'||!/^[0-9a-f-]{36}$/i.test(b.documentId))throw Error('Richiesta non valida');
    const publicKey=PropertiesService.getScriptProperties().getProperty('SUPABASE_ANON_KEY');
    if(!publicKey)throw Error('Configurazione incompleta');
    const authHeaders={apikey:publicKey,Authorization:'Bearer '+b.token};
    const auth=UrlFetchApp.fetch(SGP_URL+'/auth/v1/user',{headers:authHeaders,muteHttpExceptions:true});
    if(auth.getResponseCode()!==200)throw Error('Accesso negato');
    const user=JSON.parse(auth.getContentText());
    const profile=sgpFetchJson(SGP_URL+'/rest/v1/profiles?id=eq.'+encodeURIComponent(user.id)+'&select=id,role,active,must_change_password',authHeaders)[0];
    if(!profile||!profile.active||profile.must_change_password)throw Error('Accesso negato');
    const doc=sgpFetchJson(SGP_URL+'/rest/v1/documents?id=eq.'+encodeURIComponent(b.documentId)+'&select=*',authHeaders)[0];
    if(!doc)throw Error('Documento non autorizzato');
    const driveHeaders={Authorization:'Bearer '+ScriptApp.getOAuthToken()};
    if(b.action==='upload'){
      if(doc.teacher_id!==user.id||doc.status!=='uploading'||typeof b.content!=='string'||b.content.length>28000000)throw Error('Caricamento non autorizzato');
      const bytes=Utilities.base64Decode(b.content);if(bytes.length!==doc.size||bytes.length>20971520)throw Error('Dimensione non valida');
      // One owner-side lock prevents a repeated request from creating two files for the same document.
      const lock=LockService.getScriptLock();lock.waitLock(30000);
      try {
        const folder=sgpFolder(driveHeaders);
        const query="trashed=false and '"+folder+"' in parents and appProperties has { key='sgpDocumentId' and value='"+doc.id+"' }";
        const existing=sgpFetchJson('https://www.googleapis.com/drive/v3/files?q='+encodeURIComponent(query)+'&fields=files(id)',driveHeaders).files;
        if(existing.length)return sgpJson({ok:true,fileId:existing[0].id});
        const start=UrlFetchApp.fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=resumable&fields=id',{
          method:'post',contentType:'application/json',headers:driveHeaders,payload:JSON.stringify({name:doc.name,mimeType:doc.mime,parents:[folder],appProperties:{sgpDocumentId:doc.id,sgpTeacherId:user.id}}),muteHttpExceptions:true
        });
        if(start.getResponseCode()!==200)throw Error('Impossibile iniziare il caricamento');
        const loc=start.getHeaders().Location||start.getHeaders().location;
        if(!loc||!String(loc).startsWith('https://www.googleapis.com/'))throw Error('Risposta Drive non valida');
        const uploaded=UrlFetchApp.fetch(loc,{method:'put',contentType:doc.mime,headers:driveHeaders,payload:bytes,muteHttpExceptions:true});
        if(uploaded.getResponseCode()!==200&&uploaded.getResponseCode()!==201)throw Error('Caricamento su Drive non riuscito');
        return sgpJson({ok:true,fileId:JSON.parse(uploaded.getContentText()).id});
      }finally{lock.releaseLock();}
    }
    if(b.action==='download'){
      if(doc.status!=='ready'||!doc.drive_file_id||(doc.teacher_id!==user.id&&profile.role!=='secretary'))throw Error('Accesso negato');
      const file=UrlFetchApp.fetch('https://www.googleapis.com/drive/v3/files/'+encodeURIComponent(doc.drive_file_id)+'?alt=media',{headers:driveHeaders,muteHttpExceptions:true});
      if(file.getResponseCode()!==200)throw Error('File non disponibile su Drive');
      return sgpJson({ok:true,content:Utilities.base64Encode(file.getBlob().getBytes())});
    }
    throw Error('Operazione non valida');
  }catch(err){return sgpJson({ok:false,error:String(err.message||err)});}
}
function sgpFolder(headers){
  const p=PropertiesService.getScriptProperties();let id=p.getProperty('SGP_DRIVE_FOLDER_ID');if(id)return id;
  const r=UrlFetchApp.fetch('https://www.googleapis.com/drive/v3/files?fields=id',{method:'post',contentType:'application/json',headers:headers,payload:JSON.stringify({name:'SGP · Documenti insegnanti',mimeType:'application/vnd.google-apps.folder'}),muteHttpExceptions:true});
  if(r.getResponseCode()!==200)throw Error('Impossibile creare la cartella SGP');id=JSON.parse(r.getContentText()).id;p.setProperty('SGP_DRIVE_FOLDER_ID',id);return id;
}
function sgpFetchJson(url,headers){const r=UrlFetchApp.fetch(url,{headers:headers,muteHttpExceptions:true});if(r.getResponseCode()!==200)throw Error('Verifica autorizzazioni non riuscita');return JSON.parse(r.getContentText());}
function sgpJson(value){return ContentService.createTextOutput(JSON.stringify(value)).setMimeType(ContentService.MimeType.JSON);}
