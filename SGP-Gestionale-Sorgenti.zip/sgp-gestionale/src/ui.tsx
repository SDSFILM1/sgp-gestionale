import { createContext, useContext, useEffect, useRef, type ReactNode, type FormEvent } from 'react';
import { X, CalendarDays, Plus } from 'lucide-react';
export function Modal({title,children,onClose}:{title:string;children:ReactNode;onClose:()=>void}) {
 const ref=useRef<HTMLDialogElement>(null);
 const notice=useContext(NoticeContext);
 useEffect(()=>{ref.current?.showModal();return()=>ref.current?.close();},[]);
 return <dialog ref={ref} onCancel={onClose} className="modal"><header><h2>{title}</h2><button type="button" className="icon-btn" onClick={onClose} aria-label="Chiudi"><X size={22}/></button></header>{notice&&<p className="notice" role={notice.error?'alert':'status'}>{notice.text}</p>}{children}</dialog>;
}
export const NoticeContext=createContext<{text:string;error:boolean}|null>(null);
export function Empty({title,children,action}:{title:string;children:ReactNode;action?:()=>void}){return <div className="empty"><CalendarDays size={36}/><h3>{title}</h3><p>{children}</p>{action&&<button className="primary" onClick={action}><Plus size={18}/>Aggiungi</button>}</div>;}
export function Field({label,children}:{label:string;children:ReactNode}){return <label className="field"><span>{label}</span>{children}</label>;}
export function Form({children,onSubmit,busy}:{children:ReactNode;onSubmit:(f:FormData)=>void;busy:boolean}){return <form onSubmit={(e:FormEvent<HTMLFormElement>)=>{e.preventDefault();if(!busy)onSubmit(new FormData(e.currentTarget));}}>{children}<footer><button className="primary" disabled={busy}>{busy?'Salvataggio…':'Salva'}</button></footer></form>;}
export const str=(f:FormData,k:string)=>String(f.get(k)||'');
export const checked=(f:FormData,k:string)=>f.getAll(k).map(String);
export function csvDownload(name:string,rows:unknown[][]){
 const csv=rows.map(row=>row.map(v=>{let s=String(v??'');if(/^[=+\-@\t\r]/.test(s))s="'"+s;return '"'+s.replaceAll('"','""')+'"';}).join(';')).join('\r\n');
 const url=URL.createObjectURL(new Blob(['\ufeff'+csv],{type:'text/csv;charset=utf-8'}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
