export type Profile = { id:string; name:string; email:string; role:'secretary'|'teacher'; active:boolean; must_change_password:boolean };
export type Course = { id:string; name:string; audience:string; location:string; color:string; wix_service_id:string|null; archived:boolean };
export type CourseTeacher = { course_id:string; teacher_id:string };
export type Student = { id:string; name:string; birth_date?:string|null; notes:string; archived:boolean; wix_managed?:boolean; enrollment_state?:'enrolled'|'trial' };
export type StudentPackage = {student_id:string;total:number;valid_from:string;booked:number;attended:number;remaining:number;linked:boolean};
export type Enrollment = { id:string; course_id:string; student_id:string; valid_from:string; valid_to:string|null };
export type Lesson = { id:string; course_id:string; starts_at:string; ends_at:string; location:string; notes:string; cancelled:boolean };
export type Assignment = { lesson_id:string; teacher_id:string; status:'pending'|'present'|'absent'; note:string };
export type Participant = { id:string; lesson_id:string; student_id:string|null; name:string; source:'fixed'|'manual'|'wix'; status:'unmarked'|'present'|'absent'|'excused'; excluded:boolean; wix_booking_id:string|null; is_trial?:boolean;package_booking?:boolean };
export type Booking = { id:string; course_id:string|null; lesson_id:string|null; name:string; starts_at:string|null; ends_at:string|null; status:string; participants:number; service_name:string; wix_person_id?:string|null; source_present?:boolean };
export type DocumentRow = { id:string; teacher_id:string; name:string; notes:string; size:number; mime:string; created_at:string; drive_file_id:string|null; status:string };
export type Notice = { id:string; recipient_id:string; title:string; body:string; read_at:string|null; created_at:string };
export type SyncState = { id:string; last_success:string|null; last_error:string|null };
export type StaffNote = {id:string;student_id:string;author_id:string;author_name:string;body:string;created_at:string};
export type WixPerson = {id:string;name:string;last_booking_at:string|null;next_booking_at:string|null;subscription_ends_at:string|null;hide_at?:string|null;hide_reason?:'subscription'|'inactivity'|null};
export type WixStaffNote = {id:string;wix_person_id:string;author_id:string;author_name:string;body:string;created_at:string};
export type TrialCourseCount = {student_id:string;course_id:string;lessons:number};
export type WixPackage = {id:string;wix_person_id:string;name:string|null;status:string;ends_at:string|null;total:number|null;remaining:number|null;reserved:number|null;updated_at:string|null};
export type Dataset = { wixPackages?:WixPackage[]; studentPackages?:StudentPackage[];wixLinks?:{student_id:string;wix_person_id:string}[]; profiles:Profile[]; courses:Course[]; courseTeachers:CourseTeacher[]; students:Student[]; enrollments:Enrollment[]; lessons:Lesson[]; assignments:Assignment[]; participants:Participant[]; bookings:Booking[]; documents:DocumentRow[]; notices:Notice[]; sync:SyncState[]; trialCounts:{student_id:string;lessons:number}[]; staffNotes:StaffNote[]; trialCourseCounts:TrialCourseCount[]; rollCallEditors?:RollCallEditor[];extraSubstitutes?:ExtraSubstitute[];wixPeople?:WixPerson[]; wixNotes?:WixStaffNote[] };


export type RollCallEditor={lesson_id:string;actor_id:string;author_name:string;first_saved_at:string;last_saved_at:string};
export type ExtraSubstitute={lesson_id:string;teacher_id:string;teacher_name:string;joined_at:string;active:boolean};

