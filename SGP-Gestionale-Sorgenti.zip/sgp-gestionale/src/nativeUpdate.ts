import {Capacitor,registerPlugin,type PluginListenerHandle} from '@capacitor/core';
export type UpdatePhase='idle'|'permission'|'downloading'|'verifying'|'installing'|'confirmation'|'confirming'|'success'|'error';
export type InstallState={phase:UpdatePhase;progress:number;message:string;version:string;canInstall:boolean};
export type AppUpdate={version:string;apk:string;sha256?:string};
export interface UpdateInstaller{
 getStatus():Promise<InstallState>;
 start(options:{url:string;version:string;sha256:string}):Promise<InstallState>;
 openSettings():Promise<void>;
 addListener(event:'progress',listener:(state:InstallState)=>void):Promise<PluginListenerHandle>;
}
const plugin=registerPlugin<UpdateInstaller>('SgpUpdater');
export const nativeInstaller=()=>Capacitor.getPlatform()==='android'&&Capacitor.isPluginAvailable('SgpUpdater')?plugin:null;
export const idleInstallState:InstallState={phase:'idle',progress:0,message:'',version:'',canInstall:false};
export function parseAppUpdate(raw:unknown):AppUpdate|null{
 if(!raw||typeof raw!=='object')return null;
 const value=raw as Record<string,unknown>;
 if(typeof value.version!=='string'||!/^\d+(\.\d+){1,3}$/.test(value.version)||typeof value.apk!=='string')return null;
 try{
  const url=new URL(value.apk,'https://sdsfilm1.github.io/sgp-gestionale/');
  if(url.origin!=='https://sdsfilm1.github.io'||!/^\/sgp-gestionale\/SGP-Gestionale-Android-\d+(\.\d+){1,3}\.apk$/.test(url.pathname)||url.search||url.hash||url.username||url.password)return null;
  if(value.sha256!==undefined&&(typeof value.sha256!=='string'||!/^[a-fA-F0-9]{64}$/.test(value.sha256)))return null;
  return {version:value.version,apk:url.href,sha256:typeof value.sha256==='string'?value.sha256:undefined};
 }catch{return null}
}
export function isNewerVersion(candidate:string,installed:string){
 const left=candidate.split('.').map(Number),right=installed.split('.').map(Number);
 for(let i=0;i<Math.max(left.length,right.length);i++)if((left[i]||0)!==(right[i]||0))return(left[i]||0)>(right[i]||0);
 return false;
}
