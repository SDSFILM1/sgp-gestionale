type SlotTime={ends_at:string;cancelled:boolean};
const romeDay=(date:Date)=>new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Rome',year:'numeric',month:'2-digit',day:'2-digit'}).format(date);
export function canRegisterSubstitute(slot:SlotTime,now=new Date()):boolean{
 const end=new Date(slot.ends_at);
 return !slot.cancelled&&Number.isFinite(end.getTime())&&(end.getTime()>now.getTime()||romeDay(end)===romeDay(now));
}
