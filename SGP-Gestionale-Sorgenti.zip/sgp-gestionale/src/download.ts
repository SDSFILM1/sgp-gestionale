import {Capacitor} from '@capacitor/core';
import {Filesystem,Directory} from '@capacitor/filesystem';
import {Share} from '@capacitor/share';
export async function saveFile(name:string,mime:string,content:string){
 if(Capacitor.isNativePlatform()){
  const path='sgp/'+Date.now()+'-'+name.replace(/[^a-zA-Z0-9._-]/g,'_');
  const {uri}=await Filesystem.writeFile({path,data:content,directory:Directory.Cache,recursive:true});
  try{await Share.share({title:name,url:uri,dialogTitle:'Salva o apri il documento'});}finally{setTimeout(()=>{void Filesystem.deleteFile({path,directory:Directory.Cache}).catch(()=>{});},300000);}
  return;
 }
 const bytes=Uint8Array.from(atob(content),c=>c.charCodeAt(0));const url=URL.createObjectURL(new Blob([bytes],{type:mime}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),60000);
}
