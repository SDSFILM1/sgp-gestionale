import {useEffect,useMemo,useRef,useState} from 'react';
import {Cake,PartyPopper} from 'lucide-react';
import {Modal} from './ui';
import type {Student,Course,Enrollment} from './types';
import {birthdayDay,birthdaysToday,birthdayCourses} from './birthdays';
import './birthdays.css';

// Uses the existing secretary snapshot: no extra requests or birth dates shared with teachers.
export function BirthdayNotice({students,courses,enrollments,accountId}:{students:Student[];courses:Course[];enrollments:Enrollment[];accountId:string}){
 const [day,setDay]=useState(birthdayDay),[open,setOpen]=useState(false);
 const shown=useRef('');
 const people=useMemo(()=>birthdaysToday(students,day),[students,day]);
 const storageKey='sgp-birthday-seen:'+accountId;
 useEffect(()=>{const tick=()=>setDay(birthdayDay());const timer=setInterval(tick,60000);window.addEventListener('focus',tick);return()=>{clearInterval(timer);window.removeEventListener('focus',tick)}},[]);
 useEffect(()=>{
  setOpen(false);
  if(!people.length||shown.current===day)return;
  try{if(localStorage.getItem(storageKey)===day){shown.current=day;return}}catch{/* Still works when storage is unavailable. */}
  // Let login, updates and new-registration dialogs finish before showing another popup.
  const timer=setInterval(()=>{if(shown.current!==day&&!document.querySelector('dialog[open]')){shown.current=day;setOpen(true);clearInterval(timer)}},700);
  return()=>clearInterval(timer);
 },[day,people.length,storageKey]);
 const close=()=>{setOpen(false);try{localStorage.setItem(storageKey,day)}catch{}};
 if(!people.length)return null;
 return <>
  <section className="birthday-reminder" aria-label="Compleanni di oggi"><Cake size={24} aria-hidden="true"/><div><strong>{people.length===1?'Oggi c’è un compleanno!':`Oggi ci sono ${people.length} compleanni!`}</strong><small>{people.map(p=>p.name).join(', ')}</small></div><button type="button" onClick={()=>setOpen(true)}>Vedi auguri</button></section>
  {open&&<Modal title="Buon compleanno!" onClose={close}><div className="birthday-celebration"><span className="birthday-cake" aria-hidden="true"><Cake size={46}/><PartyPopper size={25}/></span><p className="birthday-date">{new Date(day+'T12:00:00Z').toLocaleDateString('it-IT',{day:'numeric',month:'long',timeZone:'Europe/Rome'})}</p><h3>Oggi festeggiamo</h3><ul>{people.map(p=>{const names=birthdayCourses(p.id,courses,enrollments,day);return <li key={p.id}>{p.name}<small>{names.length?names.join(' · '):'Nessun corso fisso attivo'}</small>{p.enrollment_state==='trial'&&<small>In prova</small>}</li>})}</ul><p className="hint">Un piccolo promemoria per fare gli auguri ai nostri atleti.</p><button type="button" className="primary wide" onClick={close}>Ho visto, grazie!</button></div></Modal>}
 </>;
}
