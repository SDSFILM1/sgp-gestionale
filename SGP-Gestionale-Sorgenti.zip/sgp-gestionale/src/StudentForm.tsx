import {useState} from 'react';
import type {Dataset,Student} from './types';
import {localDate} from './api';
import {Field,str} from './ui';

export function StudentForm({data,student,trial,onSave}:{data:Dataset;student?:Student;trial:boolean;onSave:(args:Record<string,unknown>)=>Promise<boolean>}){
 const [saving,setSaving]=useState(false);
 const [viaWix,setViaWix]=useState(false);
 const [wixId,setWixId]=useState('');
 const today=localDate(); const hasPackage=data.studentPackages?.some(p=>p.student_id===student?.id);
 const memberships=data.enrollments.filter(e=>e.student_id===student?.id&&(trial||e.valid_from<=today)&&(!e.valid_to||e.valid_to>today)&&(!e.valid_to||e.valid_to>e.valid_from)).sort((a,b)=>a.valid_from.localeCompare(b.valid_from));
 const [selected,setSelected]=useState(()=>Array.from(new Set(memberships.map(e=>e.course_id))));
 const [starts,setStarts]=useState<Record<string,string>>(()=>Object.fromEntries([...new Set(memberships.map(e=>e.course_id))].map(id=>[id,memberships.find(e=>e.course_id===id)!.valid_from])));
 if(viaWix)return <form onSubmit={async e=>{e.preventDefault();if(saving||!wixId)return;setSaving(true);try{await onSave({p_wix:wixId})}finally{setSaving(false)}}}>
  <label className="check"><input type="checkbox" checked onChange={()=>setViaWix(false)}/>Tramite Wix</label>
  <p className="notice">Scegli l’atleta già presente su Wix: abbonamento e residuo si aggiornano automaticamente. Compare negli appelli solo quando prenota. Non viene creata una nuova scheda nel gestionale.</p>
  <Field label="Atleta Wix"><select required value={wixId} onChange={e=>setWixId(e.target.value)}><option value="">Seleziona l’atleta</option>{(data.wixPeople||[]).map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select></Field>
  {!(data.wixPeople||[]).length&&<p>Non ci sono abbonati Wix disponibili. Aggiorna i dati dopo l’acquisto su Wix.</p>}
  <button className="primary" disabled={saving||!wixId}>Salva tramite Wix</button>
 </form>;
 return <form onSubmit={async e=>{e.preventDefault();if(saving)return;const f=new FormData(e.currentTarget);setSaving(true);try{await onSave({p_id:student?.id||null,p_name:str(f,'name'),p_notes:str(f,'notes'),p_birth:student?.birth_date||str(f,'birth')||null,p_trial:trial,p_courses:hasPackage?[]:selected,p_starts:trial&&!hasPackage?Object.fromEntries(selected.map(id=>[id,str(f,'start-'+id)])):{}});}finally{setSaving(false);}}}>
  <label className="check"><input type="checkbox" checked={false} onChange={()=>setViaWix(true)}/>Tramite Wix</label>
  <Field label="Nome e cognome"><input name="name" required maxLength={200} defaultValue={student?.name}/></Field>
  {!student&&<Field label="Data di nascita (facoltativa)"><input name="birth" type="date" min="1900-01-01" max={today}/></Field>}
  {hasPackage&&<p className="notice">Atleta con pacchetto: compare solo nelle lezioni prenotate su Wix. Gestisci totale e collegamento dalla scheda atleta.</p>}<fieldset disabled={saving||hasPackage}><legend>{trial?'Corsi in prova':'Corsi di iscrizione fissa'}</legend>
   <p className="hint">{trial?'Per ogni corso selezionato indica la data della prima lezione. L’atleta comparirà negli appelli solo da quella data.':'Puoi scegliere più corsi.'} Potrai modificare la scelta in seguito con «Modifica e corsi».</p>
   <div className="check-list">{data.courses.filter(c=>!c.archived).sort((a,b)=>a.name.localeCompare(b.name,'it')).map(c=><div key={c.id}><label><input type="checkbox" name="courses" value={c.id} checked={selected.includes(c.id)} onChange={e=>setSelected(ids=>e.target.checked?[...ids,c.id]:ids.filter(id=>id!==c.id))}/>{c.name}</label>{trial&&selected.includes(c.id)&&<div className="trial-course-start" style={{padding:'0 8px 16px'}}><Field label={'Prima lezione · '+c.name}><input type="date" name={'start-'+c.id} required min={memberships.find(e=>e.course_id===c.id)?.valid_from&&memberships.find(e=>e.course_id===c.id)!.valid_from<today?memberships.find(e=>e.course_id===c.id)!.valid_from:today} value={starts[c.id]||''} onChange={e=>setStarts(values=>({...values,[c.id]:e.target.value}))}/></Field></div>}</div>)}</div>
   {!data.courses.some(c=>!c.archived)&&<p>Nessun corso disponibile.</p>}
  </fieldset>
  <p className="notice">{trial?'Ogni corso in prova parte dalla sua data di prima lezione, anche negli appelli creati successivamente. I corsi già programmati restano selezionati quando riapri la scheda. L’atleta resta in prova e il conteggio delle prove è conservato.':'I corsi selezionati valgono da oggi per tutte le lezioni successive, anche quelle create in futuro. Eventuali cambi di corso già programmati saranno sostituiti.'} Deseleziona un corso per interromperlo da oggi. Le presenze già registrate e le lezioni passate restano conservate.</p>
  <Field label="Note riservate alla segreteria"><textarea name="notes" defaultValue={student?.notes}/></Field>
  <footer><button className="primary" disabled={saving}>{saving?'Salvataggio…':'Salva alunno e corsi'}</button></footer>
 </form>;
}
