import {useEffect,useRef,useState} from 'react';
import {createPortal} from 'react-dom';
import {ArrowDownToLine,ShieldCheck,X} from 'lucide-react';
import {Capacitor} from '@capacitor/core';
import {App} from '@capacitor/app';
import {nativeInstaller,idleInstallState,parseAppUpdate,isNewerVersion,type AppUpdate,type UpdateInstaller,type InstallState} from './nativeUpdate';
import './update-dialog.css';

export function UpdateDialog({update,onLater,installer=nativeInstaller()}:{update:AppUpdate;onLater:()=>void;installer?:UpdateInstaller|null}){
 const ref=useRef<HTMLDialogElement>(null);
 const [state,setState]=useState<InstallState>(idleInstallState),[starting,setStarting]=useState(false);
 const startingRef=useRef(false);
 const processing=['downloading','verifying','installing','confirmation','confirming'].includes(state.phase);
 const downloading=starting||state.phase==='downloading'||state.phase==='verifying';
 const close=()=>{if(!downloading)onLater()};
 useEffect(()=>{const dialog=ref.current!;dialog.showModal();const previous=document.body.style.overflow;document.body.style.overflow='hidden';return()=>{dialog.close();document.body.style.overflow=previous}},[]);
 useEffect(()=>{
  if(!installer)return;let active=true,listener:{remove:()=>Promise<void>}|undefined;
  const receive=(next:InstallState)=>{if(active&&next.version===update.version)setState(next)};
  const read=()=>installer.getStatus().then(receive).catch(()=>{});
  void installer.addListener('progress',receive).then(handle=>{if(active)listener=handle;else void handle.remove()}).catch(()=>{});
  void read();const timer=setInterval(()=>void read(),1500);
  return()=>{active=false;clearInterval(timer);void listener?.remove()};
 },[installer,update.version]);
 const start=async()=>{
  if(!installer||startingRef.current||processing)return;
  startingRef.current=true;setStarting(true);
  try{
   if(state.phase==='permission'&&!state.canInstall){await installer.openSettings();return}
   if(!update.sha256)throw Error('L’aggiornamento non ha ancora la verifica del file. Riprova tra poco.');
   await installer.start({url:update.apk,sha256:update.sha256,version:update.version});
   setState(await installer.getStatus());
  }catch(error){setState({phase:'error',progress:0,version:update.version,canInstall:state.canInstall,message:error instanceof Error?error.message:'Aggiornamento non riuscito. Premi Riprova.'})}
  finally{startingRef.current=false;setStarting(false)}
 };
 const label=starting?'Preparazione…':processing?state.phase==='downloading'?`Scaricamento ${state.progress}%…`:state.phase==='verifying'?'Verifica del file…':'Installazione…':state.phase==='permission'?state.canInstall?'Continua aggiornamento':'Autorizza aggiornamenti':state.phase==='error'?'Riprova aggiornamento':state.phase==='success'?'Aggiornato':'Aggiorna';
 return createPortal(<dialog ref={ref} className="sgp-update-dialog" aria-labelledby="sgp-update-title" aria-describedby="sgp-update-description" onCancel={e=>{e.preventDefault();close()}}>
  <div className="sgp-update-hero"><div className="sgp-update-brand"><img src="./icon-192.png" alt=""/><span><strong>SGP</strong><small>Il tuo gestionale</small></span></div><button className="sgp-update-close" onClick={close} disabled={downloading} aria-label="Ricordamelo più tardi"><X size={22}/></button><div className="sgp-update-symbol"><ArrowDownToLine size={40}/></div><span className="sgp-update-version">NUOVA VERSIONE · {update.version}</span></div>
  <div className="sgp-update-body"><h2 id="sgp-update-title">È pronto un<br/>aggiornamento</h2><p id="sgp-update-description">{installer?'Premi Aggiorna: al download e all’installazione pensa SGP.':'Porta sul telefono le ultime novità di SGP.'}</p><div className="sgp-update-safe"><ShieldCheck size={25}/><span><strong>Aggiorna l’app che hai già.</strong><small>{installer?'File e firma SGP verificati prima di installare.':'I tuoi dati restano disponibili.'}</small></span></div>
   {installer?<><button className="sgp-update-download" onClick={()=>void start()} disabled={starting||processing||state.phase==='success'}><ArrowDownToLine size={21}/>{label}</button>{(processing||state.phase==='success')&&<progress className="sgp-update-progress" value={state.progress} max={100} aria-label="Avanzamento aggiornamento"/>}{state.message&&<p className={'sgp-install-state '+(state.phase==='error'?'error':'')} role={state.phase==='error'?'alert':'status'}>{state.message}</p>}<p className="sgp-update-help">{state.phase==='permission'?'Solo la prima volta: abilita «Consenti da questa fonte» per SGP, poi torna qui e premi Continua aggiornamento.':'Sui telefoni compatibili basta questo pulsante. Se Android richiede una conferma, comparirà direttamente. L’app potrebbe chiudersi durante l’installazione: riaprila al termine.'}</p></>:<><a className="sgp-update-download" href={update.apk} target="_blank" rel="noopener" download><ArrowDownToLine size={21}/>Scarica aggiornamento</a><p className="sgp-update-help">Apri questo file per introdurre gli aggiornamenti dall’app.<br/>Non serve disinstallare SGP.</p></>}
   <button className="sgp-update-later" onClick={close} disabled={downloading}>{processing?'Torna al gestionale':state.phase==='success'?'Chiudi':'Più tardi'}</button><div className="sgp-update-foot">Hai un appello aperto? Salvalo prima di aggiornare.</div></div>
 </dialog>,document.body)
}
export function UpdateNotice(){
 const[update,setUpdate]=useState<AppUpdate|null>(null);const dismissed=useRef('');
 useEffect(()=>{if(!Capacitor.isNativePlatform())return;let active=true;
  const check=async()=>{try{const info=await App.getInfo();const response=await fetch('https://sdsfilm1.github.io/sgp-gestionale/version.json',{cache:'no-store',credentials:'omit'});if(!response.ok)return;const v=parseAppUpdate(await response.json());if(v&&active&&isNewerVersion(v.version,info.version)&&dismissed.current!==v.version)setUpdate(v)}catch{}};
  void check();const timer=setInterval(check,300000);return()=>{active=false;clearInterval(timer)};
 },[]);
 return update?<UpdateDialog update={update} onLater={()=>{dismissed.current=update.version;setUpdate(null)}}/>:null
}
