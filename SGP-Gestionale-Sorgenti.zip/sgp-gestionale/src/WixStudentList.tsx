import {useState} from 'react';
import {Search} from 'lucide-react';
import type {Booking,Dataset,WixPerson} from './types';
import {dateLabel,time,localDate} from './api';
import {Field,Modal} from './ui';
import {wixBookingsForPerson,wixPeopleExpiring} from './wixPeople';

const bookingDate=(value:string|null)=>value?dateLabel(value)+' · '+time(value):'Data non disponibile';
const courseName=(b:Booking,data:Dataset)=>data.courses.find(c=>c.id===b.course_id)?.name||b.service_name||'Corso Wix';
const confirmedBookings=(personId:string,data:Dataset)=>wixBookingsForPerson(personId,data.bookings).filter(b=>b.source_present!==false&&b.status.toUpperCase()==='CONFIRMED');
const notesFor=(id:string,data:Dataset)=>{
 const students=new Set(data.wixLinks?.filter(k=>k.wix_person_id===id).map(k=>k.student_id));
 const notes=[...(data.wixNotes||[]).filter(n=>n.wix_person_id===id),...(data.staffNotes||[]).filter(n=>students.has(n.student_id))];
 return notes.filter((n,i)=>notes.findIndex(x=>x.id===n.id)===i).sort((a,b)=>b.created_at.localeCompare(a.created_at));
};
function WixPackages({id,data}:{id:string;data:Dataset}){
 const packages=(data.wixPackages||[]).filter(p=>p.wix_person_id===id&&(p.status==='ACTIVE'||p.status==='PAUSED'||!p.ends_at||Date.parse(p.ends_at)+3*86400000>Date.now()));
 return <>{packages.map(p=><p className="notice" key={p.id}><strong>{p.name||'Abbonamento Wix'}</strong><br/>{p.remaining===null?'Residuo non disponibile':`Lezioni residue: ${p.remaining}${p.total===null?'':` su ${p.total}`}`}{!!p.reserved&&<> · Riservate: {p.reserved}</>}{p.ends_at&&<small className="block">Scadenza: {dateLabel(p.ends_at)}</small>}</p>)}{data.sync.find(s=>s.id==='wix-balances')?.last_error&&<small>Saldo non aggiornato: {data.sync.find(s=>s.id==='wix-balances')?.last_error}</small>}</>;
}

export function WixStudentList({data,busy,admin=false,onOpen}:{data:Dataset;busy:boolean;admin?:boolean;onOpen:(id:string)=>void}){
 const [search,setSearch]=useState('');
 const needle=search.trim().toLocaleLowerCase('it');
 const expiring=new Set(wixPeopleExpiring(data.wixPeople||[]).map(p=>p.id));
 const rows=(data.wixPeople||[]).filter(p=>(p.name+' '+wixBookingsForPerson(p.id,data.bookings).map(b=>courseName(b,data)).join(' ')).toLocaleLowerCase('it').includes(needle)).sort((a,b)=>a.name.localeCompare(b.name,'it'));
 return <section aria-labelledby="wix-students-title">
  <div className="section-heading"><h2 id="wix-students-title">Da Wix <span className="count-pill">{(data.wixPeople||[]).length}</span></h2></div>
  <p className="hint">Gli abbonati Wix compaiono qui anche prima di prenotare. Negli appelli compaiono solo nelle lezioni prenotate. Dopo 3 giorni dalla fine dell’abbonamento escono dall’elenco; lo storico è conservato.</p>
  {admin&&data.sync.find(s=>s.id==='wix-plans')?.last_error&&<p className="notice" role="alert">Scadenze abbonamenti non aggiornate. {data.sync.find(s=>s.id==='wix-plans')?.last_error}</p>}
  <div className="search-box"><Search size={20}/><input aria-label="Cerca alunno da Wix" placeholder="Cerca nome o corso Wix…" value={search} onChange={e=>setSearch(e.target.value)}/></div>
  <div className="panel student-list"><div className="table-wrap"><table><thead><tr><th>Alunno</th><th>Corsi prenotati</th><th>Prenotazioni</th><th>Azioni</th></tr></thead><tbody>{rows.map(p=><tr key={p.id}>
   <td><button className="name-link" onClick={()=>onOpen(p.id)}>{p.name}</button><small>Da Wix</small>{expiring.has(p.id)&&p.hide_at&&<p className="notice">Esce dall’elenco il {dateLabel(p.hide_at)}: {'abbonamento terminato da 3 giorni'}.</p>}{(data.wixNotes||[]).filter(n=>n.wix_person_id===p.id).slice(0,1).map(n=><p className="hint" key={n.id}>Note staff: {n.body}</p>)}</td>
   <td data-label="Corsi prenotati">{Array.from(new Set(confirmedBookings(p.id,data).map(b=>courseName(b,data)))).join(', ')||'Nessuna prenotazione confermata'}<WixPackages id={p.id} data={data}/></td>
   <td data-label="Prenotazioni"><div><small className="block">Ultima prenotazione: {bookingDate(p.last_booking_at)}</small><small className="block">Prossima lezione: {p.next_booking_at?bookingDate(p.next_booking_at):'Nessuna prenotata'}</small></div></td>
   <td data-label="Azioni"><div className="student-actions"><button disabled={busy} onClick={()=>onOpen(p.id)}>Scheda e note</button></div></td>
  </tr>)}</tbody></table></div>{!rows.length&&<p className="empty">{search?'Nessun alunno Wix trovato.':'Nessun alunno Wix attivo nei corsi che puoi vedere.'}</p>}</div>
 </section>;
}

export function WixToFixedForm({person,data,busy,onCancel,onSave}:{person:WixPerson;data:Dataset;busy:boolean;onCancel:()=>void;onSave:(courses:string[],student:string|null)=>Promise<boolean>}){
 const linked=data.wixLinks?.find(k=>k.wix_person_id===person.id)?.student_id;
 const [student,setStudent]=useState(linked||'');
 const today=localDate();
 const [courses,setCourses]=useState(()=>Array.from(new Set(data.enrollments.filter(e=>e.student_id===linked&&e.valid_from<=today&&(!e.valid_to||e.valid_to>today)).map(e=>e.course_id))));
 const [saving,setSaving]=useState(false);
 return <form onSubmit={async e=>{e.preventDefault();if(busy||saving||!courses.length)return;setSaving(true);try{await onSave(courses,student||null)}finally{setSaving(false)}}}>
  <h3>Passa a iscritto fisso</h3>
  <p className="notice">Da oggi l’atleta sarà nell’elenco degli iscritti fissi e negli appelli dei corsi scelti. Il collegamento attivo con Wix sarà rimosso; note e presenze passate resteranno conservate. L’abbonamento su Wix non viene modificato.</p>
  {linked?<p>Scheda già associata: <strong>{data.students.find(s=>s.id===linked)?.name||person.name}</strong></p>:<Field label="Scheda già esistente (facoltativa)"><select value={student} disabled={busy||saving} onChange={e=>setStudent(e.target.value)}><option value="">Crea una nuova scheda per {person.name}</option>{data.students.filter(s=>!s.archived&&!s.wix_managed).sort((a,b)=>a.name.localeCompare(b.name,'it')).map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</select></Field>}
  <fieldset disabled={busy||saving}><legend>Corsi di iscrizione fissa</legend><div className="check-list">{data.courses.filter(c=>!c.archived).sort((a,b)=>a.name.localeCompare(b.name,'it')).map(c=><label key={c.id}><input type="checkbox" checked={courses.includes(c.id)} onChange={e=>setCourses(ids=>e.target.checked?[...ids,c.id]:ids.filter(id=>id!==c.id))}/>{c.name}</label>)}</div></fieldset>
  <p className="hint">Seleziona almeno un corso. Le prossime sincronizzazioni non riaggiungeranno questo atleta alla sezione Wix.</p>
  <footer className="actions"><button type="button" disabled={busy||saving} onClick={onCancel}>Annulla</button><button className="primary" disabled={busy||saving||!courses.length}>{saving?'Salvataggio…':'Conferma passaggio a fisso'}</button></footer>
 </form>;
}

export function WixStudentDetails({person,data,busy,onClose,onOpenLesson,onAddNote,onConvert}:{person:WixPerson;data:Dataset;busy:boolean;onClose:()=>void;onOpenLesson:(id:string)=>void;onAddNote:(body:string)=>Promise<boolean>;onConvert?:(courses:string[],student:string|null)=>Promise<boolean>}){
 const [converting,setConverting]=useState(false);
 const bookings=wixBookingsForPerson(person.id,data.bookings).sort((a,b)=>(b.starts_at||'').localeCompare(a.starts_at||''));
 if(converting&&onConvert)return <Modal title={person.name} onClose={onClose}><WixToFixedForm person={person} data={data} busy={busy} onCancel={()=>setConverting(false)} onSave={onConvert}/></Modal>;
 return <Modal title={person.name} onClose={onClose}>
  <p className="notice">Alunno da Wix · Prenotazioni e abbonamenti si aggiornano da Wix.</p>
  {onConvert&&<button disabled={busy} onClick={()=>setConverting(true)}>Passa a iscritto fisso</button>}
  <WixPackages id={person.id} data={data}/>
  {person.subscription_ends_at&&<p>Fine abbonamento: {dateLabel(person.subscription_ends_at)}</p>}
  <h3>Note condivise con lo staff</h3><p className="hint">Visibili solo a segreteria e insegnanti autorizzati.</p>
  {notesFor(person.id,data).map(n=><p className="notice staff-note" key={n.id}>{n.body}<small> · {n.author_name} · {dateLabel(n.created_at)}</small></p>)}
  <form onSubmit={async e=>{e.preventDefault();if(busy)return;const form=e.currentTarget;const body=String(new FormData(form).get('body')||'').trim();if(body&&await onAddNote(body))form.reset();}}>
   <Field label="Nuova nota staff"><textarea name="body" required maxLength={2000}/></Field><button className="primary" disabled={busy}>Aggiungi nota</button>
  </form>
  <h3>Storico delle prenotazioni</h3><div className="student-history">{bookings.map(b=>{
   const lesson=b.lesson_id?data.lessons.find(l=>l.id===b.lesson_id):undefined;
   return <button key={b.id} disabled={!lesson} onClick={()=>lesson&&onOpenLesson(lesson.id)}><div><strong>{courseName(b,data)}</strong><small>{bookingDate(b.starts_at)}</small></div><span className="tag">{b.status}</span></button>;
  })}</div>{!bookings.length&&<p className="hint">Nessuna prenotazione disponibile.</p>}
 </Modal>;
}

