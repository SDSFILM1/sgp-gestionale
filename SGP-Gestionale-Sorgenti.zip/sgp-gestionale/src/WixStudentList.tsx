import {useState} from 'react';
import {Search} from 'lucide-react';
import type {Booking,Dataset,WixPerson} from './types';
import {dateLabel,time} from './api';
import {Field,Modal} from './ui';
import {wixBookingsForPerson,wixPeopleExpiring} from './wixPeople';

const bookingDate=(value:string|null)=>value?dateLabel(value)+' · '+time(value):'Data non disponibile';
const courseName=(b:Booking,data:Dataset)=>data.courses.find(c=>c.id===b.course_id)?.name||b.service_name||'Corso Wix';
const confirmedBookings=(personId:string,data:Dataset)=>wixBookingsForPerson(personId,data.bookings).filter(b=>b.source_present!==false&&b.status.toUpperCase()==='CONFIRMED');
const notesFor=(id:string,data:Dataset)=>{
 const students=new Set(data.wixLinks?.filter(k=>k.wix_person_id===id).map(k=>k.student_id));
 const notes=[...(data.wixNotes||[]).filter(n=>n.wix_person_id===id),...(data.staffNotes||[]).filter(n=>students.has(n.student_id))];
 return notes.filter((n,i)=>notes.findIndex(x=>x.id===n.id)===i).sort((a,b)=>b.created_at.localeCompare(a.created_at));
};
function WixPackages({id,data}:{id:string;data:Dataset}){
 const packages=(data.wixPackages||[]).filter(p=>p.wix_person_id===id&&(p.status==='ACTIVE'||p.status==='PAUSED'||!p.ends_at||Date.parse(p.ends_at)+3*86400000>Date.now()));
 return <>{packages.map(p=><p className="notice" key={p.id}><strong>{p.name||'Abbonamento Wix'}</strong><br/>{p.remaining===null?'Residuo non disponibile':`Lezioni residue: ${p.remaining}${p.total===null?'':` su ${p.total}`}`}{!!p.reserved&&<> · Riservate: {p.reserved}</>}{p.ends_at&&<small className="block">Scadenza: {dateLabel(p.ends_at)}</small>}</p>)}{data.sync.find(s=>s.id==='wix-balances')?.last_error&&<small>Saldo non aggiornato: {data.sync.find(s=>s.id==='wix-balances')?.last_error}</small>}</>;
}

export function WixStudentList({data,busy,admin=false,onOpen}:{data:Dataset;busy:boolean;admin?:boolean;onOpen:(id:string)=>void}){
 const [search,setSearch]=useState('');
 const needle=search.trim().toLocaleLowerCase('it');
 const expiring=new Set(wixPeopleExpiring(data.wixPeople||[]).map(p=>p.id));
 const rows=(data.wixPeople||[]).filter(p=>(p.name+' '+wixBookingsForPerson(p.id,data.bookings).map(b=>courseName(b,data)).join(' ')).toLocaleLowerCase('it').includes(needle)).sort((a,b)=>a.name.localeCompare(b.name,'it'));
 return <section aria-labelledby="wix-students-title">
  <div className="section-heading"><h2 id="wix-students-title">Da Wix <span className="count-pill">{(data.wixPeople||[]).length}</span></h2></div>
  <p className="hint">Gli abbonati Wix compaiono qui anche prima di prenotare. Negli appelli compaiono solo nelle lezioni prenotate. Dopo 3 giorni dalla fine dell’abbonamento escono dall’elenco; lo storico è conservato.</p>
  {admin&&data.sync.find(s=>s.id==='wix-plans')?.last_error&&<p className="notice" role="alert">Scadenze abbonamenti non aggiornate. {data.sync.find(s=>s.id==='wix-plans')?.last_error}</p>}
  <div className="search-box"><Search size={20}/><input aria-label="Cerca alunno da Wix" placeholder="Cerca nome o corso Wix…" value={search} onChange={e=>setSearch(e.target.value)}/></div>
  <div className="panel student-list"><div className="table-wrap"><table><thead><tr><th>Alunno</th><th>Corsi prenotati</th><th>Prenotazioni</th><th>Azioni</th></tr></thead><tbody>{rows.map(p=><tr key={p.id}>
   <td><button className="name-link" onClick={()=>onOpen(p.id)}>{p.name}</button><small>Da Wix</small>{expiring.has(p.id)&&p.hide_at&&<p className="notice">Esce dall’elenco il {dateLabel(p.hide_at)}: {'abbonamento terminato da 3 giorni'}.</p>}{(data.wixNotes||[]).filter(n=>n.wix_person_id===p.id).slice(0,1).map(n=><p className="hint" key={n.id}>Note staff: {n.body}</p>)}</td>
   <td data-label="Corsi prenotati">{Array.from(new Set(confirmedBookings(p.id,data).map(b=>courseName(b,data)))).join(', ')||'Nessuna prenotazione confermata'}<WixPackages id={p.id} data={data}/></td>
   <td data-label="Prenotazioni"><div><small className="block">Ultima prenotazione: {bookingDate(p.last_booking_at)}</small><small className="block">Prossima lezione: {p.next_booking_at?bookingDate(p.next_booking_at):'Nessuna prenotata'}</small></div></td>
   <td data-label="Azioni"><div className="student-actions"><button disabled={busy} onClick={()=>onOpen(p.id)}>Scheda e note</button></div></td>
  </tr>)}</tbody></table></div>{!rows.length&&<p className="empty">{search?'Nessun alunno Wix trovato.':'Nessun alunno Wix attivo nei corsi che puoi vedere.'}</p>}</div>
 </section>;
}

export function WixStudentDetails({person,data,busy,onClose,onOpenLesson,onAddNote}:{person:WixPerson;data:Dataset;busy:boolean;onClose:()=>void;onOpenLesson:(id:string)=>void;onAddNote:(body:string)=>Promise<boolean>}){
 const bookings=wixBookingsForPerson(person.id,data.bookings).sort((a,b)=>(b.starts_at||'').localeCompare(a.starts_at||''));
 return <Modal title={person.name} onClose={onClose}>
  <p className="notice">Alunno da Wix · Prenotazioni e abbonamenti si aggiornano da Wix.</p>
  <WixPackages id={person.id} data={data}/>
  {person.subscription_ends_at&&<p>Fine abbonamento: {dateLabel(person.subscription_ends_at)}</p>}
  <h3>Note condivise con lo staff</h3><p className="hint">Visibili solo a segreteria e insegnanti autorizzati.</p>
  {notesFor(person.id,data).map(n=><p className="notice staff-note" key={n.id}>{n.body}<small> · {n.author_name} · {dateLabel(n.created_at)}</small></p>)}
  <form onSubmit={async e=>{e.preventDefault();if(busy)return;const form=e.currentTarget;const body=String(new FormData(form).get('body')||'').trim();if(body&&await onAddNote(body))form.reset();}}>
   <Field label="Nuova nota staff"><textarea name="body" required maxLength={2000}/></Field><button className="primary" disabled={busy}>Aggiungi nota</button>
  </form>
  <h3>Storico delle prenotazioni</h3><div className="student-history">{bookings.map(b=>{
   const lesson=b.lesson_id?data.lessons.find(l=>l.id===b.lesson_id):undefined;
   return <button key={b.id} disabled={!lesson} onClick={()=>lesson&&onOpenLesson(lesson.id)}><div><strong>{courseName(b,data)}</strong><small>{bookingDate(b.starts_at)}</small></div><span className="tag">{b.status}</span></button>;
  })}</div>{!bookings.length&&<p className="hint">Nessuna prenotazione disponibile.</p>}
 </Modal>;
}

