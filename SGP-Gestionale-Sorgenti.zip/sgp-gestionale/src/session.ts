import {Capacitor} from '@capacitor/core';
import {SecureStorage} from '@aparajita/capacitor-secure-storage';
import {BiometricAuth} from '@aparajita/capacitor-biometric-auth';
export const nativeApp=Capacitor.isNativePlatform();
export const rememberSession=()=>localStorage.getItem('sgp-remember')!=='false';
export const biometricEnabled=()=>nativeApp&&localStorage.getItem('sgp-biometric')==='true';
let releaseGate:()=>void=()=>{};
const gate=biometricEnabled()?new Promise<void>(resolve=>{releaseGate=resolve;}):Promise.resolve();
export const unlockStorage=()=>releaseGate();
const keys=new Set<string>();
export const sessionStorageAdapter={
 async getItem(key:string):Promise<string|null>{
  keys.add(key);await gate;
  if(!rememberSession())return sessionStorage.getItem(key);
  if(!nativeApp)return localStorage.getItem(key);
  const value=await SecureStorage.get(key);
  if(typeof value==='string')return value;
  // Migrate the session from APK 1.0 to Android's encrypted storage once.
  const legacy=localStorage.getItem(key);
  if(legacy){await SecureStorage.set(key,legacy);localStorage.removeItem(key);}
  return legacy;
 },
 async setItem(key:string,value:string){
  keys.add(key);
  if(!rememberSession()){sessionStorage.setItem(key,value);localStorage.removeItem(key);if(nativeApp)await SecureStorage.remove(key);return;}
  if(nativeApp){await SecureStorage.set(key,value);localStorage.removeItem(key);}else localStorage.setItem(key,value);
  sessionStorage.removeItem(key);
 },
 async removeItem(key:string){localStorage.removeItem(key);sessionStorage.removeItem(key);if(nativeApp)await SecureStorage.remove(key);}
};
export async function setRememberSession(value:boolean){
 const existing=await Promise.all([...keys].map(async key=>[key,await sessionStorageAdapter.getItem(key)] as const));
 localStorage.setItem('sgp-remember',String(value));
 if(!value)setBiometricEnabled(false);
 for(const [key,data] of existing)if(data)await sessionStorageAdapter.setItem(key,data);
}
export function setBiometricEnabled(value:boolean){localStorage.setItem('sgp-biometric',String(value));window.dispatchEvent(new Event('sgp-security-change'));}
export async function authenticateDevice(){await BiometricAuth.authenticate({reason:'Accedi al gestionale SGP',androidTitle:'SGP · Accesso protetto',androidSubtitle:'Usa l’impronta o il riconoscimento del telefono',allowDeviceCredential:true});}
export async function forgetSavedSession(){
 // Discard only this project's session. The user must then enter their password.
 const key='sb-ogtyuhgmmdajqqkrakhi-auth-token';
 await sessionStorageAdapter.removeItem(key);setBiometricEnabled(false);unlockStorage();
}
