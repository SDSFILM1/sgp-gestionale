import {useState} from 'react';
import {Check, X, Save, UserRound, UserMinus} from 'lucide-react';
import type {Participant} from './types';
type Mark='present'|'absent'|'excused';
export function AttendanceGrid({rows,cancelled,busy,onSave,onExclude}:{rows:Participant[];cancelled:boolean;busy:boolean;onSave:(rows:{id:string;expected:string;status:Mark}[])=>Promise<boolean>;onExclude?:(p:Participant)=>void}) {
 const [draft,setDraft]=useState<Record<string,{status:Mark;expected:string}>>({});
 const [saved,setSaved]=useState(false);
 const status=(p:Participant):Mark=>draft[p.id]?.status||(p.status==='unmarked'?'present':p.status);
 const changed=rows.some(p=>p.status==='unmarked'||(draft[p.id]&&draft[p.id].status!==p.status));
 const choose=(p:Participant,s:Mark)=>{setSaved(false);setDraft(d=>({...d,[p.id]:{status:s,expected:d[p.id]?.expected||p.status}}));};
 const present=rows.filter(p=>status(p)==='present').length;
 return <section className="roll-call" aria-label="Appello della lezione">
  <div className="roll-call-summary"><div><Check size={20}/><strong>{present}</strong> presenti</div><div><X size={20}/><strong>{rows.length-present}</strong> assenti</div></div>
  <p className="hint">I nomi da segnare partono da «Presente». Tocca la crocetta di chi manca, poi salva. Le presenze già registrate restano come sono.</p>
  <div className="roll-call-head"><span>Nome e cognome</span><span>Presente</span><span>Assente</span>{onExclude&&<span/>}</div>
  {[...rows].sort((a,b)=>a.name.localeCompare(b.name,'it')).map(p=><div className={'roll-call-row '+status(p)} key={p.id}>
   <div className="roll-call-person"><span className="person-symbol" aria-hidden="true"><UserRound size={18}/></span><div><strong>{p.name}</strong><small>{p.source==='fixed'?'Iscritto fisso':p.source==='wix'?'Prenotazione Wix':'Solo questa lezione'}{status(p)==='excused'?' · Giustificato':''}</small></div></div>
   <button type="button" className="mark-box yes" aria-label={p.name+': presente'} aria-pressed={status(p)==='present'} disabled={busy||cancelled} onClick={()=>choose(p,'present')}><Check size={23}/></button>
   <button type="button" className="mark-box no" aria-label={p.name+': assente'} aria-pressed={status(p)!=='present'} disabled={busy||cancelled} onClick={()=>choose(p,'absent')}><X size={23}/></button>
   {onExclude&&<button className="icon-btn exclude-student" aria-label={'Escludi '+p.name+' solo da questa lezione'} disabled={busy||cancelled||!p.student_id} onClick={()=>onExclude(p)}><UserMinus size={17}/></button>}
  </div>)}
  {!rows.length?<p className="notice">Nessun alunno. La segreteria può aggiungere gli iscritti in Corsi → Gestisci iscritti, oppure solo a questa lezione.</p>:<div className="roll-call-save"><span role="status">{saved?'Appello salvato':changed?'Presenze da salvare':'Appello già registrato'}</span><button className="primary" disabled={busy||cancelled||!changed} onClick={async()=>{const edits=rows.filter(p=>p.status==='unmarked'||draft[p.id]).map(p=>({id:p.id,expected:draft[p.id]?.expected||p.status,status:status(p)}));if(await onSave(edits)){setDraft({});setSaved(true);}}}><Save size={18}/>{busy?'Salvataggio…':'Salva appello'}</button></div>}
 </section>;
}
