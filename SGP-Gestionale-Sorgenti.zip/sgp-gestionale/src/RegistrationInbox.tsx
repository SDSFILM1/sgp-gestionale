import {useEffect,useRef,useState} from 'react';
import {Bell,UserPlus} from 'lucide-react';
import {Modal,Field} from './ui';
import {supabase,check,rpc,localDate,errorText} from './api';
import type {Course,Student} from './types';
import {ExcelImport} from './ExcelImport';
type Registration={id:string;first_name:string;last_name:string;birth_date:string;requested_course:string;student_id:string|null;needs_identity_review:boolean;received_at:string};
const birth=(s:string)=>s.split('-').reverse().join('/');
export function RegistrationInbox({courses,students,onSaved}:{courses:Course[];students:Student[];onSaved:()=>Promise<void>}){
 const [rows,setRows]=useState<Registration[]>([]),[open,setOpen]=useState(false),[excel,setExcel]=useState(false),[error,setError]=useState('');
 const shown=useRef(false);
 async function load(){
  if(!supabase)return;
  try{const result:Registration[]=[];let offset=0;
   while(true){const batch=check(await supabase.from('jotform_registrations').select('*').is('resolved_at',null).order('received_at').order('id').range(offset,offset+999));result.push(...batch);if(batch.length<1000)break;offset+=1000;}
   setRows(result);setError('');if(result.length&&!shown.current){shown.current=true;setOpen(true);}
  }catch(e){setError(errorText(e));}
 }
 useEffect(()=>{void load();const timer=setInterval(()=>void load(),60000);const focus=()=>{shown.current=false;void load();};window.addEventListener('focus',focus);return()=>{clearInterval(timer);window.removeEventListener('focus',focus);};},[]);
 if(error&&!rows.length)return <p className="notice" role="alert">Nuove iscrizioni: {error} <button onClick={()=>void load()}>Riprova</button></p>;
 if(!rows.length)return <>{excel&&<ExcelImport courses={courses} students={students} onSaved={onSaved} onClose={()=>setExcel(false)}/>}<button className="primary" onClick={()=>setExcel(true)}>Importa iscritti da Excel</button></>;
 return <><section className="notice registration-reminder" role="status"><Bell size={22}/><strong>{rows.length} iscrizioni da sistemare</strong><button className="primary" onClick={()=>setOpen(true)}>Associa ai corsi</button></section>
 {open&&<Modal title="Nuovi iscritti da assegnare" onClose={()=>setOpen(false)}><p>Controlla il corso richiesto e conferma l’assegnazione. Se chiudi, il promemoria rimane finché hai completato l’elenco.</p>{error&&<p role="alert" className="notice">{error}</p>}{rows.map(r=><RegistrationCard key={r.id} row={r} courses={courses} students={students} onSaved={async()=>{await onSaved();await load();}}/>)}</Modal>}</>;
}
export function RegistrationCard({row:r,courses,students,onSaved}:{row:Registration;courses:Course[];students:Student[];onSaved:()=>Promise<void>}){
 const [busy,setBusy]=useState(false),[error,setError]=useState(''),[isOpen,setIsOpen]=useState(false);
 const [identity,setIdentity]=useState('');
 const [isPackage,setIsPackage]=useState(false);
 return <article className="registration-card"><h3><UserPlus size={20}/> {r.last_name} {r.first_name}</h3><p>Nato/a il <strong>{birth(r.birth_date)}</strong></p><p className="notice"><strong>Scelta su Jotform:</strong> {r.requested_course||'Nessun corso indicato: scegli con l’iscritto.'}</p>
 <form onSubmit={async e=>{e.preventDefault();if(busy)return;const f=new FormData(e.currentTarget);setBusy(true);setError('');try{if(isPackage)await rpc('resolve_jotform_package',{p_id:r.id,p_total:Number(f.get('packageTotal')),p_from:String(f.get('from')),p_student:identity&&identity!=='new'?identity:null});else await rpc('resolve_jotform',{p_id:r.id,p_courses:isOpen?[]:f.getAll('courses').map(String),p_from:String(f.get('from')),p_student:identity&&identity!=='new'?identity:null,p_open:isOpen});await onSaved();}catch(err){setError(errorText(err));}finally{setBusy(false);}}}>
 {r.needs_identity_review&&<Field label="Possibile omonimo: controlla se esiste già"><select required value={identity} onChange={e=>setIdentity(e.target.value)}><option value="">Scegli l’alunno esistente oppure crea una nuova persona</option><option value="new">È una nuova persona</option>{students.filter(s=>!s.archived).sort((a,b)=>a.name.localeCompare(b.name)).map(s=><option key={s.id} value={s.id}>{s.name}{s.birth_date?' · '+birth(s.birth_date):' · nascita da completare'}</option>)}</select></Field>}
 <div className="field"><span>Iscritto fisso nei corsi</span><div className="check-list">{courses.filter(c=>!c.archived).map(c=><label className="check" key={c.id}><input type="checkbox" name="courses" value={c.id} disabled={isOpen||isPackage||busy}/><span>{c.name}</span></label>)}</div></div>
 <label className="check"><input type="checkbox" checked={isOpen} disabled={busy||isPackage} onChange={e=>setIsOpen(e.target.checked)}/>Piano Open: prenota le lezioni, senza corso fisso</label>
 <label className="check"><input type="checkbox" checked={isPackage} disabled={busy} onChange={e=>{setIsPackage(e.target.checked);if(e.target.checked)setIsOpen(false)}}/>Pacchetto lezioni · prenota con Wix, senza iscrizione fissa ai corsi</label>{isPackage&&<><Field label="Lezioni nel pacchetto"><input name="packageTotal" type="number" min="1" max="10000" required/></Field><p className="hint">Il collegamento a Wix avviene quando arriva la prenotazione con lo stesso nome completo. Ogni prenotazione confermata scala il residuo; le cancellazioni lo restituiscono. I nomi ambigui richiedono il collegamento manuale dalla scheda atleta.</p></>}
 <Field label="Valido dal"><input type="date" name="from" required min={localDate()} defaultValue={localDate()}/></Field>
 {error&&<p className="notice" role="alert">{error}</p>}<div className="actions"><button className="primary" disabled={busy}>{busy?'Salvataggio…':'Conferma assegnazione'}</button><button type="button" className="text-btn" disabled={busy} onClick={async()=>{if(!confirm('Non aggiungere questa iscrizione al database?'))return;setBusy(true);setError('');try{await rpc('skip_jotform',{p_id:r.id});await onSaved();}catch(err){setError(errorText(err));}finally{setBusy(false);}}}>Non aggiungere al database</button></div></form></article>;
}

