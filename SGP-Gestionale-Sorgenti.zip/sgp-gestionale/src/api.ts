import { createClient } from '@supabase/supabase-js';
import type { Dataset } from './types';
declare global { interface Window { SGP_CONFIG?:{supabaseUrl:string;supabaseAnonKey:string} } }
const config=window.SGP_CONFIG;
const url=import.meta.env.VITE_SUPABASE_URL || config?.supabaseUrl;
const key=import.meta.env.VITE_SUPABASE_ANON_KEY || config?.supabaseAnonKey;
export const supabase = url && key ? createClient(url,key) : null;
export const emptyData:Dataset = {profiles:[],courses:[],students:[],enrollments:[],lessons:[],assignments:[],participants:[],bookings:[],documents:[],notices:[],sync:[]};
// Boundary for ungenerated Supabase responses; domain types are declared in types.ts.
export function check({data,error}:{data?:any;error:unknown}):any {if(error) throw error;return data;}
export async function loadData():Promise<Dataset>{
  if(!supabase) return emptyData;
  const tables={profiles:'profiles',courses:'courses',students:'students',enrollments:'enrollments',lessons:'lessons',assignments:'lesson_teachers',participants:'lesson_participants',bookings:'wix_bookings',documents:'documents',notices:'notifications',sync:'sync_state'};
  const entries=await Promise.all(Object.entries(tables).map(async([k,t])=>{
    const rows:unknown[]=[];let offset=0;
    while(true){let q=supabase!.from(t).select('*');q=t==='lesson_teachers'?q.order('lesson_id').order('teacher_id'):q.order('id');const batch=check(await q.range(offset,offset+999));rows.push(...batch);if(batch.length<1000)break;offset+=1000;}
    return [k,rows];
  }));
  return Object.fromEntries(entries) as Dataset;
}
export async function rpc(name:string,args:Record<string,unknown>={}) {if(!supabase)throw Error('Collegamento dati non configurato.'); return check(await supabase.rpc(name,args));}
export async function invoke(name:string,body:Record<string,unknown>|FormData){
  if(!supabase)throw Error('Collegamento dati non configurato.');
  const {data,error}=await supabase.functions.invoke(name,{body});
  if(error){let message=error.message;try {const parsed=await error.context.json();message=parsed.error||message;}catch{}throw Error(message);}
  if(data?.error) throw Error(data.error);return data;
}
export const localDate=(date=new Date())=>new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Rome',year:'numeric',month:'2-digit',day:'2-digit'}).format(date);
export const time=(iso:string)=>new Date(iso).toLocaleTimeString('it-IT',{hour:'2-digit',minute:'2-digit',timeZone:'Europe/Rome'});
export const dateLabel=(iso:string)=>new Date(iso).toLocaleDateString('it-IT',{day:'numeric',month:'long',year:'numeric',timeZone:'Europe/Rome'});
export const errorText=(error:unknown)=>error instanceof Error?error.message:typeof error==='object'&&error&&'message' in error?String(error.message):'Operazione non riuscita. Riprova.';
