import type {Student,Course,Enrollment} from './types';

export const birthdayDay=(now=new Date())=>new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Rome',year:'numeric',month:'2-digit',day:'2-digit'}).format(now);

export function birthdaysToday(students:Student[],day=birthdayDay()):Student[]{
 const seen=new Set<string>();
 return students.filter(student=>{
  const birth=student.birth_date;
  if(student.archived||!birth||!/^\d{4}-\d{2}-\d{2}$/.test(birth)||birth>day||seen.has(student.id))return false;
  const parsed=new Date(birth+'T12:00:00Z');
  if(!Number.isFinite(parsed.getTime())||parsed.toISOString().slice(0,10)!==birth||birth.slice(5)!==day.slice(5))return false;
  seen.add(student.id);return true;
 }).sort((a,b)=>a.name.localeCompare(b.name,'it'));
}

export function birthdayCourses(studentId:string,courses:Course[],enrollments:Enrollment[],day=birthdayDay()):string[]{
 const current=new Set(enrollments.filter(e=>e.student_id===studentId&&e.valid_from<=day&&(!e.valid_to||e.valid_to>day)).map(e=>e.course_id));
 return Array.from(new Set(courses.filter(c=>!c.archived&&current.has(c.id)).map(c=>c.name))).sort((a,b)=>a.localeCompare(b,'it'));
}
