-- Save one roll call atomically, without overwriting another teacher's edits.
create or replace function public.save_roll_call(p_lesson uuid,p_rows jsonb)
returns void language plpgsql security definer set search_path='' as $$
declare v jsonb; v_row public.lesson_participants;
begin
 if not public.can_lesson(p_lesson) then raise exception 'Accesso negato'; end if;
 if jsonb_typeof(p_rows) is distinct from 'array' then raise exception 'Elenco non valido'; end if;
 if jsonb_array_length(p_rows)>500 then raise exception 'Troppi partecipanti'; end if;
 if exists(select 1 from public.lessons where id=p_lesson and cancelled) then raise exception 'Lezione annullata'; end if;
 for v in select value from jsonb_array_elements(p_rows) order by value->>'id' loop
  select * into v_row from public.lesson_participants where id=(v->>'id')::uuid for update;
  if not found or v_row.lesson_id<>p_lesson or v_row.excluded then raise exception 'Elenco cambiato: riapri la lezione'; end if;
  if v_row.status is distinct from v->>'expected' then raise exception 'Presenze aggiornate da un altro utente: riapri la lezione'; end if;
  if v->>'status' is null or v->>'status' not in ('present','absent','excused') then raise exception 'Presenza non valida'; end if;
  if v_row.status<>v->>'status' then perform public.set_attendance(v_row.id,v->>'status'); end if;
 end loop;
end $$;
revoke all on function public.save_roll_call(uuid,jsonb) from public,anon;
grant execute on function public.save_roll_call(uuid,jsonb) to authenticated;
