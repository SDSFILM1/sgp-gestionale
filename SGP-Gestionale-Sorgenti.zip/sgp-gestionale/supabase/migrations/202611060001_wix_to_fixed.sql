begin;
-- Separate historical identity from the active Wix membership connection.
alter table public.wix_people add column fixed_student_id uuid references public.students;
alter table public.wix_people add column fixed_since timestamptz;

create function public.secretary_wix_to_fixed(p_wix uuid,p_courses uuid[],p_student uuid default null) returns uuid
language plpgsql security definer set search_path='' as $$
declare person public.wix_people; pupil public.students; sid uuid; linked uuid; before_value jsonb;
begin
 perform public.require_secretary();perform pg_advisory_xact_lock(927001);
 if coalesce(cardinality(p_courses),0)=0 or exists(select 1 from unnest(p_courses) c where c is null or not exists(select 1 from public.courses where id=c and not archived)) then raise exception 'Seleziona almeno un corso valido';end if;
 select * into person from public.wix_people where id=p_wix for update;
 if not found then raise exception 'Atleta Wix non valido';end if;
 if person.fixed_student_id is not null then return person.fixed_student_id;end if;
 if person.ignored then raise exception 'Atleta Wix non attivo';end if;
 select student_id into linked from public.student_wix_links where wix_person_id=p_wix;
 if linked is not null and p_student is not null and linked<>p_student then raise exception 'Questa identità è già collegata a un altro alunno';end if;
 sid:=coalesce(linked,p_student);
 if sid is not null then
  select * into pupil from public.students where id=sid for update;
  if not found or pupil.archived then raise exception 'Alunno non attivo';end if;
  if exists(select 1 from public.student_wix_links where student_id=sid and wix_person_id<>p_wix) then raise exception 'Altri collegamenti Wix presenti: contatta la segreteria';end if;
 end if;
 select jsonb_build_object('person',to_jsonb(person),'student',to_jsonb(pupil),
  'package',(select to_jsonb(p) from public.student_packages p where student_id=sid),
  'enrollments',(select jsonb_agg(to_jsonb(e)) from public.enrollments e where student_id=sid)) into before_value;
 if sid is null then
  -- Reuse the standard duplicate checks; never guess an identity from a name.
  sid:=public.secretary_save_student_courses(null,person.name,'',null,false,p_courses);
 else
  delete from public.student_packages where student_id=sid;
  update public.students set wix_managed=false,enrollment_state='enrolled' where id=sid;
  perform public.secretary_save_student_courses(sid,pupil.name,pupil.notes,pupil.birth_date,false,p_courses);
 end if;
 insert into public.student_staff_notes(id,student_id,author_id,body,created_at)
 select id,sid,author_id,body,created_at from public.wix_staff_notes where wix_person_id=p_wix on conflict(id) do nothing;
 update public.wix_people set ignored=true,fixed_student_id=sid,fixed_since=now() where id=p_wix;
 delete from public.student_wix_links where wix_person_id=p_wix;
 insert into public.audit_log(actor_id,event,entity_id,before_value,after_value)
 values(auth.uid(),'wix_to_fixed',p_wix::text,before_value,jsonb_build_object('student',sid,'courses',p_courses));
 return sid;
end $$;
revoke all on function public.secretary_wix_to_fixed(uuid,uuid[],uuid) from public,anon;
grant execute on function public.secretary_wix_to_fixed(uuid,uuid[],uuid) to authenticated;

-- An ignored/detached identity must never be linked again by a later sync.
do $patch$
declare definition text;
begin
 select pg_get_functiondef('public.auto_link_package_wix()'::regprocedure) into definition;
 if position('where not s.archived' in definition)=0 then raise exception 'Controllo collegamenti non riconosciuto';end if;
 execute replace(definition,'where not s.archived','where not w.ignored and not s.archived');
end $patch$;

-- Keep the historical teacher scope and canonical attendance identity, while
-- future Wix bookings for a converted student stay excluded from the roster.
do $patch$
declare definition text;needle text;replacement text;
begin
 select pg_get_functiondef('public.staff_dataset()'::regprocedure) into definition;
 needle:='left join public.student_wix_links k on k.wix_person_id=b.wix_person_id';
 replacement:='left join (select wix_person_id,student_id from public.student_wix_links union all select id,fixed_student_id from public.wix_people where fixed_student_id is not null) k on k.wix_person_id=b.wix_person_id';
 if position(needle in definition)=0 then raise exception 'Dataset non riconosciuto';end if;
 definition:=replace(definition,needle,replacement);
 needle:='ignored.id=b.wix_person_id and ignored.ignored';
 replacement:='ignored.id=b.wix_person_id and ignored.ignored and (ignored.fixed_student_id is null or l.starts_at>=ignored.fixed_since)';
 if position(needle in definition)=0 then raise exception 'Filtro Wix non riconosciuto';end if;
 definition:=replace(definition,needle,replacement);
 needle:='where public.can_wix_person(k.wix_person_id))q;';
 replacement:='where public.can_wix_person(k.wix_person_id) union select fixed_student_id from public.wix_people w where fixed_student_id is not null and public.can_wix_person(w.id))q;';
 if position(needle in definition)=0 then raise exception 'Ambito insegnanti non riconosciuto';end if;
 execute replace(definition,needle,replacement);
 select pg_get_functiondef('public.can_student(uuid)'::regprocedure) into definition;
 needle:='public.can_wix_person(k.wix_person_id))))';
 if position(needle in definition)=0 then raise exception 'Permessi alunni non riconosciuti';end if;
 execute replace(definition,needle,'public.can_wix_person(k.wix_person_id)) or exists(select 1 from public.wix_people w where w.fixed_student_id=p_student and public.can_wix_person(w.id))))');
end $patch$;
notify pgrst,'reload schema';
commit;
