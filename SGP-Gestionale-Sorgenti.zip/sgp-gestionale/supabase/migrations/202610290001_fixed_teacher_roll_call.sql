begin;

-- A fixed course teacher can compile today's and future existing lessons as well.
-- Do not insert historical lesson_teachers rows or alter any attendance marks.
create or replace function public.can_lesson(p_id uuid) returns boolean
language sql stable security definer set search_path='' as $$
 select public.is_secretary() or (public.is_active() and (
  exists(select 1 from public.lesson_teachers where lesson_id=p_id and teacher_id=auth.uid())
  or exists(select 1 from public.lesson_substitutes where lesson_id=p_id and teacher_id=auth.uid() and active)
  or exists(select 1 from public.lessons l join public.course_teachers t on t.course_id=l.course_id
    where l.id=p_id and t.teacher_id=auth.uid()
      and l.starts_at >= ((now() at time zone 'Europe/Rome')::date::timestamp at time zone 'Europe/Rome'))))
$$;

-- Keep the optimized, private dataset contract and include lessons of fixed courses.
do $$
declare definition text;
needle text:='select coalesce(array_agg(lesson_id),''{}''::uuid[]) into v_lessons from (select lesson_id from public.lesson_teachers where teacher_id=v_user union select lesson_id from public.lesson_substitutes where teacher_id=v_user and active) q;';
replacement text:='select coalesce(array_agg(lesson_id),''{}''::uuid[]) into v_lessons from (
 select lesson_id from public.lesson_teachers where teacher_id=v_user
 union select lesson_id from public.lesson_substitutes where teacher_id=v_user and active
 union select l.id from public.lessons l join public.course_teachers ct on ct.course_id=l.course_id where ct.teacher_id=v_user
  and l.starts_at >= ((now() at time zone ''Europe/Rome'')::date::timestamp at time zone ''Europe/Rome'')
 ) q;';
begin
 select pg_get_functiondef('public.staff_dataset()'::regprocedure) into definition;
 if position(needle in definition)=0 then raise exception 'Definizione staff_dataset non riconosciuta: nessuna modifica applicata';end if;
 execute replace(definition,needle,replacement);
end $$;

-- The existing UI then offers "Apri appello", also for a completed lesson of a fixed course.
-- Extraordinary substitutes still receive access to their single lesson only.
create or replace function public.substitute_calendar(p_from date,p_until date)
returns table(id uuid,course_id uuid,course_name text,starts_at timestamptz,ends_at timestamptz,location text,cancelled boolean,is_assigned boolean,is_substitute boolean)
language plpgsql stable security definer set search_path='' as $$
begin
 if not public.is_active() then raise exception 'Accesso negato';end if;
 if p_from is null or p_until is null or p_until<p_from or p_until>p_from+31 then raise exception 'Scegli un periodo massimo di 31 giorni';end if;
 return query select l.id,l.course_id,c.name,l.starts_at,l.ends_at,l.location,l.cancelled,
  (exists(select 1 from public.lesson_teachers t where t.lesson_id=l.id and t.teacher_id=auth.uid())
   or exists(select 1 from public.course_teachers ct where ct.course_id=l.course_id and ct.teacher_id=auth.uid()
    and l.starts_at >= ((now() at time zone 'Europe/Rome')::date::timestamp at time zone 'Europe/Rome'))),
  exists(select 1 from public.lesson_substitutes s where s.lesson_id=l.id and s.teacher_id=auth.uid() and s.active)
 from public.lessons l join public.courses c on c.id=l.course_id
 where not c.archived and l.starts_at >= p_from::timestamp at time zone 'Europe/Rome' and l.starts_at < (p_until+1)::timestamp at time zone 'Europe/Rome'
 order by l.starts_at,c.name,l.id;
end $$;

notify pgrst,'reload schema';
commit;
