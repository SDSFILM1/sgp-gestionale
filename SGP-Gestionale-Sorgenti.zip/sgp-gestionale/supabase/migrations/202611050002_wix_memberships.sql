begin;
alter table public.wix_people add column ignored boolean not null default false;
alter table public.students add column wix_managed boolean not null default false;
alter table public.wix_plan_orders add column member_id text;
alter table public.wix_plan_orders add column plan_name text;
create table public.wix_balances(
 id text primary key,member_id text,external_program_id text,status text,
 available numeric,reserved numeric,credit_amount numeric,depleted_at timestamptz,
 source_present boolean not null default true,updated_at timestamptz not null default now()
);
create index on public.wix_balances(external_program_id,member_id);
alter table public.wix_balances enable row level security;
revoke all on public.wix_balances from public,anon,authenticated;
grant all on public.wix_balances to service_role;

alter function public.apply_wix_snapshot(jsonb,jsonb) rename to apply_wix_snapshot_before_memberships;
revoke all on function public.apply_wix_snapshot_before_memberships(jsonb,jsonb) from public,anon,authenticated,service_role;
create function public.apply_wix_snapshot(p_rows jsonb,p_orders jsonb default null,p_balances jsonb default null,p_contacts jsonb default null) returns integer
language plpgsql security definer set search_path='' as $$
declare n integer;
begin
 if (p_contacts is not null and jsonb_typeof(p_contacts)<>'array') or (p_balances is not null and jsonb_typeof(p_balances)<>'array') then raise exception 'Snapshot Wix non valido';end if;
 n:=public.apply_wix_snapshot_before_memberships(p_rows,p_orders);
 if p_orders is not null then
  update public.wix_plan_orders o set member_id=v->>'member_id',plan_name=v->>'plan_name' from jsonb_array_elements(p_orders) v where o.id=v->>'id';
 end if;
 if p_contacts is not null then
  insert into public.wix_people(contact_id,name) select v->>'contact_id',v->>'name' from jsonb_array_elements(p_contacts) v
  where nullif(v->>'contact_id','') is not null and nullif(trim(v->>'name'),'') is not null
  on conflict(contact_id) do update set name=excluded.name;
 end if;
 if p_balances is not null then
  update public.wix_balances set source_present=false where source_present;
  insert into public.wix_balances(id,member_id,external_program_id,status,available,reserved,credit_amount,depleted_at)
  select v->>'id',v->>'member_id',v->>'external_program_id',v->>'status',(v->>'available')::numeric,(v->>'reserved')::numeric,(v->>'credit_amount')::numeric,
   case when (v->>'available')::numeric=0 then now() end from jsonb_array_elements(p_balances) v
  on conflict(id) do update set member_id=excluded.member_id,external_program_id=excluded.external_program_id,status=excluded.status,
   available=excluded.available,reserved=excluded.reserved,credit_amount=excluded.credit_amount,
   depleted_at=case when excluded.available=0 then coalesce(public.wix_balances.depleted_at,excluded.depleted_at) end,
   source_present=true,updated_at=now();
  insert into public.sync_state(id,last_success,last_error) values('wix-balances',now(),null) on conflict(id) do update set last_success=now(),last_error=null;
 else
  insert into public.sync_state(id,last_error) values('wix-balances','Saldi Wix non aggiornati: controlla i permessi.') on conflict(id) do update set last_error=excluded.last_error;
 end if;
 return n;
end $$;
revoke all on function public.apply_wix_snapshot(jsonb,jsonb,jsonb,jsonb) from public,anon,authenticated;
grant execute on function public.apply_wix_snapshot(jsonb,jsonb,jsonb,jsonb) to service_role;

-- No activity deadline: an active subscription is visible even before booking.
create or replace function public.staff_wix_people() returns table(id uuid,name text,last_booking_at timestamptz,next_booking_at timestamptz,subscription_ends_at timestamptz,hide_at timestamptz,hide_reason text)
language sql stable security definer set search_path='' as $$
 with orders as materialized (
  select o.*,case when b.depleted_at is not null and b.available=0 then least(o.end_date,b.depleted_at) else o.end_date end effective_end
  from public.wix_plan_orders o left join lateral (
   select min(depleted_at) depleted_at,min(available) available from public.wix_balances b where b.source_present and b.external_program_id=o.id and b.member_id=o.member_id
  ) b on true where o.source_present and o.status not in('DRAFT','PENDING')
 ), plans as (
  select contact_id,bool_or(status in('ACTIVE','PAUSED','CANCELED') and (start_date is null or start_date<=now()) and (effective_end>now() or (effective_end is null and status in('ACTIVE','PAUSED')))) usable,
  max(effective_end) ended_at from orders group by contact_id
 ), activity as (
  select wix_person_id,max(booked_at) last_booking_at,min(starts_at) filter(where starts_at>=now()) next_booking_at from public.wix_bookings
  where source_present and status='CONFIRMED' group by wix_person_id
 ), visible as (
  select p.id,p.name,a.last_booking_at,a.next_booking_at,case when coalesce(o.usable,false) then null else o.ended_at end subscription_ends_at,
   case when coalesce(o.usable,false) or exists(select 1 from public.sync_state where id in('wix-plans','wix-balances') and last_error is not null) then null else o.ended_at+interval '3 days' end hide_at
  from public.wix_people p join plans o on o.contact_id=p.contact_id left join activity a on a.wix_person_id=p.id
  where not p.ignored and public.can_wix_person(p.id)
 ) select v.id,v.name,v.last_booking_at,v.next_booking_at,v.subscription_ends_at,v.hide_at,'subscription'::text from visible v
 where v.hide_at is null or v.hide_at>now() order by v.name,v.id
$$;

create function public.staff_wix_packages() returns jsonb language sql stable security definer set search_path='' as $$
 select coalesce(jsonb_agg(jsonb_build_object('id',o.id,'wix_person_id',p.id,'name',o.plan_name,'status',o.status,'ends_at',o.end_date,
  'total',b.credit_amount,'remaining',b.available,'reserved',b.reserved,'updated_at',b.updated_at)),'[]'::jsonb)
 from public.wix_plan_orders o join public.wix_people p on p.contact_id=o.contact_id
 left join public.wix_balances b on b.external_program_id=o.id and b.member_id=o.member_id and b.source_present
 where not p.ignored and o.source_present and o.status not in('DRAFT','PENDING') and public.can_wix_person(p.id)
$$;
revoke all on function public.staff_wix_packages() from public,anon,authenticated;

create function public.secretary_choose_wix_person(p_wix uuid,p_student uuid default null) returns void language plpgsql security definer set search_path='' as $$
begin
 perform public.require_secretary();perform pg_advisory_xact_lock(927001);
 if not exists(select 1 from public.wix_people where id=p_wix and not ignored) then raise exception 'Atleta Wix non valido';end if;
 if p_student is not null then
  perform public.secretary_link_wix_student(p_student,p_wix);
  update public.students set wix_managed=true where id=p_student;
  update public.enrollments set valid_to=greatest(valid_from,(now() at time zone 'Europe/Rome')::date) where student_id=p_student and (valid_to is null or valid_to>(now() at time zone 'Europe/Rome')::date);
 end if;
 insert into public.audit_log(actor_id,event,entity_id,after_value) values(auth.uid(),'student_wix_mode',p_wix::text,jsonb_build_object('student_id',p_student));
end $$;
revoke all on function public.secretary_choose_wix_person(uuid,uuid) from public,anon;
grant execute on function public.secretary_choose_wix_person(uuid,uuid) to authenticated;

alter function public.staff_dataset() rename to staff_dataset_before_wix_memberships;
revoke all on function public.staff_dataset_before_wix_memberships() from public,anon,authenticated;
-- Patch the existing scoped query in place: do not parse and join the full JSON roster twice.
do $migration$
declare definition text;needle text;replacement text;
begin
 select pg_get_functiondef('public.staff_dataset_before_wix_memberships()'::regprocedure) into definition;
 definition:=replace(definition,'public.staff_dataset_before_wix_memberships()','public.staff_dataset()');
 needle:=$old$'enrollment_state',s.enrollment_state)$old$; replacement:=$new$'enrollment_state',s.enrollment_state,'wix_managed',s.wix_managed)$new$;
 if position(needle in definition)=0 then raise exception 'Dataset non riconosciuto: nessuna modifica applicata';end if;
 definition:=replace(definition,needle,replacement);
 needle:=$old$where (v_admin or p.lesson_id=any(v_lessons))$old$; replacement:=$new$where (v_admin or p.lesson_id=any(v_lessons))
 and not exists(select 1 from public.wix_people ignored where ignored.id=b.wix_person_id and ignored.ignored)
 and (not coalesce(s.wix_managed,false) or (l.starts_at at time zone 'Europe/Rome')::date<(now() at time zone 'Europe/Rome')::date
 or exists(select 1 from public.wix_bookings booked join public.student_wix_links linked on linked.wix_person_id=booked.wix_person_id
 where linked.student_id=s.id and booked.lesson_id=l.id and booked.source_present and booked.status='CONFIRMED'))$new$;
 if position(needle in definition)=0 then raise exception 'Dataset non riconosciuto: nessuna modifica applicata';end if;
 definition:=replace(definition,needle,replacement);
 needle:=$old$from public.staff_wix_people() w where not exists(select 1 from public.student_wix_links k where k.wix_person_id=w.id)$old$; replacement:=$new$from public.staff_wix_people() w$new$;
 if position(needle in definition)=0 then raise exception 'Dataset non riconosciuto: nessuna modifica applicata';end if;
 definition:=replace(definition,needle,replacement);
 needle:=$old$from public.staff_wix_notes() n where not exists(select 1 from public.student_wix_links k where k.wix_person_id=n.wix_person_id)$old$; replacement:=$new$from public.staff_wix_notes() n join public.wix_people wp on wp.id=n.wix_person_id where not wp.ignored$new$;
 if position(needle in definition)=0 then raise exception 'Dataset non riconosciuto: nessuna modifica applicata';end if;
 definition:=replace(definition,needle,replacement);
 needle:=$old$return v_data || jsonb_build_object($old$; replacement:=$new$return v_data || jsonb_build_object('wixPackages',public.staff_wix_packages(),$new$;
 if position(needle in definition)=0 then raise exception 'Dataset non riconosciuto: nessuna modifica applicata';end if;
 definition:=replace(definition,needle,replacement);
 execute definition;
end $migration$;
revoke all on function public.staff_dataset() from public,anon;
grant execute on function public.staff_dataset() to authenticated;
notify pgrst,'reload schema';
commit;
