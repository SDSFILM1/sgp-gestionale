-- A public endpoint with no access to application data.
-- It is called once a day by GitHub Actions to keep the Free project active.
create or replace function public.sgp_keepalive()
returns timestamptz
language sql
security invoker
set search_path = ''
as $$ select now() $$;

revoke all on function public.sgp_keepalive() from public;
grant execute on function public.sgp_keepalive() to anon;
