-- SGP: dati privati, storico per lezione e operazioni atomiche.
create table public.profiles (
 id uuid primary key references auth.users(id), name text not null check(length(trim(name))>0),
 email text not null, role text not null check(role in ('secretary','teacher')) default 'teacher',
 active boolean not null default true, must_change_password boolean not null default true
);
create table public.courses (
 id uuid primary key default gen_random_uuid(), name text not null check(length(trim(name))>0),
 audience text not null default 'ragazzi' check(audience in ('ragazzi','adulti','misto')),
 location text not null default '', color text not null default '#0066cc',
 wix_service_id text unique, archived boolean not null default false
);
create table public.students (
 id uuid primary key default gen_random_uuid(),name text not null check(length(trim(name))>0),
 notes text not null default '', archived boolean not null default false
);
create table public.enrollments (
 id uuid primary key default gen_random_uuid(), course_id uuid not null references public.courses,
 student_id uuid not null references public.students, valid_from date not null, valid_to date,
 check(valid_to is null or valid_to>=valid_from), unique(course_id,student_id,valid_from)
);
create table public.lessons (
 id uuid primary key default gen_random_uuid(), course_id uuid not null references public.courses,
 starts_at timestamptz not null, ends_at timestamptz not null, location text not null default '',
 notes text not null default '', cancelled boolean not null default false,
 check(ends_at>starts_at),unique(course_id,starts_at)
);
create table public.lesson_teachers (
 lesson_id uuid not null references public.lessons,teacher_id uuid not null references public.profiles,
 status text not null default 'pending' check(status in ('pending','present','absent')),
 note text not null default '',updated_at timestamptz not null default now(),primary key(lesson_id,teacher_id)
);
create table public.lesson_participants (
 id uuid primary key default gen_random_uuid(),lesson_id uuid not null references public.lessons,
 student_id uuid references public.students,name text not null,
 source text not null check(source in ('fixed','manual','wix')),
 status text not null default 'unmarked' check(status in ('unmarked','present','absent','excused')),
 excluded boolean not null default false,wix_booking_id text,
 updated_at timestamptz not null default now(), updated_by uuid references public.profiles,
 unique(lesson_id,student_id), unique(lesson_id,wix_booking_id)
);
create table public.wix_bookings (
 id text primary key,course_id uuid references public.courses,lesson_id uuid references public.lessons,
 name text not null,starts_at timestamptz,ends_at timestamptz,status text not null,
 participants integer not null default 1,service_name text not null default '',updated_at timestamptz not null default now()
);
create table public.documents (
 id uuid primary key default gen_random_uuid(),teacher_id uuid not null references public.profiles,
 name text not null,notes text not null default '',size integer not null check(size>0 and size<=20971520),
 mime text not null,created_at timestamptz not null default now(),drive_file_id text,
 status text not null default 'uploading' check(status in ('uploading','ready','error'))
);
create table public.notifications (
 id uuid primary key default gen_random_uuid(),recipient_id uuid not null references public.profiles,
 title text not null,body text not null default '',read_at timestamptz,created_at timestamptz not null default now()
);
create table public.sync_state (id text primary key,last_success timestamptz,last_error text);
create table public.audit_log (id bigint generated always as identity primary key,actor_id uuid,event text not null,entity_id text,before_value jsonb,after_value jsonb,created_at timestamptz not null default now());
create index on public.lessons(starts_at);
create index on public.lesson_teachers(teacher_id);
create index on public.lesson_participants(student_id);
create index on public.enrollments(course_id,valid_from,valid_to);
create index on public.documents(teacher_id,created_at);

create function public.is_active() returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.profiles where id=auth.uid() and active and not must_change_password)
$$;
create function public.is_secretary() returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.profiles where id=auth.uid() and active and not must_change_password and role='secretary')
$$;
create function public.can_lesson(p_id uuid) returns boolean language sql stable security definer set search_path='' as $$
 select public.is_secretary() or (public.is_active() and exists(select 1 from public.lesson_teachers where lesson_id=p_id and teacher_id=auth.uid()))
$$;
create function public.can_course(p_id uuid) returns boolean language sql stable security definer set search_path='' as $$
 select public.is_secretary() or (public.is_active() and exists(select 1 from public.lessons l join public.lesson_teachers t on t.lesson_id=l.id where l.course_id=p_id and t.teacher_id=auth.uid()))
$$;
create function public.require_secretary() returns void language plpgsql security definer set search_path='' as $$
 begin if not public.is_secretary() then raise exception 'Accesso riservato alla segreteria';end if;end
$$;

alter table public.profiles enable row level security;
alter table public.courses enable row level security;
alter table public.students enable row level security;
alter table public.enrollments enable row level security;
alter table public.lessons enable row level security;
alter table public.lesson_teachers enable row level security;
alter table public.lesson_participants enable row level security;
alter table public.wix_bookings enable row level security;
alter table public.documents enable row level security;
alter table public.notifications enable row level security;
alter table public.sync_state enable row level security;
alter table public.audit_log enable row level security;
create policy profile_read on public.profiles for select to authenticated using(id=auth.uid() or public.is_secretary());
create policy courses_read on public.courses for select to authenticated using(public.can_course(id));
create policy students_read on public.students for select to authenticated using(public.is_secretary());
create policy enrollments_read on public.enrollments for select to authenticated using(public.is_secretary());
create policy lessons_read on public.lessons for select to authenticated using(public.can_lesson(id));
create policy teachers_read on public.lesson_teachers for select to authenticated using(public.can_lesson(lesson_id));
create policy participants_read on public.lesson_participants for select to authenticated using(public.can_lesson(lesson_id));
create policy bookings_read on public.wix_bookings for select to authenticated using(public.is_secretary() or public.can_lesson(lesson_id));
create policy documents_read on public.documents for select to authenticated using(public.is_secretary() or (public.is_active() and teacher_id=auth.uid()));
create policy notices_read on public.notifications for select to authenticated using(public.is_secretary() or (public.is_active() and recipient_id=auth.uid()));
create policy sync_read on public.sync_state for select to authenticated using(public.is_active());
create policy audit_read on public.audit_log for select to authenticated using(public.is_secretary());

-- No authenticated direct writes: the RPCs below enforce per-field permissions.
revoke all on all tables in schema public from anon,authenticated;
grant select on public.profiles,public.courses,public.students,public.enrollments,public.lessons,public.lesson_teachers,public.lesson_participants,public.wix_bookings,public.documents,public.notifications,public.sync_state,public.audit_log to authenticated;

create function public.save_course(p_name text,p_audience text,p_location text,p_wix_service_id text default null,p_id uuid default null) returns uuid language plpgsql security definer set search_path='' as $$
 declare v_id uuid;begin perform public.require_secretary();
 if length(trim(p_name))=0 or length(p_name)>200 then raise exception 'Nome corso non valido';end if;
 if p_id is null then insert into public.courses(name,audience,location,wix_service_id) values(trim(p_name),p_audience,p_location,nullif(p_wix_service_id,'')) returning id into v_id;
 else update public.courses set name=trim(p_name),audience=p_audience,location=p_location,wix_service_id=nullif(p_wix_service_id,'') where id=p_id returning id into v_id;end if;
 return v_id;end
$$;
create function public.save_student(p_name text,p_notes text default '',p_id uuid default null) returns uuid language plpgsql security definer set search_path='' as $$
 declare v_id uuid;begin perform public.require_secretary();
 if length(trim(p_name))=0 or length(p_name)>200 then raise exception 'Nome alunno non valido';end if;
 if p_id is null then insert into public.students(name,notes) values(trim(p_name),p_notes) returning id into v_id;
 else update public.students set name=trim(p_name),notes=p_notes where id=p_id returning id into v_id;end if;return v_id;end
$$;
create function public.refresh_roster(p_course uuid,p_from date) returns void language plpgsql security definer set search_path='' as $$
 begin
 -- Remove only future unmarked fixed memberships that no longer apply. Manual exceptions survive.
 delete from public.lesson_participants p using public.lessons l where p.lesson_id=l.id and l.course_id=p_course
 and l.starts_at>=now() and (l.starts_at at time zone 'Europe/Rome')::date>=p_from and p.source='fixed' and p.status='unmarked'
 and not exists(select 1 from public.enrollments e where e.course_id=p_course and e.student_id=p.student_id
 and e.valid_from<=(l.starts_at at time zone 'Europe/Rome')::date and (e.valid_to is null or e.valid_to>(l.starts_at at time zone 'Europe/Rome')::date));
 insert into public.lesson_participants(lesson_id,student_id,name,source)
 select l.id,s.id,s.name,'fixed' from public.lessons l join public.enrollments e on e.course_id=l.course_id
 join public.students s on s.id=e.student_id where l.course_id=p_course and l.starts_at>=now()
 and (l.starts_at at time zone 'Europe/Rome')::date>=p_from and e.valid_from<=(l.starts_at at time zone 'Europe/Rome')::date
 and (e.valid_to is null or e.valid_to>(l.starts_at at time zone 'Europe/Rome')::date) and not s.archived
 on conflict(lesson_id,student_id) do nothing;
 end
$$;
create function public.set_roster(p_course uuid,p_from date,p_students uuid[]) returns void language plpgsql security definer set search_path='' as $$
 begin perform public.require_secretary();
 if p_from<(now() at time zone 'Europe/Rome')::date then raise exception 'Scegli oggi o una data futura: lo storico va conservato';end if;
 perform 1 from public.courses where id=p_course for update;if not found then raise exception 'Corso inesistente';end if;
 if exists(select 1 from unnest(p_students) x where not exists(select 1 from public.students s where s.id=x and not s.archived)) then raise exception 'Alunno non valido';end if;
 insert into public.audit_log(actor_id,event,entity_id,before_value,after_value) values(auth.uid(),'roster_change',p_course::text,
 (select coalesce(jsonb_agg(to_jsonb(e)),'[]') from public.enrollments e where e.course_id=p_course),jsonb_build_object('from',p_from,'students',p_students));
 delete from public.enrollments where course_id=p_course and valid_from>=p_from;
 update public.enrollments set valid_to=p_from where course_id=p_course and valid_from<p_from and (valid_to is null or valid_to>p_from);
 insert into public.enrollments(course_id,student_id,valid_from) select p_course,x,p_from from (select distinct unnest(p_students) x) q;
 perform public.refresh_roster(p_course,p_from);end
$$;
create function public.create_lessons(p_course uuid,p_from date,p_until date,p_start time,p_end time,p_teachers uuid[],p_weekly boolean default true) returns integer language plpgsql security definer set search_path='' as $$
 declare v_day date;v_id uuid;v_count integer:=0;begin perform public.require_secretary();
 if p_until<p_from or p_until>p_from+366 or p_end<=p_start then raise exception 'Date o orari non validi';end if;
 if cardinality(p_teachers)=0 or exists(select 1 from unnest(p_teachers) x where not exists(select 1 from public.profiles p where p.id=x and p.active and p.role='teacher')) then raise exception 'Seleziona insegnanti attivi';end if;
 perform 1 from public.courses where id=p_course for update;
 v_day:=p_from;while v_day<=p_until loop
 insert into public.lessons(course_id,starts_at,ends_at,location) select p_course,(v_day+p_start) at time zone 'Europe/Rome',(v_day+p_end) at time zone 'Europe/Rome',location from public.courses where id=p_course on conflict do nothing returning id into v_id;
 if v_id is not null then
 insert into public.lesson_teachers(lesson_id,teacher_id) select v_id,x from (select distinct unnest(p_teachers) x) q;
 insert into public.lesson_participants(lesson_id,student_id,name,source) select v_id,s.id,s.name,'fixed' from public.enrollments e join public.students s on s.id=e.student_id where e.course_id=p_course and e.valid_from<=v_day and(e.valid_to is null or e.valid_to>v_day) and not s.archived on conflict do nothing;
 v_count:=v_count+1;end if;
 exit when not p_weekly;v_day:=v_day+7;end loop;return v_count;end
$$;
create function public.set_attendance(p_participant uuid,p_status text) returns void language plpgsql security definer set search_path='' as $$
 declare v_old public.lesson_participants;begin select * into v_old from public.lesson_participants where id=p_participant for update;
 if not found or not public.can_lesson(v_old.lesson_id) then raise exception 'Accesso negato';end if;
 if exists(select 1 from public.lessons where id=v_old.lesson_id and cancelled) or v_old.excluded then raise exception 'Partecipante o lezione esclusi';end if;
 update public.lesson_participants set status=p_status,updated_at=now(),updated_by=auth.uid() where id=p_participant;
 insert into public.audit_log(actor_id,event,entity_id,before_value,after_value) values(auth.uid(),'attendance',p_participant::text,to_jsonb(v_old),jsonb_build_object('status',p_status));end
$$;
create function public.set_teacher_presence(p_lesson uuid,p_status text,p_note text default '') returns void language plpgsql security definer set search_path='' as $$
 begin if not public.is_active() then raise exception 'Accesso negato';end if;
 if exists(select 1 from public.lessons where id=p_lesson and cancelled) then raise exception 'Lezione annullata';end if;
 update public.lesson_teachers set status=p_status,note=p_note,updated_at=now() where lesson_id=p_lesson and teacher_id=auth.uid();
 if not found then raise exception 'Lezione non assegnata';end if;end
$$;
create function public.lesson_override(p_lesson uuid,p_student uuid,p_excluded boolean) returns void language plpgsql security definer set search_path='' as $$
 begin perform public.require_secretary();
 insert into public.lesson_participants(lesson_id,student_id,name,source,excluded) select p_lesson,id,name,'manual',p_excluded from public.students where id=p_student
 on conflict(lesson_id,student_id) do update set source='manual',excluded=excluded.excluded,updated_at=now(),updated_by=auth.uid();end
$$;
create function public.update_lesson(p_lesson uuid,p_start timestamptz,p_end timestamptz,p_location text,p_notes text,p_cancelled boolean,p_teachers uuid[]) returns void language plpgsql security definer set search_path='' as $$
 declare v_old public.lessons;begin perform public.require_secretary();select * into v_old from public.lessons where id=p_lesson for update;
 if not found then raise exception 'Lezione inesistente';end if;
 if exists(select 1 from unnest(p_teachers) x where not exists(select 1 from public.profiles p where p.id=x and p.active and p.role='teacher')) then raise exception 'Insegnante non valido';end if;
 update public.lessons set starts_at=p_start,ends_at=p_end,location=p_location,notes=p_notes,cancelled=p_cancelled where id=p_lesson;
 delete from public.lesson_teachers where lesson_id=p_lesson and not(teacher_id=any(p_teachers));
 insert into public.lesson_teachers(lesson_id,teacher_id) select p_lesson,x from(select distinct unnest(p_teachers) x) q on conflict do nothing;
 insert into public.audit_log(actor_id,event,entity_id,before_value,after_value) values(auth.uid(),'lesson_edit',p_lesson::text,to_jsonb(v_old),jsonb_build_object('start',p_start,'end',p_end,'teachers',p_teachers));end
$$;
create function public.read_notification(p_id uuid) returns void language plpgsql security definer set search_path='' as $$
 begin if not public.is_active() then raise exception 'Accesso negato';end if;update public.notifications set read_at=now() where id=p_id and recipient_id=auth.uid();end
$$;
create function public.send_notification(p_recipients uuid[],p_title text,p_body text) returns void language plpgsql security definer set search_path='' as $$
 begin perform public.require_secretary();if length(trim(p_title))=0 then raise exception 'Inserisci un titolo';end if;
 insert into public.notifications(recipient_id,title,body) select id,trim(p_title),p_body from public.profiles where id=any(p_recipients) and active;end
$$;
-- Internal roster helper never callable by a client.
revoke execute on all functions in schema public from public,anon,authenticated;
grant execute on function public.is_active(),public.is_secretary(),public.can_lesson(uuid),public.can_course(uuid) to authenticated;
grant execute on function public.save_course(text,text,text,text,uuid),public.save_student(text,text,uuid),public.set_roster(uuid,date,uuid[]),public.create_lessons(uuid,date,date,time,time,uuid[],boolean),public.set_attendance(uuid,text),public.set_teacher_presence(uuid,text,text),public.lesson_override(uuid,uuid,boolean),public.update_lesson(uuid,timestamptz,timestamptz,text,text,boolean,uuid[]),public.read_notification(uuid),public.send_notification(uuid[],text,text) to authenticated;
grant all on all tables in schema public to service_role;
grant usage,select on all sequences in schema public to service_role;
grant execute on all functions in schema public to service_role;
