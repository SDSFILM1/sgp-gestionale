begin;
-- A current confirmed Wix booking is an enrolled attendee, even when a linked
-- legacy fixed roster row still says trial. Keep row IDs and saved marks intact.
do $$
declare definition text;needle text;replacement text;
begin
 select pg_get_functiondef('public.staff_dataset()'::regprocedure) into definition;
 needle:='||case when package_from is not null and (starts_at at time zone ''Europe/Rome'')::date>=package_from then jsonb_build_object(''package_booking'',true,''is_trial'',false) else ''{}''::jsonb end)';
 replacement:='||case when package_from is not null and (starts_at at time zone ''Europe/Rome'')::date>=package_from then jsonb_build_object(''package_booking'',true,''is_trial'',false) else ''{}''::jsonb end
 ||case when exists(select 1 from public.wix_bookings booked
 join public.student_wix_links linked on linked.wix_person_id=booked.wix_person_id
 where linked.student_id=p.logical_student and booked.lesson_id=p.lesson_id
 and booked.source_present and booked.status=''CONFIRMED'')
 then jsonb_build_object(''is_trial'',false,''source'',''wix'') else ''{}''::jsonb end)';
 if position(needle in definition)=0 then raise exception 'Dataset non riconosciuto: nessuna modifica applicata';end if;
 execute replace(definition,needle,replacement);
end $$;
notify pgrst,'reload schema';
commit;
