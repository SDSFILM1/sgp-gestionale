create table public.integration_locks(id text primary key,locked_until timestamptz not null default now());
alter table public.integration_locks enable row level security;
revoke all on public.integration_locks from anon,authenticated;
grant all on public.integration_locks to service_role;
create function public.begin_wix_sync() returns boolean language plpgsql security definer set search_path='' as $$
 declare v_time timestamptz;begin
 insert into public.integration_locks(id,locked_until) values('wix',now()-interval '1 second') on conflict do nothing;
 select locked_until into v_time from public.integration_locks where id='wix' for update;
 if v_time>now() then return false;end if;
 if exists(select 1 from public.sync_state where id='wix' and last_success>now()-interval '4 minutes') then return false;end if;
 update public.integration_locks set locked_until=now()+interval '3 minutes' where id='wix';return true;end
$$;
create function public.apply_wix_bookings(p_rows jsonb) returns integer language plpgsql security definer set search_path='' as $$
 declare v jsonb;v_course uuid;v_lesson uuid;v_count integer:=0;v_start timestamptz;v_name text;v_status text;begin
 if jsonb_typeof(p_rows)<>'array' then raise exception 'Prenotazioni non valide';end if;
 for v in select * from jsonb_array_elements(p_rows) loop
  v_start:=nullif(v->>'starts_at','')::timestamptz;v_name:=v->>'name';v_status:=v->>'status';
  select id into v_course from public.courses where wix_service_id=v->>'service_id';
  select id into v_lesson from public.lessons where course_id=v_course and starts_at=v_start;
  insert into public.wix_bookings(id,course_id,lesson_id,name,starts_at,ends_at,status,participants,service_name)
  values(v->>'id',v_course,v_lesson,v_name,v_start,nullif(v->>'ends_at','')::timestamptz,v_status,coalesce((v->>'participants')::integer,1),coalesce(v->>'service_name',''))
  on conflict(id) do update set course_id=excluded.course_id,lesson_id=excluded.lesson_id,name=excluded.name,starts_at=excluded.starts_at,ends_at=excluded.ends_at,status=excluded.status,participants=excluded.participants,service_name=excluded.service_name,updated_at=now();
  -- If a booking moves or is cancelled, only unmarked FUTURE attendance rows are retired.
  update public.lesson_participants p set excluded=true from public.lessons l where p.lesson_id=l.id and p.wix_booking_id=v->>'id'
   and p.status='unmarked' and l.starts_at>=now() and (v_status<>'CONFIRMED' or p.lesson_id is distinct from v_lesson);
  if v_lesson is not null and v_status='CONFIRMED' then
   insert into public.lesson_participants(lesson_id,name,source,wix_booking_id)
   values(v_lesson,v_name,'wix',v->>'id') on conflict(lesson_id,wix_booking_id) do update set excluded=false,name=excluded.name
   where public.lesson_participants.status='unmarked' and v_start>=now();
  end if;v_count:=v_count+1;
 end loop;
 insert into public.sync_state(id,last_success,last_error) values('wix',now(),null) on conflict(id) do update set last_success=now(),last_error=null;
 update public.integration_locks set locked_until=now() where id='wix';return v_count;end
$$;
revoke execute on function public.begin_wix_sync(),public.apply_wix_bookings(jsonb) from public,anon,authenticated;
grant execute on function public.begin_wix_sync(),public.apply_wix_bookings(jsonb) to service_role;
