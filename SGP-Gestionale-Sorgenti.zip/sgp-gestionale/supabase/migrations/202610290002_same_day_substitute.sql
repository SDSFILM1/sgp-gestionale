begin;
-- Roll calls are often completed immediately after class. Allow a same-day
-- substitute registration until midnight in Rome, without opening older dates.
do $$
declare definition text;
needle text:='if not found or v_lesson.ends_at<=now() then raise exception ''La lezione è terminata o non esiste'';end if;';
replacement text:='if not found then raise exception ''La lezione non esiste'';end if;
 if (v_lesson.ends_at at time zone ''Europe/Rome'')::date < (now() at time zone ''Europe/Rome'')::date then
  raise exception ''Puoi segnarti come supplente per le lezioni di oggi o future. Per i giorni precedenti contatta la segreteria'';
 end if;';
begin
 select pg_get_functiondef('public.set_extra_substitute(uuid,boolean)'::regprocedure) into definition;
 if position(needle in definition)=0 then raise exception 'Definizione supplenze non riconosciuta: nessuna modifica applicata';end if;
 execute replace(definition,needle,replacement);
end $$;
notify pgrst,'reload schema';
commit;
