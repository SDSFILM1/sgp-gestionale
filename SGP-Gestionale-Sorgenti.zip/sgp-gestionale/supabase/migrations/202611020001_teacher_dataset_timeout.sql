begin;
-- Restrict the expensive student authorization check to actual package holders.
-- The former join allowed the planner to check every student before discovering
-- the empty package table. Teacher accounts then exceeded the API time limit.
create or replace function public.staff_student_packages() returns jsonb
language plpgsql stable security definer set search_path='' as $$
declare result jsonb;
begin
 if not exists(select 1 from public.student_packages) then return '[]'::jsonb;end if;
 with package_rows as materialized (
  select p.* from public.student_packages p join public.students s on s.id=p.student_id where not s.archived
 ), eligible as materialized (
  select p.* from package_rows p where public.can_student(p.student_id)
 )
 select coalesce(jsonb_agg(jsonb_build_object('student_id',p.student_id,'total',p.total,'valid_from',p.valid_from,
  'booked',a.booked,'attended',a.attended,'remaining',greatest(p.total-a.booked,0),
  'linked',exists(select 1 from public.student_wix_links k where k.student_id=p.student_id))),'[]'::jsonb)
 into result from eligible p
 cross join lateral (
  select count(*)::integer booked,count(*) filter(where exists(
   select 1 from public.lesson_participants lp join public.lessons l on l.id=lp.lesson_id
   where lp.lesson_id=q.lesson_id and not lp.excluded and lp.status='present' and not l.cancelled
   and not exists(select 1 from public.lesson_participants x where x.lesson_id=q.lesson_id and x.student_id=p.student_id and x.source='manual' and x.excluded)
   and (lp.student_id=p.student_id or exists(select 1 from public.wix_bookings b join public.student_wix_links k on k.wix_person_id=b.wix_person_id where b.id=lp.wix_booking_id and k.student_id=p.student_id))
  ))::integer attended
  from (select distinct coalesce(b.lesson_id::text,b.id) key,b.lesson_id
   from public.wix_bookings b join public.student_wix_links k on k.wix_person_id=b.wix_person_id
   left join public.lessons l on l.id=b.lesson_id
   where k.student_id=p.student_id and b.source_present and b.status='CONFIRMED'
   and (b.starts_at at time zone 'Europe/Rome')::date>=p.valid_from and not coalesce(l.cancelled,false)) q
 )a;
 return result;
end $$;
revoke all on function public.staff_student_packages() from public,anon,authenticated;
notify pgrst,'reload schema';
commit;
