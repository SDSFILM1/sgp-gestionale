import {createClient} from 'npm:@supabase/supabase-js@2';
const url=Deno.env.get('SUPABASE_URL')!,key=Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const admin=createClient(url,key,{auth:{persistSession:false,autoRefreshToken:false}});
const headers={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization, x-client-info, apikey, content-type','Access-Control-Allow-Methods':'POST, OPTIONS','Content-Type':'application/json'};
const json=(v:unknown,status=200)=>new Response(JSON.stringify(v),{status,headers});
const ok=(r:any)=>{if(r.error)throw Error(r.error.message);return r.data;};
Deno.serve(async(req)=>{
 if(req.method==='OPTIONS')return new Response('ok',{headers});
 if(req.method!=='POST')return json({error:'Metodo non consentito'},405);
 try{
  const token=req.headers.get('Authorization')?.replace(/^Bearer /i,'');if(!token)return json({error:'Accedi per continuare'},401);
  const {data,error}=await admin.auth.getUser(token);if(error||!data.user)return json({error:'Sessione scaduta'},401);
  const p=ok(await admin.from('profiles').select('*').eq('id',data.user.id).single());if(!p.active)return json({error:'Account disattivato'},403);
  const b=await req.json();
  if(b.action==='change-password'){
   if(typeof b.password!=='string'||b.password.length<12||b.password.length>128)throw Error('La password deve avere tra 12 e 128 caratteri');
   ok(await admin.auth.admin.updateUserById(p.id,{password:b.password}));
   ok(await admin.from('profiles').update({must_change_password:false}).eq('id',p.id));return json({ok:true});
  }
  if(p.role!=='secretary'||p.must_change_password)return json({error:'Accesso riservato alla segreteria'},403);
  if(b.action==='create'){
   if(typeof b.name!=='string'||!b.name.trim()||b.name.length>200||typeof b.email!=='string'||!b.email.includes('@'))throw Error('Nome o email non validi');
   if(typeof b.password!=='string'||b.password.length<12||b.password.length>128)throw Error('Password temporanea non valida');
   const created=ok(await admin.auth.admin.createUser({email:b.email.trim(),password:b.password,email_confirm:true}));
   try{ok(await admin.from('profiles').insert({id:created.user.id,name:b.name.trim(),email:b.email.trim(),role:'teacher',must_change_password:true}));}
   catch(e){await admin.auth.admin.deleteUser(created.user.id);throw e;}
   return json({ok:true});
  }
  const target=ok(await admin.from('profiles').select('id,role').eq('id',b.id).single());
  if(target.role!=='teacher')throw Error('Puoi gestire soltanto account insegnanti');
  if(b.action==='toggle'){
   if(typeof b.active!=='boolean')throw Error('Stato non valido');
   // RLS blocks existing access tokens as soon as active becomes false.
   ok(await admin.from('profiles').update({active:b.active}).eq('id',target.id));
   ok(await admin.auth.admin.updateUserById(target.id,{ban_duration:b.active?'none':'876000h'}));return json({ok:true});
  }
  if(b.action==='reset'){
   if(typeof b.password!=='string'||b.password.length<12||b.password.length>128)throw Error('Password temporanea non valida');
   ok(await admin.from('profiles').update({must_change_password:true}).eq('id',target.id));
   ok(await admin.auth.admin.updateUserById(target.id,{password:b.password}));return json({ok:true});
  }
  throw Error('Operazione non riconosciuta');
 }catch(e){return json({error:e instanceof Error?e.message:'Operazione non riuscita'},400);}
});
