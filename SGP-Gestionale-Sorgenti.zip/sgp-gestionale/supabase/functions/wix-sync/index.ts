import{createClient}from'npm:@supabase/supabase-js@2';
import{normalizeBooking,normalizeOrder,normalizeBalance}from'./normalization.ts';
const admin=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,{auth:{persistSession:false}});
const headers={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization, x-client-info, apikey, content-type','Access-Control-Allow-Methods':'POST, OPTIONS','Content-Type':'application/json'};
const json=(v:unknown,status=200)=>new Response(JSON.stringify(v),{status,headers});
const ok=(r:any)=>{if(r.error)throw Error(r.error.message);return r.data;};
class WixReadError extends Error{constructor(readonly status:number){super('Lettura Wix non riuscita ('+status+'). Verifica le autorizzazioni della chiave.');}}
async function wix(path:string,body?:unknown,query?:Record<string,string>){
 const key=Deno.env.get('WIX_API_KEY'),site=Deno.env.get('WIX_SITE_ID');if(!key||!site)throw Error('Collegamento Wix non ancora configurato.');
 // Only these read/query endpoints may be used: no mutations to Wix.
 const contactRead=/^\/contacts\/v5\/contacts\/[0-9a-f-]{36}$/i.test(path);
 if(!contactRead&&!['/bookings/v2/services/query','/_api/bookings-reader/v2/extended-bookings/query','/pricing-plans/v2/orders','/benefit-programs/v1/balances/query'].includes(path))throw Error('Operazione Wix non consentita');
 const method=contactRead||path==='/pricing-plans/v2/orders'?'GET':'POST';
 const response=await fetch('https://www.wixapis.com'+path+(query?'?'+new URLSearchParams(query):''),{method,headers:{Authorization:key,'wix-site-id':site,'Content-Type':'application/json'},...(method==='POST'?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(20000)});
 if(!response.ok)throw new WixReadError(response.status);return await response.json();
}
Deno.serve(async(req)=>{
 if(req.method==='OPTIONS')return new Response('ok',{headers});if(req.method!=='POST')return json({error:'Metodo non consentito'},405);let lock=false;
 try{
  const token=req.headers.get('Authorization')?.replace(/^Bearer /i,'');if(!token)return json({error:'Accesso richiesto'},401);
  const cronSecret=Deno.env.get('SGP_CRON_SECRET');const cron=!!cronSecret&&token===cronSecret;
  let secretary=false;
  if(!cron){const {data,error}=await admin.auth.getUser(token);if(error||!data.user)return json({error:'Sessione scaduta'},401);
   const p=ok(await admin.from('profiles').select('*').eq('id',data.user.id).single());if(!p.active||p.must_change_password)return json({error:'Accesso negato'},403);secretary=p.role==='secretary';}
  const b=await req.json();
  if(b.action==='services'){
   if(!secretary)return json({error:'Accesso riservato alla segreteria'},403);
   const services:any[]=[];let offset=0;
   while(true){const result=await wix('/bookings/v2/services/query',{query:{paging:{limit:100,offset}}});const list=result.services||[];services.push(...list.filter((s:any)=>s.type==='CLASS'||s.type==='COURSE').map((s:any)=>({id:s.id,name:s.name})));if(list.length<100)break;offset+=100;if(offset>10000)throw Error('Troppi servizi: sincronizzazione interrotta');}
   return json({services});
  }
  if(b.action!=='sync')throw Error('Operazione non riconosciuta');
  if(!Deno.env.get('WIX_API_KEY'))throw Error('Collegamento Wix non ancora configurato.');
  lock=ok(await admin.rpc('begin_wix_sync'));if(!lock)return json({ok:true,skipped:true});
  const rows:any[]=[];let cursor:string|undefined;const cursors=new Set<string>();const bookingIds=new Set<string>();
  do{const result=await wix('/_api/bookings-reader/v2/extended-bookings/query',{query:{cursorPaging:{limit:100,...(cursor?{cursor}:{})}}});
   if(!Array.isArray(result.extendedBookings))throw Error('Risposta prenotazioni Wix non valida: nessun dato parziale salvato');
   for(const e of result.extendedBookings){const row=normalizeBooking(e);if(bookingIds.has(row.id))throw Error('Paginazione prenotazioni Wix non valida: nessun dato parziale salvato');bookingIds.add(row.id);rows.push(row);}
   cursor=result.pagingMetadata?.cursors?.next;if(cursor){if(cursors.has(cursor))throw Error('Paginazione Wix non valida');cursors.add(cursor);}if(rows.length>10000)throw Error('Limite di sincronizzazione raggiunto: nessun dato parziale salvato');
  }while(cursor);
  let orders:any[]|null=[];let warning:string|undefined;
  try{
   const ids=new Set<string>();let offset=0;
   while(true){
    const result=await wix('/pricing-plans/v2/orders',undefined,{limit:'50',offset:String(offset)});
    if(!Array.isArray(result.orders))throw Error('Risposta abbonamenti Wix non valida: nessun dato parziale salvato');
    for(const order of result.orders){const row=normalizeOrder(order);if(ids.has(row.id))throw Error('Paginazione abbonamenti Wix non valida: nessun dato parziale salvato');ids.add(row.id);orders.push(row);}
    if(orders.length>10000)throw Error('Limite abbonamenti Wix raggiunto: nessun dato parziale salvato');
    if(result.orders.length<50)break;offset+=50;
   }
  }catch(error){
   // A Bookings-only key remains usable. Null means unknown, not an empty subscription list.
   if(!(error instanceof WixReadError)||error.status!==403)throw error;
   orders=null;warning='Le prenotazioni Wix sono aggiornate. Per controllare scadenze e avvisi degli abbonamenti, abilita il permesso «Read Orders» della chiave Wix.';
  }
  let balances:any[]|null=null,contacts:any[]|null=null;
  if(orders){
   try{
    balances=[];let next:string|undefined;const seen=new Set<string>();const ids=new Set<string>();
    do{const page=await wix('/benefit-programs/v1/balances/query',{query:{cursorPaging:{limit:100,...(next?{cursor:next}:{})}}});
     if(!Array.isArray(page.balances))throw Error('Risposta saldi Wix non valida');
     for(const b of page.balances){const row=normalizeBalance(b);if(ids.has(row.id))throw Error('Saldi Wix duplicati nella paginazione');ids.add(row.id);balances.push(row);}
     next=page.metadata?.cursors?.next;if(next){if(seen.has(next))throw Error('Paginazione saldi Wix ripetuta');seen.add(next);}if(balances.length>10000)throw Error('Troppi saldi Wix');
    }while(next);
   }catch(error){balances=null;warning='Prenotazioni aggiornate; saldi Wix non aggiornati. Verifica i permessi di lettura.';}
   try{
    contacts=[];const contactIds=[...new Set(orders.map(o=>o.contact_id).filter(Boolean))] as string[];
    for(let i=0;i<contactIds.length;i+=5){const results=await Promise.allSettled(contactIds.slice(i,i+5).map(async id=>{
     const response=await wix('/contacts/v5/contacts/'+id);const c=response.contact;
     if(c?.id!==id)throw Error('Identita contatto Wix non valida');
     return {contact_id:id,name:[c.name?.first,c.name?.last].filter(Boolean).join(' ').trim()||'Nome non disponibile'};
    }));for(const result of results){if(result.status==='rejected'){if(result.reason instanceof WixReadError&&result.reason.status===404)continue;throw result.reason;}contacts.push(result.value);}}
   }catch(error){contacts=null;warning=[warning,'Contatti Wix non aggiornati. Verifica i permessi di lettura.'].filter(Boolean).join(' ');}
  }
  const count=ok(await admin.rpc('apply_wix_snapshot',{p_rows:rows,p_orders:orders,p_balances:balances,p_contacts:contacts}));return json({ok:true,count,...(warning?{warning}:{})});
 }catch(e){const message=e instanceof Error?e.message:'Sincronizzazione non riuscita';if(lock){await admin.from('sync_state').upsert({id:'wix',last_error:message});await admin.from('integration_locks').update({locked_until:new Date().toISOString()}).eq('id','wix');}return json({error:message},400);}
});
