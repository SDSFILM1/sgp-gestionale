import{createClient}from'npm:@supabase/supabase-js@2';
const admin=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,{auth:{persistSession:false}});
const headers={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization, x-client-info, apikey, content-type','Access-Control-Allow-Methods':'POST, OPTIONS','Content-Type':'application/json'};
const json=(v:unknown,status=200)=>new Response(JSON.stringify(v),{status,headers});
const ok=(r:any)=>{if(r.error)throw Error(r.error.message);return r.data;};
async function wix(path:string,body:unknown){
 const key=Deno.env.get('WIX_API_KEY'),site=Deno.env.get('WIX_SITE_ID');if(!key||!site)throw Error('Collegamento Wix non ancora configurato.');
 // Only these two read/query endpoints may be used: no mutations to Wix.
 if(!['/bookings/v2/services/query','/_api/bookings-reader/v2/extended-bookings/query'].includes(path))throw Error('Operazione Wix non consentita');
 const response=await fetch('https://www.wixapis.com'+path,{method:'POST',headers:{Authorization:key,'wix-site-id':site,'Content-Type':'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(20000)});
 if(!response.ok)throw Error('Lettura Wix non riuscita ('+response.status+'). Verifica le autorizzazioni della chiave.');return await response.json();
}
Deno.serve(async(req)=>{
 if(req.method==='OPTIONS')return new Response('ok',{headers});if(req.method!=='POST')return json({error:'Metodo non consentito'},405);let lock=false;
 try{
  const token=req.headers.get('Authorization')?.replace(/^Bearer /i,'');if(!token)return json({error:'Accesso richiesto'},401);
  const cronSecret=Deno.env.get('SGP_CRON_SECRET');const cron=!!cronSecret&&token===cronSecret;
  let secretary=false;
  if(!cron){const {data,error}=await admin.auth.getUser(token);if(error||!data.user)return json({error:'Sessione scaduta'},401);
   const p=ok(await admin.from('profiles').select('*').eq('id',data.user.id).single());if(!p.active||p.must_change_password)return json({error:'Accesso negato'},403);secretary=p.role==='secretary';}
  const b=await req.json();
  if(b.action==='services'){
   if(!secretary)return json({error:'Accesso riservato alla segreteria'},403);
   const services:any[]=[];let offset=0;
   while(true){const result=await wix('/bookings/v2/services/query',{query:{paging:{limit:100,offset}}});const list=result.services||[];services.push(...list.filter((s:any)=>s.type==='CLASS'||s.type==='COURSE').map((s:any)=>({id:s.id,name:s.name})));if(list.length<100)break;offset+=100;if(offset>10000)throw Error('Troppi servizi: sincronizzazione interrotta');}
   return json({services});
  }
  if(b.action!=='sync')throw Error('Operazione non riconosciuta');
  if(!Deno.env.get('WIX_API_KEY'))throw Error('Collegamento Wix non ancora configurato.');
  lock=ok(await admin.rpc('begin_wix_sync'));if(!lock)return json({ok:true,skipped:true});
  const rows:any[]=[];let cursor:string|undefined;const cursors=new Set<string>();
  do{const result=await wix('/_api/bookings-reader/v2/extended-bookings/query',{query:{cursorPaging:{limit:100,...(cursor?{cursor}:{})}}});
   for(const e of result.extendedBookings||[]){const b=e.booking;if(!b?.id)throw Error('Prenotazione Wix priva di identificativo');
    // Course-wide bookings have no individual lesson; leave them unmatched rather than inventing occurrences.
    const slot=b.bookedEntity?.slot;
    rows.push({id:b.id,service_id:slot?.serviceId||b.bookedEntity?.schedule?.serviceId||null,name:[b.contactDetails?.firstName,b.contactDetails?.lastName].filter(Boolean).join(' ')||'Nome non disponibile',starts_at:slot?b.startDate:null,ends_at:slot?b.endDate:null,status:b.status,participants:b.numberOfParticipants||b.totalParticipants||1,service_name:b.bookedEntity?.title||''});
   }
   cursor=result.pagingMetadata?.cursors?.next;if(cursor){if(cursors.has(cursor))throw Error('Paginazione Wix non valida');cursors.add(cursor);}if(rows.length>10000)throw Error('Limite di sincronizzazione raggiunto: nessun dato parziale salvato');
  }while(cursor);
  const count=ok(await admin.rpc('apply_wix_bookings',{p_rows:rows}));return json({ok:true,count});
 }catch(e){const message=e instanceof Error?e.message:'Sincronizzazione non riuscita';if(lock){await admin.from('sync_state').upsert({id:'wix',last_error:message});await admin.from('integration_locks').update({locked_until:new Date().toISOString()}).eq('id','wix');}return json({error:message},400);}
});
