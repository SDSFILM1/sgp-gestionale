// Read-only Wix contracts:
// https://dev.wix.com/docs/api-reference/business-solutions/bookings/bookings/bookings-reader-v2/query-extended-bookings
// https://dev.wix.com/docs/api-reference/business-solutions/pricing-plans/orders/order-management-service-list-orders
const text=(value:unknown)=>typeof value==='string'&&value.trim()?value.trim():null;
const date=(value:unknown)=>typeof value==='string'&&Number.isFinite(Date.parse(value))?new Date(value).toISOString():null;

export function normalizeBooking(extended:any){
 const b=extended.booking;if(!b?.id)throw Error('Prenotazione Wix priva di identificativo');
 // Contact details belong to the booking customer. The creator can instead be a staff member.
 const contact=b.contactDetails;
 const slot=b.bookedEntity?.slot;
 return {id:b.id,service_id:slot?.serviceId||b.bookedEntity?.schedule?.serviceId||null,
  name:[contact?.firstName,contact?.lastName].filter(Boolean).join(' ')||'Nome non disponibile',
  contact_id:text(contact?.contactId),booked_at:date(b.createdDate),
  // Course-wide bookings have no individual lesson; do not invent occurrences.
  starts_at:slot?date(b.startDate):null,ends_at:slot?date(b.endDate):null,
  status:b.status,participants:b.numberOfParticipants||b.totalParticipants||1,service_name:b.bookedEntity?.title||''};
}

export function normalizeOrder(order:any){
 if(!order?.id)throw Error('Abbonamento Wix privo di identificativo');
 return {id:order.id,contact_id:text(order.buyer?.contactId),member_id:text(order.buyer?.memberId),
  status:text(order.status),start_date:date(order.startDate),end_date:date(order.endDate),
  auto_renew_canceled:order.autoRenewCanceled===true,cancellation_effective_at:text(order.cancellation?.effectiveAt),
  plan_name:text(order.planName)};
}

// https://dev.wix.com/docs/api-reference/business-solutions/benefit-programs/balances/query-balances
// Keep Wix's member/pool identity: never join balances by a person's name.
export function normalizeBalance(balance:any){
 const id=text(balance?.id),memberId=text(balance?.beneficiary?.memberId);
 if(!id)throw Error('Saldo Wix privo di identificativo');
 const number=(value:unknown)=>{
  if(typeof value!=='string'&&typeof value!=='number')return null;
  if(String(value).trim()==='')return null;
  const parsed=Number(value);return Number.isFinite(parsed)&&parsed>=0?parsed:null;
 };
 return {id,member_id:memberId,program_id:text(balance.poolInfo?.programId),
  external_program_id:text(balance.poolInfo?.externalProgramId),
  status:text(balance.poolInfo?.status),available:number(balance.amount?.available),
  reserved:number(balance.amount?.reserved),credit_amount:number(balance.poolInfo?.creditAmount),
  updated_at:date(balance.updatedDate)};
}
