import {createClient} from 'npm:@supabase/supabase-js@2';
const admin=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,{auth:{persistSession:false}});
const headers={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'authorization, x-client-info, apikey, content-type','Access-Control-Allow-Methods':'POST, OPTIONS','Content-Type':'application/json'};
const json=(v:unknown,status=200)=>new Response(JSON.stringify(v),{status,headers});
const ok=(r:any)=>{if(r.error)throw Error(r.error.message);return r.data;};
const mimeByExt:Record<string,string>={pdf:'application/pdf',doc:'application/msword',docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document',jpg:'image/jpeg',jpeg:'image/jpeg',png:'image/png',webp:'image/webp',heic:'image/heic'};
function base64(bytes:Uint8Array){let s='';for(let i=0;i<bytes.length;i+=8192)s+=String.fromCharCode(...bytes.subarray(i,i+8192));return btoa(s);}
Deno.serve(async(req)=>{
 if(req.method==='OPTIONS')return new Response('ok',{headers});if(req.method!=='POST')return json({error:'Metodo non consentito'},405);
 let docId:string|undefined;
 try{
  const token=req.headers.get('Authorization')?.replace(/^Bearer /i,'');if(!token)return json({error:'Accesso richiesto'},401);
  const {data,error}=await admin.auth.getUser(token);if(error||!data.user)return json({error:'Sessione scaduta'},401);
  const p=ok(await admin.from('profiles').select('*').eq('id',data.user.id).single());if(!p.active||p.must_change_password)return json({error:'Accesso negato'},403);
  const bridge=Deno.env.get('GOOGLE_DRIVE_BRIDGE_URL');if(!bridge)throw Error('Google Drive non è ancora collegato. Completa la configurazione con la segreteria.');
  const call=async(body:unknown)=>{const response=await fetch(bridge,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(110000)});if(!response.ok)throw Error('Google Drive non raggiungibile');const result=await response.json();if(!result.ok)throw Error(result.error||'Operazione Drive non riuscita');return result;};
  if(req.headers.get('Content-Type')?.includes('multipart/form-data')){
   if(Number(req.headers.get('Content-Length')||0)>22*1024*1024)throw Error('File troppo grande');
   const form=await req.formData(),file=form.get('file');if(!(file instanceof File)||file.size===0||file.size>20*1024*1024)throw Error('Il file deve essere tra 1 byte e 20 MB');
   const ext=file.name.split('.').pop()?.toLowerCase()||'',mime=mimeByExt[ext];if(!mime)throw Error('Formato non supportato. Usa PDF, Word o un’immagine.');
   const name=file.name.replace(/[\x00-\x1f/\\]/g,'_').slice(0,180);const notes=String(form.get('notes')||'').slice(0,2000);
   const d=ok(await admin.from('documents').insert({teacher_id:p.id,name,notes,size:file.size,mime,status:'uploading'}).select().single());docId=d.id;
   const result=await call({action:'upload',token,documentId:d.id,content:base64(new Uint8Array(await file.arrayBuffer()))});
   ok(await admin.from('documents').update({drive_file_id:result.fileId,status:'ready'}).eq('id',d.id));
   docId=undefined;
   const {data:secretaries}=await admin.from('profiles').select('id').eq('role','secretary').eq('active',true);
   if(secretaries?.length)await admin.from('notifications').insert(secretaries.map(s=>({recipient_id:s.id,title:'Nuovo documento',body:p.name+' ha caricato '+name})));
   return json({ok:true,id:d.id});
  }
  const b=await req.json();if(b.action!=='download')throw Error('Operazione non riconosciuta');
  const d=ok(await admin.from('documents').select('*').eq('id',b.id).single());if(p.role!=='secretary'&&d.teacher_id!==p.id)return json({error:'Accesso negato'},403);
  if(d.status!=='ready'||!d.drive_file_id)throw Error('Documento non disponibile');
  const result=await call({action:'download',token,documentId:d.id});return json({ok:true,content:result.content,name:d.name,mime:d.mime});
 }catch(e){if(docId)await admin.from('documents').update({status:'error'}).eq('id',docId);return json({error:e instanceof Error?e.message:'Operazione non riuscita'},400);}
});
