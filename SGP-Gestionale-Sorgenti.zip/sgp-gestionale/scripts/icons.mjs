import {writeFileSync} from 'node:fs';import{deflateSync}from'node:zlib';
const glyphs=['011111000010000100000111100000010000111110','011111000010000101110100011000110001011110','111101000110001111101000010000100000'];
const patterns=['01111100001000001110000010000111110','01111100001000010111100011000101111','11110100011000111110100001000010000'];
function crc(b){let c=0xffffffff;for(const v of b){c^=v;for(let i=0;i<8;i++)c=(c>>>1)^((c&1)?0xedb88320:0);}return(c^0xffffffff)>>>0;}
function chunk(t,b){const type=Buffer.from(t),n=Buffer.alloc(4),end=Buffer.alloc(4);n.writeUInt32BE(b.length);end.writeUInt32BE(crc(Buffer.concat([type,b])));return Buffer.concat([n,type,b,end]);}
for(const size of [192,512]){const row=size*4+1,raw=Buffer.alloc(row*size);const cell=size/25,ox=4*cell,oy=8*cell;
 for(let y=0;y<size;y++)for(let x=0;x<size;x++){let c=[0,102,204,255];for(let g=0;g<3;g++){const px=Math.floor((x-ox-g*6*cell)/cell),py=Math.floor((y-oy)/cell);if(px>=0&&px<5&&py>=0&&py<7&&patterns[g][py*5+px]==='1')c=[255,255,255,255];}if(y>=17*cell&&y<18.5*cell&&x>=4*cell&&x<21*cell)c=[204,0,0,255];raw.set(c,y*row+1+x*4);}
 const ih=Buffer.alloc(13);ih.writeUInt32BE(size,0);ih.writeUInt32BE(size,4);ih[8]=8;ih[9]=6;writeFileSync(new URL('../public/icon-'+size+'.png',import.meta.url),Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',ih),chunk('IDAT',deflateSync(raw)),chunk('IEND',Buffer.alloc(0))]));}
