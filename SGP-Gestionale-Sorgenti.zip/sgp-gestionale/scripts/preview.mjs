import{createServer}from'node:http';import{readFile}from'node:fs/promises';import{resolve,extname,sep}from'node:path';
const root=resolve('dist');const escape=s=>s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;');
const files={'/setup/drive-code':'google-drive/Code.gs','/setup/drive-manifest':'google-drive/appsscript.json','/setup/sql':'supabase/migrations/202609180001_initial.sql','/setup/wix-sql':'supabase/migrations/202609180002_wix.sql','/setup/account-admin':'supabase/functions/account-admin/index.ts','/setup/drive-files':'supabase/functions/drive-files/index.ts','/setup/wix-sync':'supabase/functions/wix-sync/index.ts'};
createServer(async(req,res)=>{try{const path=new URL(req.url,'http://localhost').pathname;
 if(files[path]){const source=await readFile(files[path],'utf8');res.writeHead(200,{'Content-Type':'text/html;charset=utf-8'});res.end('<!doctype html><title>SGP · Configurazione</title><h1>Configurazione SGP</h1><textarea aria-label="Codice configurazione" readonly style="width:95vw;height:80vh">'+escape(source)+'</textarea>');return;}
 const file=resolve(root,'.'+(path==='/'?'/index.html':decodeURIComponent(path)));if(!file.startsWith(root+sep)){res.writeHead(403).end();return;}
 const types={'.html':'text/html;charset=utf-8','.js':'application/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml','.webmanifest':'application/manifest+json'};
 const body=await readFile(file);res.writeHead(200,{'Content-Type':types[extname(file)]||'application/octet-stream','Cache-Control':'no-cache'});res.end(body);
 }catch{res.writeHead(404).end('Not found');}}).listen(4173,'127.0.0.1',()=>console.log('SGP preview: http://127.0.0.1:4173/'));
