import {mkdir,writeFile,readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {resolve} from 'node:path';
const root=resolve('../android-tools');await mkdir(root,{recursive:true});
const jdk=(await (await fetch('https://api.adoptium.net/v3/assets/latest/21/hotspot?architecture=x64&image_type=jdk&os=windows&vendor=eclipse')).json())[0].binary.package;
for(const item of [{name:'jdk.zip',url:jdk.link,hash:jdk.checksum},{name:'sdk.zip',url:'https://dl.google.com/android/repository/commandlinetools-win-15859902_latest.zip',hash:'90ae805d20434428bffcb699c290860f19bb5f66a67e6b330067e3de801fb04a'}]){
 const path=resolve(root,item.name);let bytes;try{bytes=await readFile(path);}catch{}
 if(!bytes||createHash('sha256').update(bytes).digest('hex')!==item.hash){const r=await fetch(item.url);if(!r.ok)throw Error('Download failed '+r.status);bytes=Buffer.from(await r.arrayBuffer());if(createHash('sha256').update(bytes).digest('hex')!==item.hash)throw Error('Checksum mismatch '+item.name);await writeFile(path,bytes);}
 console.log(item.name+' verified '+bytes.length+' bytes');
}
