-- Admin-only maintenance. Caller supplies a temporary approved_student_merges
-- table(drop_id uuid primary key, keep_id uuid), in an explicit transaction.
-- No name-based inference, application RPC or new permissions are introduced.
do $$
declare m record; original jsonb;
begin
 for m in select * from approved_student_merges loop
  if m.drop_id=m.keep_id or not exists(select 1 from public.students where id=m.keep_id and not archived)
   or not exists(select 1 from public.students where id=m.drop_id and not archived) then
   raise exception 'Identita approvate non valide';end if;
  if exists(select 1 from public.lesson_participants a join public.lesson_participants b on a.lesson_id=b.lesson_id
   where a.student_id=m.keep_id and b.student_id=m.drop_id and a.status<>b.status
   and a.status<>'unmarked' and b.status<>'unmarked') then raise exception 'Presenze in conflitto: unione sospesa';end if;
  if exists(select 1 from public.student_packages where student_id=m.drop_id)
   and exists(select 1 from public.student_packages where student_id=m.keep_id) then
   raise exception 'Due pacchetti: revisione necessaria';end if;
  select jsonb_build_object(
   'students',(select jsonb_agg(to_jsonb(s)) from public.students s where s.id in(m.keep_id,m.drop_id)),
   'enrollments',(select jsonb_agg(to_jsonb(e)) from public.enrollments e where e.student_id in(m.keep_id,m.drop_id)),
   'participants',(select jsonb_agg(to_jsonb(p)) from public.lesson_participants p where p.student_id in(m.keep_id,m.drop_id)),
   'notes',(select jsonb_agg(to_jsonb(n)) from public.student_staff_notes n where n.student_id in(m.keep_id,m.drop_id)),
   'links',(select jsonb_agg(to_jsonb(k)) from public.student_wix_links k where k.student_id in(m.keep_id,m.drop_id)),
   'packages',(select jsonb_agg(to_jsonb(k)) from public.student_packages k where k.student_id in(m.keep_id,m.drop_id))) into original;
  insert into public.enrollments(course_id,student_id,valid_from,valid_to)
  select course_id,m.keep_id,valid_from,valid_to from public.enrollments where student_id=m.drop_id
  on conflict(course_id,student_id,valid_from) do update set valid_to=
   case when public.enrollments.valid_to is null or excluded.valid_to is null then null
    else greatest(public.enrollments.valid_to,excluded.valid_to) end;
  delete from public.enrollments where student_id=m.drop_id;
  update public.lesson_participants k set
   status=case when k.status='unmarked' then d.status else k.status end,
   excluded=k.excluded and d.excluded,updated_at=greatest(k.updated_at,d.updated_at),
   updated_by=case when k.status='unmarked' then d.updated_by else k.updated_by end
  from public.lesson_participants d where k.student_id=m.keep_id and d.student_id=m.drop_id and k.lesson_id=d.lesson_id;
  delete from public.lesson_participants d where d.student_id=m.drop_id
   and exists(select 1 from public.lesson_participants k where k.lesson_id=d.lesson_id and k.student_id=m.keep_id);
  update public.lesson_participants set student_id=m.keep_id where student_id=m.drop_id;
  update public.student_staff_notes set student_id=m.keep_id where student_id=m.drop_id;
  update public.student_wix_links set student_id=m.keep_id where student_id=m.drop_id;
  update public.student_packages set student_id=m.keep_id where student_id=m.drop_id;
  update public.jotform_registrations set student_id=m.keep_id where student_id=m.drop_id;
  update public.students k set birth_date=coalesce(k.birth_date,d.birth_date),
   notes=case when trim(k.notes)='' then d.notes when trim(d.notes)='' or k.notes=d.notes then k.notes else k.notes||E'\n'||d.notes end
  from public.students d where k.id=m.keep_id and d.id=m.drop_id;
  update public.students set archived=true where id=m.drop_id;
  insert into public.audit_log(actor_id,event,entity_id,before_value,after_value)
  values(auth.uid(),'approved_student_merge',m.keep_id::text,original,jsonb_build_object('archived_duplicate',m.drop_id));
 end loop;
end $$;
