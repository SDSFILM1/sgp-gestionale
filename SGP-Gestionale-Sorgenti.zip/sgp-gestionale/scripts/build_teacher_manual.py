from pathlib import Path
from PIL import Image as PILImage, ImageDraw, ImageFont
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, PageBreak, Table, TableStyle, KeepTogether

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT.parents[1] / "outputs" / "Manuale-insegnanti-SGP.pdf"
ASSETS = ROOT / "work" / "manual-assets"
ASSETS.mkdir(parents=True, exist_ok=True)
ICON = ROOT / "assets" / "app-icon-sgp.png"
BLUE, NAVY, TEAL, RED, GOLD = "#1378B8", "#17384E", "#13816D", "#C83C46", "#E5B72E"

def font(size, bold=False):
    p = Path("C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf")
    return ImageFont.truetype(str(p), size)

def rounded(draw, xy, radius=24, fill="white", outline="#DDE7EC", width=3):
    draw.rounded_rectangle(xy, radius=radius, fill=fill, outline=outline, width=width)

def txt(draw, xy, value, size=24, color=NAVY, bold=False, anchor=None):
    draw.text(xy, value, font=font(size,bold), fill=color, anchor=anchor)

def phone(draw, x, y, w, h, title, accent=BLUE):
    rounded(draw,(x,y,x+w,y+h),30,"#FFFFFF",NAVY,4)
    draw.rounded_rectangle((x+14,y+14,x+w-14,y+h-14),22,fill="#F5F9FA")
    draw.rounded_rectangle((x+w*.37,y+9,x+w*.63,y+20),7,fill=NAVY)
    draw.rectangle((x+14,y+35,x+w-14,y+87),fill=accent)
    txt(draw,(x+w/2,y+61),title,20,"white",True,"mm")
    return (x+32,y+112,x+w-32,y+h-32)

def button(draw, x1,y1,x2,y2,label,fill=BLUE,color="white"):
    draw.rounded_rectangle((x1,y1,x2,y2),14,fill=fill)
    txt(draw,((x1+x2)/2,(y1+y2)/2),label,19,color,True,"mm")

def caption(draw,x,y,n,label):
    draw.ellipse((x,y,x+44,y+44),fill=GOLD)
    txt(draw,(x+22,y+22),str(n),21,NAVY,True,"mm")
    txt(draw,(x+56,y+22),label,20,NAVY,True,"lm")

def save_android():
    im=PILImage.new("RGB",(1400,760),"#EDF5F6");d=ImageDraw.Draw(im)
    xs=[55,500,945]
    a=phone(d,xs[0],58,400,600,"Pagina installazione")
    txt(d,(a[0],a[1]+20),"SGP sul telefono",30,NAVY,True);button(d,a[0],a[1]+105,a[2],a[1]+170,"Scarica app Android")
    txt(d,(a[0],a[1]+205),"Apri il file APK scaricato",20,"#4E6878")
    b=phone(d,xs[1],58,400,600,"Sicurezza Android",RED)
    txt(d,(b[0],b[1]+15),"Per installare questa app",22,NAVY,True);txt(d,(b[0],b[1]+55),"autorizza questa fonte.",22,NAVY)
    button(d,b[0],b[1]+130,b[2],b[1]+195,"Impostazioni",fill="#E7EEF2",color=NAVY)
    d.rectangle((b[0],b[1]+250,b[0]+38,b[1]+288),outline=TEAL,width=4);txt(d,(b[0]+58,b[1]+269),"Consenti da questa fonte",19,NAVY,False,"lm")
    c=phone(d,xs[2],58,400,600,"Installa SGP",TEAL)
    icon=PILImage.open(ICON).convert("RGB").resize((150,150));im.paste(icon,(xs[2]+125,220));txt(d,(xs[2]+200,405),"SGP Gestionale",26,NAVY,True,"mm");button(d,xs[2]+82,470,xs[2]+318,530,"Installa",fill=TEAL)
    for i,(x,l) in enumerate(zip(xs,["Scarica l'APK","Autorizza la fonte","Installa"]),1):caption(d,x+40,682,i,l)
    p=ASSETS/"android-install.png";im.save(p);return p

def save_iphone():
    im=PILImage.new("RGB",(1400,760),"#EDF5F6");d=ImageDraw.Draw(im);xs=[55,500,945]
    a=phone(d,xs[0],58,400,600,"Safari");txt(d,(a[0],a[1]+12),"sdsfilm1.github.io",19,"#637884");rounded(d,(a[0],a[1]+55,a[2],a[1]+290),18,"white");txt(d,((a[0]+a[2])/2,a[1]+115),"SGP Gestionale",29,NAVY,True,"mm");button(d,a[0]+30,a[1]+165,a[2]-30,a[1]+222,"Apri il gestionale")
    b=phone(d,xs[1],58,400,600,"Condividi",BLUE);d.line((b[0]+40,b[1]+75,b[0]+40,b[1]+25),fill=BLUE,width=5);d.line((b[0]+40,b[1]+25,b[0]+25,b[1]+43),fill=BLUE,width=5);d.line((b[0]+40,b[1]+25,b[0]+55,b[1]+43),fill=BLUE,width=5);txt(d,(b[0]+95,b[1]+62),"Tocca Condividi",22,NAVY,True,"lm");rounded(d,(b[0],b[1]+140,b[2],b[1]+220),15,"white");txt(d,(b[0]+24,b[1]+180),"+  Aggiungi alla schermata Home",19,NAVY,True,"lm")
    c=phone(d,xs[2],58,400,600,"Schermata Home",TEAL);icon=PILImage.open(ICON).convert("RGB").resize((180,180));im.paste(icon,(xs[2]+110,190));txt(d,(xs[2]+200,408),"SGP",23,NAVY,True,"mm");button(d,xs[2]+105,475,xs[2]+295,530,"Apri",fill=TEAL)
    for i,(x,l) in enumerate(zip(xs,["Apri in Safari","Usa Condividi","Aggiungi e apri"]),1):caption(d,x+40,682,i,l)
    p=ASSETS/"iphone-install.png";im.save(p);return p

def save_login():
    im=PILImage.new("RGB",(1200,700),"#EEF5F6");d=ImageDraw.Draw(im);x=360
    body=phone(d,x,35,480,620,"SGP Area riservata",TEAL);txt(d,(body[0],body[1]+22),"Email",18,NAVY,True);rounded(d,(body[0],body[1]+55,body[2],body[1]+112),12,"white");txt(d,(body[0]+15,body[1]+84),"nome@esempio.it",18,"#6B7C86",False,"lm");txt(d,(body[0],body[1]+145),"Password",18,NAVY,True);rounded(d,(body[0],body[1]+178,body[2],body[1]+235),12,"white");txt(d,(body[0]+15,body[1]+207),"••••••••••••",22,"#6B7C86",False,"lm");d.rectangle((body[0],body[1]+270,body[0]+30,body[1]+300),outline=TEAL,width=4);txt(d,(body[0]+46,body[1]+285),"Rimani connesso",19,NAVY,True,"lm");button(d,body[0],body[1]+335,body[2],body[1]+400,"Accedi",fill=TEAL)
    txt(d,(600,674),"Le credenziali vengono fornite dalla segreteria",21,NAVY,True,"mm");p=ASSETS/"login.png";im.save(p);return p

def save_calendar():
    im=PILImage.new("RGB",(1200,700),"#F1F7F8");d=ImageDraw.Draw(im);x=300;body=phone(d,x,30,600,630,"Calendario",TEAL);txt(d,(body[0],body[1]+8),"Le tue lezioni",26,NAVY,True);y=body[1]+70
    for day,num,sel in [("LUN",21,True),("MAR",22,False),("MER",23,False),("GIO",24,False),("VEN",25,False)]:
        fill=TEAL if sel else "white";col="white" if sel else NAVY;rounded(d,(body[0],y,body[0]+80,y+92),12,fill,fill);txt(d,(body[0]+40,y+24),day,14,col,True,"mm");txt(d,(body[0]+40,y+61),str(num),25,col,True,"mm");body=(body[0]+90,body[1],body[2],body[3])
    bx=x+32;rounded(d,(bx,y+135,x+568,y+325),18,"white");txt(d,(bx+22,y+165),"16:00 - 17:00",18,TEAL,True);txt(d,(bx+22,y+210),"Acro Gym",29,NAVY,True);txt(d,(bx+22,y+255),"Palestra principale",18,"#637884");button(d,bx+325,y+232,bx+505,y+288,"Apri lezione",fill=TEAL)
    txt(d,(600,674),"Tocca la lezione per disponibilità, appello e dettagli",21,NAVY,True,"mm");p=ASSETS/"calendar.png";im.save(p);return p

def save_attendance():
    im=PILImage.new("RGB",(1400,760),"#F0F7F7");d=ImageDraw.Draw(im);x=280;body=phone(d,x,25,840,680,"Appello Acro Gym",TEAL);x1=body[0]; y=body[1]+5
    txt(d,(x1,y),"Nome e cognome",19,NAVY,True);txt(d,(body[2]-190,y),"Presente",16,TEAL,True,"mm");txt(d,(body[2]-70,y),"Assente",16,RED,True,"mm");y+=48
    names=[("Anna Rossi",True),("Luca Bianchi",True),("Sara Verdi",False),("Marco Neri",True)]
    for name,present in names:
        d.line((x1,y-10,body[2],y-10),fill="#DCE7E9",width=2);txt(d,(x1,y+20),name,22,NAVY,True,"lm")
        for cx,chosen,col,sym in [(body[2]-190,present,TEAL,"V"),(body[2]-70,not present,RED,"X")]:
            fill="#DFF3EC" if chosen and col==TEAL else "#FFE8E8" if chosen else "white";d.rounded_rectangle((cx-36,y-15,cx+36,y+57),12,fill=fill,outline=col if chosen else "#BDCBD1",width=4);txt(d,(cx,y+19),sym,35,col if chosen else "#9AAAB1",True,"mm")
        y+=94
    button(d,x1+150,y+15,body[2]-150,y+78,"Salva appello",fill=TEAL);txt(d,(700,735),"Tutti i non ancora segnati partono presenti: seleziona solo chi manca",21,NAVY,True,"mm");p=ASSETS/"attendance.png";im.save(p);return p

def save_tools():
    im=PILImage.new("RGB",(1400,760),"#EEF5F6");d=ImageDraw.Draw(im);xs=[55,500,945]
    a=phone(d,xs[0],58,400,600,"Disponibilità",TEAL);txt(d,(xs[0]+55,210),"Ci sarai?",28,NAVY,True);button(d,xs[0]+55,285,xs[0]+345,345,"Ci sono",fill=TEAL);button(d,xs[0]+55,370,xs[0]+345,430,"Non ci sono",fill=RED);button(d,xs[0]+55,455,xs[0]+345,515,"Da confermare",fill="#E9B52C",color=NAVY)
    b=phone(d,xs[1],58,400,600,"Documenti",BLUE);txt(d,(xs[1]+55,210),"Invia un file",28,NAVY,True);txt(d,(xs[1]+55,270),"PDF, Word o immagine",19,"#637884");button(d,xs[1]+55,345,xs[1]+345,410,"Carica documento");txt(d,(xs[1]+55,465),"Il file arriva alla segreteria",18,NAVY)
    c=phone(d,xs[2],58,400,600,"Impostazioni",TEAL);txt(d,(xs[2]+55,205),"Accesso facile",28,NAVY,True);d.rectangle((xs[2]+55,285,xs[2]+91,321),outline=TEAL,width=4);txt(d,(xs[2]+110,303),"Rimani connesso",18,NAVY,True,"lm");d.rectangle((xs[2]+55,370,xs[2]+91,406),outline=TEAL,width=4);txt(d,(xs[2]+110,388),"Dati biometrici",18,NAVY,True,"lm");txt(d,(xs[2]+55,455),"Biometria: app Android",18,"#637884")
    p=ASSETS/"tools.png";im.save(p);return p

android,iphone,login,calendar,attendance,tools=save_android(),save_iphone(),save_login(),save_calendar(),save_attendance(),save_tools()

styles=getSampleStyleSheet()
styles.add(ParagraphStyle(name="TitleSGP",parent=styles["Title"],fontName="Helvetica-Bold",fontSize=24,leading=29,textColor=colors.black,spaceAfter=5,alignment=TA_LEFT))
styles.add(ParagraphStyle(name="Sub",parent=styles["Normal"],fontName="Helvetica",fontSize=11,leading=15,textColor=colors.HexColor("#425D6A"),spaceAfter=8))
styles.add(ParagraphStyle(name="H1SGP",parent=styles["Heading1"],fontName="Helvetica-Bold",fontSize=19,leading=23,textColor=colors.black,spaceBefore=3,spaceAfter=10))
styles.add(ParagraphStyle(name="H2SGP",parent=styles["Heading2"],fontName="Helvetica-Bold",fontSize=13,leading=17,textColor=colors.black,spaceBefore=7,spaceAfter=5))
styles.add(ParagraphStyle(name="BodySGP",parent=styles["BodyText"],fontName="Helvetica",fontSize=10.5,leading=15,textColor=colors.HexColor(NAVY),spaceAfter=6))
styles.add(ParagraphStyle(name="Step",parent=styles["BodyText"],fontName="Helvetica",fontSize=10.2,leading=14.5,textColor=colors.HexColor(NAVY),leftIndent=12,firstLineIndent=-12,spaceAfter=5))
styles.add(ParagraphStyle(name="Small",parent=styles["BodyText"],fontName="Helvetica",fontSize=8.8,leading=12,textColor=colors.HexColor("#526D79")))

def P(t,style="BodySGP"): return Paragraph(t,styles[style])
def steps(items): return [P(f"<b>{i}.</b> {v}","Step") for i,v in enumerate(items,1)]
def img(path,w): return Image(str(path),width=w,height=w*PILImage.open(path).height/PILImage.open(path).width)
def page_header(canvas,doc):
    canvas.saveState();canvas.setFillColor(colors.HexColor(TEAL));canvas.rect(0,A4[1]-5*mm,A4[0],5*mm,fill=1,stroke=0)
    canvas.setFont("Helvetica",8);canvas.setFillColor(colors.HexColor("#617984"));canvas.drawString(18*mm,10*mm,"SGP Gestionale - Manuale per le insegnanti");canvas.drawRightString(A4[0]-18*mm,10*mm,f"Pagina {doc.page}");canvas.restoreState()

doc=SimpleDocTemplate(str(OUT),pagesize=A4,rightMargin=18*mm,leftMargin=18*mm,topMargin=15*mm,bottomMargin=17*mm,title="Manuale SGP per le insegnanti",author="Società Ginnastica Pordenonese")
story=[]
story += [Table([[Image(str(ICON),28*mm,28*mm),P("Manuale SGP per le insegnanti","TitleSGP")]],colWidths=[35*mm,135*mm],style=TableStyle([('VALIGN',(0,0),(-1,-1),'MIDDLE'),('LEFTPADDING',(0,0),(-1,-1),0),('RIGHTPADDING',(0,0),(-1,-1),0)])),P("Installazione, accesso, calendario, disponibilità, appello e documenti.","Sub"),P("Installare SGP sul telefono","H1SGP"),P("Apri <link href='https://sdsfilm1.github.io/sgp-gestionale/installa.html' color='#1378B8'><b>la pagina di installazione SGP</b></link>. Serve una connessione Internet.")]
story += [P("Android","H2SGP")]+steps(["Tocca <b>Scarica l'app Android</b> e apri il file APK.","Se compare il blocco di sicurezza, tocca <b>Impostazioni</b> e abilita <b>Consenti da questa fonte</b> solo per il browser o l'app File usata per il download.","Torna indietro, tocca <b>Installa</b> e poi <b>Apri</b>. Dopo l'installazione puoi disattivare di nuovo l'autorizzazione alla fonte."])+[img(android,174*mm),P("La posizione esatta delle voci può cambiare leggermente tra Samsung, Xiaomi, Motorola e altri telefoni. Non disattivare Play Protect e non installare APK ricevuti da fonti diverse dal link SGP.","Small")]
story += [PageBreak(),P("Installare su iPhone","H1SGP"),P("Su iPhone non si usa un file APK: il gestionale si aggiunge dalla pagina web.")]+steps(["Apri <link href='https://sdsfilm1.github.io/sgp-gestionale/' color='#1378B8'><b>il sito SGP</b></link> con <b>Safari</b>.","Tocca il pulsante <b>Condividi</b> (quadrato con freccia verso l'alto).", "Scorri e scegli <b>Aggiungi alla schermata Home</b>, quindi tocca <b>Aggiungi</b>.","Apri l'icona SGP dalla schermata Home."])+[Spacer(1,3*mm),img(iphone,174*mm),P("Se non trovi la voce, scorri il menu Condividi verso il basso. L'accesso biometrico integrato è nell'app Android; su iPhone puoi usare il riempimento password e mantenere la sessione.","Small")]
story += [PageBreak(),P("Primo accesso","H1SGP"),P("La segreteria fornisce email e password temporanea. Al primo accesso l'app può chiedere di scegliere una nuova password.")]+steps(["Inserisci email e password.","Lascia selezionato <b>Rimani connesso</b> sul tuo telefono personale.","Tocca <b>Accedi</b>. Se richiesto, imposta una nuova password di almeno 12 caratteri.","Nell'app Android puoi poi aprire <b>Impostazioni</b> e attivare <b>Accedi con dati biometrici</b>."])+[img(login,132*mm),P("Usa Rimani connesso solo su un dispositivo personale protetto da PIN, impronta o riconoscimento del volto. Su un telefono condiviso, togli la spunta ed esci al termine.","Small")]
story += [PageBreak(),P("Calendario e lezioni","H1SGP"),P("Il calendario mostra soltanto le lezioni assegnate al tuo account. Usa le frecce o il selettore della data per cambiare settimana.")]+steps(["Apri <b>Calendario</b> dalla barra in basso.","Scegli il giorno; puoi anche filtrare per corso.","Tocca la scheda della lezione per aprire disponibilità, elenco degli allievi e note.","Se una lezione non compare, chiedi alla segreteria di controllare l'assegnazione."])+[img(calendar,148*mm),P("La segreteria vede tutte le lezioni e può fare o correggere l'appello. Le insegnanti assegnate alla stessa lezione lavorano sullo stesso elenco condiviso.","Small")]
story += [PageBreak(),P("Fare l'appello","H1SGP"),P("Gli iscritti fissi inseriti dalla segreteria compaiono automaticamente nell'elenco della lezione. Anche le prenotazioni Wix associate alla lezione possono comparire nello stesso appello.")]+steps(["Apri la lezione.","Gli alunni non ancora segnati partono già su <b>Presente</b>.","Tocca la crocetta nella colonna <b>Assente</b> solo per chi manca. Per correggere, tocca di nuovo <b>Presente</b>.","Controlla il totale e premi <b>Salva appello</b> una sola volta."])+[img(attendance,174*mm),P("Dopo il salvataggio le colleghe e la segreteria vedono lo stesso risultato. Se qualcun altro ha salvato mentre avevi la lezione aperta, l'app ti chiede di riaprirla: serve a non sovrascrivere le modifiche altrui.","Small")]
story += [PageBreak(),P("Disponibilità, documenti e impostazioni","H1SGP"),P("Oltre all'appello puoi comunicare la tua presenza, inviare file alla segreteria e gestire il modo di accesso.")]+[P("Disponibilità alla lezione","H2SGP")]+steps(["Apri la lezione e scegli <b>Ci sono</b>, <b>Non ci sono</b> oppure <b>Da confermare</b>.","La scelta riguarda la tua disponibilità come insegnante; non modifica le presenze degli allievi."])+[P("Inviare un documento","H2SGP")]+steps(["Apri <b>Documenti</b> e tocca <b>Carica documento</b>.","Scegli un PDF, un file Word o un'immagine, aggiungi una breve descrizione e salva.","Il file arriva direttamente alla segreteria; non serve approvazione."])+[P("Accesso sul telefono","H2SGP")]+steps(["Apri <b>Altro - Impostazioni</b>.","Attiva o disattiva <b>Rimani connesso</b>.","Nell'app Android puoi attivare i dati biometrici. Il telefono può proporre anche il codice di sblocco."])+[img(tools,174*mm)]
story += [PageBreak(),P("Comunicazioni e problemi comuni","H1SGP"),P("In <b>Messaggi</b> trovi le comunicazioni inviate dalla segreteria. Dopo averle lette puoi segnarle come lette.")]
rows=[[P("Problema","H2SGP"),P("Cosa fare","H2SGP")],[P("Non vedo una lezione"),P("Aggiorna i dati e controlla la data. Se manca ancora, chiedi alla segreteria di verificare l'assegnazione.")],[P("Non vedo un alunno"),P("Non aggiungerlo con un nome inventato. Chiedi alla segreteria di controllare l'elenco fisso o la prenotazione Wix.")],[P("Appello modificato da un'altra persona"),P("Riapri la lezione, ricontrolla le presenze aggiornate e salva di nuovo.")],[P("Il caricamento non parte"),P("Controlla la connessione e che il file non superi 20 MB. Sono accettati PDF, Word e immagini.")],[P("Password dimenticata"),P("Contatta la segreteria: non vengono inviate email automatiche di recupero.")],[P("Telefono perso o condiviso"),P("Chiedi subito alla segreteria di disattivare l'account e cambia password da un dispositivo sicuro.")]]
tbl=Table(rows,colWidths=[50*mm,120*mm],repeatRows=1,style=TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor(NAVY)),('TEXTCOLOR',(0,0),(-1,0),colors.white),('GRID',(0,0),(-1,-1),0.5,colors.HexColor('#D9D9D9')),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('LEFTPADDING',(0,0),(-1,-1),8),('RIGHTPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#F2F7F8')])]))
story += [tbl,Spacer(1,5*mm),P("Regola principale","H2SGP"),P("Salva l'appello dopo aver controllato gli assenti. L'elenco è condiviso: ogni modifica salvata vale per tutte le insegnanti assegnate e per la segreteria."),Spacer(1,4*mm),P("Sito del gestionale: <b>https://sdsfilm1.github.io/sgp-gestionale/</b><br/>Pagina di installazione: <b>https://sdsfilm1.github.io/sgp-gestionale/installa.html</b>","Small")]
doc.build(story,onFirstPage=page_header,onLaterPages=page_header)
print(OUT)
