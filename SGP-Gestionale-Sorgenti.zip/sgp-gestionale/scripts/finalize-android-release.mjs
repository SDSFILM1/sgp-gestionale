import{readFile,writeFile,stat}from'node:fs/promises';import{createHash}from'node:crypto';
// Run AFTER signing. Never rebuild Android after embedding the APK's own digest.
const root=new URL('../',import.meta.url);
const manifest=JSON.parse(await readFile(new URL('public/version.json',root),'utf8'));
if(!/^\d+(\.\d+){1,3}$/.test(manifest.version)||manifest.apk!==`./SGP-Gestionale-Android-${manifest.version}.apk`)throw Error('Versione o percorso APK non valido');
const file=new URL('public/'+manifest.apk.slice(2),root),size=(await stat(file)).size;
const gradle=await readFile(new URL('android/app/build.gradle',root),'utf8');
if(!gradle.includes(`versionName "${manifest.version}"`))throw Error('Versione Android diversa dal manifest');
const versionCode=Number(gradle.match(/versionCode\s+(\d+)/)?.[1]);if(!versionCode||size<1||size>100*1024*1024)throw Error('APK non valido');
const sha256=createHash('sha256').update(await readFile(file)).digest('hex');
const output=JSON.stringify({version:manifest.version,versionCode,apk:manifest.apk,sha256,size});
for(const path of['public/version.json','dist/version.json'])await writeFile(new URL(path,root),output);
console.log(`Manifest verificato: ${manifest.version}, codice ${versionCode}, ${size} byte, SHA-256 ${sha256}`);
