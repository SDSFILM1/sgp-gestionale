import{spawnSync}from'node:child_process';
const r=spawnSync('git',['credential','fill'],{input:'protocol=https\nhost=github.com\n\n',encoding:'utf8',env:{...process.env,GIT_TERMINAL_PROMPT:'0',GCM_INTERACTIVE:'never'},timeout:15000});
console.log(r.status===0&&/password=/.test(r.stdout)?'Credenziale GitHub già disponibile':'Nessuna credenziale GitHub disponibile per la pubblicazione da terminale');
