from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "assets" / "app-icon-sgp.png"

def contain(size, scale=0.88, transparent=False):
    src = Image.open(SRC).convert("RGBA")
    target = int(size * scale)
    src.thumbnail((target, target), Image.Resampling.LANCZOS)
    bg = Image.new("RGBA", (size, size), (255, 255, 255, 0 if transparent else 255))
    bg.alpha_composite(src, ((size-src.width)//2, (size-src.height)//2))
    return bg

for size, name in [(192,"icon-192.png"),(512,"icon-512.png")]:
    contain(size).convert("RGB").save(ROOT / "public" / name, optimize=True)

densities = {"mdpi":48,"hdpi":72,"xhdpi":96,"xxhdpi":144,"xxxhdpi":192}
for density, size in densities.items():
    folder = ROOT / "android" / "app" / "src" / "main" / "res" / f"mipmap-{density}"
    contain(size).convert("RGB").save(folder / "ic_launcher.png", optimize=True)
    contain(size).convert("RGB").save(folder / "ic_launcher_round.png", optimize=True)
    contain(round(size*2.25), 0.70, True).save(folder / "ic_launcher_foreground.png", optimize=True)

print("Icone web e Android aggiornate")
