package it.ginnasticapordenonese.gestionale;
import org.junit.Test;
import static org.junit.Assert.*;

public class SgpUpdatePolicyTest {
    @Test public void acceptsOnlyReleaseFilesOnTheSgpHttpsSite() {
        assertTrue(SgpUpdatePolicy.allowedUrl("https://sdsfilm1.github.io/sgp-gestionale/SGP-Gestionale-Android-1.24.apk"));
        for (String value : new String[]{"http://sdsfilm1.github.io/sgp-gestionale/SGP-Gestionale-Android-1.24.apk",
            "https://sdsfilm1.github.io.evil.example/sgp-gestionale/SGP-Gestionale-Android-1.24.apk",
            "https://sdsfilm1.github.io/other/SGP-Gestionale-Android-1.24.apk",
            "https://sdsfilm1.github.io/sgp-gestionale/../other.apk",
            "https://sdsfilm1.github.io/sgp-gestionale/SGP-Gestionale-Android-1.24.apk?url=elsewhere",
            "https://user@sdsfilm1.github.io/sgp-gestionale/SGP-Gestionale-Android-1.24.apk",
            "file:///sdcard/update.apk", "https://sdsfilm1.github.io/sgp-gestionale/%2e%2e/other.apk"})
            assertFalse(value, SgpUpdatePolicy.allowedUrl(value));
    }
    @Test public void blocksOtherAppsDowngradesAndWrongReleaseNames() {
        String pkg="it.ginnasticapordenonese.gestionale";
        assertTrue(SgpUpdatePolicy.allowedIdentity(pkg,25,pkg,26,"1.25","1.25"));
        assertFalse(SgpUpdatePolicy.allowedIdentity(pkg,25,pkg,25,"1.25","1.25"));
        assertFalse(SgpUpdatePolicy.allowedIdentity(pkg,25,pkg,24,"1.24","1.24"));
        assertFalse(SgpUpdatePolicy.allowedIdentity(pkg,25,"another.app",26,"1.25","1.25"));
        assertFalse(SgpUpdatePolicy.allowedIdentity(pkg,25,pkg,26,"1.26","1.25"));
    }
    @Test public void requiresTheSameNonemptySigningCertificateSet() throws Exception {
        byte[] first={1,2,3}, second={4,5,6}, wrong={7,8,9};
        assertTrue(SgpUpdatePolicy.sameSigners(new byte[][]{first},new byte[][]{first}));
        assertTrue(SgpUpdatePolicy.sameSigners(new byte[][]{first,second},new byte[][]{second,first}));
        assertFalse(SgpUpdatePolicy.sameSigners(new byte[][]{first},new byte[][]{wrong}));
        assertFalse(SgpUpdatePolicy.sameSigners(new byte[][]{first,second},new byte[][]{first}));
        assertFalse(SgpUpdatePolicy.sameSigners(null,new byte[][]{first}));
        assertFalse(SgpUpdatePolicy.sameSigners(new byte[][]{},new byte[][]{}));
    }
    @Test public void requiresACompleteSha256Digest() {
        assertTrue(SgpUpdatePolicy.validHash("abcdef0123456789abcdef0123456789abcdef0123456789abcdef0123456789"));
        assertFalse(SgpUpdatePolicy.validHash("")); assertFalse(SgpUpdatePolicy.validHash("1234")); assertFalse(SgpUpdatePolicy.validHash(null));
    }
}
