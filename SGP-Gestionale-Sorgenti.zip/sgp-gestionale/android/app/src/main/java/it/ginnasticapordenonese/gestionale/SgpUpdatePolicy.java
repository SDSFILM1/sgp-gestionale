package it.ginnasticapordenonese.gestionale;

import java.net.URI;
import java.security.MessageDigest;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Shared, testable restrictions for self-updates. No arbitrary package installation. */
final class SgpUpdatePolicy {
    static final long MAX_BYTES = 100L * 1024 * 1024;
    static boolean allowedUrl(String value) {
        try {
            URI uri = new URI(value);
            return "https".equals(uri.getScheme()) && "sdsfilm1.github.io".equals(uri.getHost())
                && uri.getUserInfo() == null && uri.getPort() == -1 && uri.getRawQuery() == null && uri.getFragment() == null
                && uri.getRawPath().matches("/sgp-gestionale/SGP-Gestionale-Android-[0-9]+(?:\\.[0-9]+){1,3}\\.apk");
        } catch (Exception error) { return false; }
    }
    static boolean validHash(String value) { return value != null && value.matches("[a-fA-F0-9]{64}"); }
    static boolean allowedIdentity(String installedPackage, long installedVersion, String candidatePackage,
                                   long candidateVersion, String candidateName, String expectedName) {
        return installedPackage.equals(candidatePackage) && candidateVersion > installedVersion
            && expectedName != null && expectedName.matches("[0-9]+(?:\\.[0-9]+){1,3}") && expectedName.equals(candidateName);
    }
    static String hex(byte[] value) {
        StringBuilder text = new StringBuilder();
        for (byte part : value) text.append(String.format(Locale.ROOT, "%02x", part & 255));
        return text.toString();
    }
    static boolean sameSigners(byte[][] installed, byte[][] candidate) throws Exception {
        if (installed == null || candidate == null || installed.length == 0 || candidate.length == 0) return false;
        Set<String> left = new HashSet<>(), right = new HashSet<>();
        for (byte[] certificate : installed) left.add(hex(MessageDigest.getInstance("SHA-256").digest(certificate)));
        for (byte[] certificate : candidate) right.add(hex(MessageDigest.getInstance("SHA-256").digest(certificate)));
        return left.equals(right);
    }
}
