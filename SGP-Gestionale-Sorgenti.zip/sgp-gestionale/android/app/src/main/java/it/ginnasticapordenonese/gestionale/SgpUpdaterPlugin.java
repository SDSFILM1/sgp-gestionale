package it.ginnasticapordenonese.gestionale;

import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.lang.ref.WeakReference;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.atomic.AtomicBoolean;

@CapacitorPlugin(name = "SgpUpdater")
public class SgpUpdaterPlugin extends Plugin {
    private static WeakReference<SgpUpdaterPlugin> current = new WeakReference<>(null);
    private static final ExecutorService worker = Executors.newSingleThreadExecutor();
    private static final AtomicBoolean running = new AtomicBoolean(false);
    private boolean visible;

    @Override public void load() { current = new WeakReference<>(this); }
    @Override protected void handleOnResume() { visible = true; showConfirmationIfVisible(); changed(); }
    @Override protected void handleOnPause() { visible = false; }
    @Override protected void handleOnDestroy() { if (current.get() == this) current.clear(); }
    static void changed() {
        SgpUpdaterPlugin plugin = current.get();
        if (plugin != null && plugin.getActivity() != null) plugin.getActivity().runOnUiThread(() ->
            plugin.notifyListeners("progress", SgpUpdateState.read(plugin.getContext())));
    }
    static void showConfirmationIfVisible() {
        SgpUpdaterPlugin plugin = current.get();
        if (plugin == null || !plugin.visible || plugin.getActivity() == null) return;
        plugin.getActivity().runOnUiThread(() -> {
            Intent confirmation = SgpUpdateState.confirmation;
            if (confirmation == null || !plugin.visible) return;
            SgpUpdateState.confirmation = null;
            try {
                plugin.getActivity().startActivity(confirmation);
                SgpUpdateState.set(plugin.getContext(), "confirming", 100, "Completa la conferma richiesta da Android.");
            } catch (Exception error) {
                SgpUpdateState.set(plugin.getContext(), "error", 100, "Non riesco ad aprire la conferma di Android. Premi Riprova.");
            }
        });
    }
    @PluginMethod public void getStatus(PluginCall call) {
        try {
            String phase = SgpUpdateState.prefs(getContext()).getString("phase", "idle");
            long target = SgpUpdateState.prefs(getContext()).getLong("targetCode", Long.MAX_VALUE);
            PackageInfo installed = getContext().getPackageManager().getPackageInfo(getContext().getPackageName(), 0);
            if (versionCode(installed) >= target) SgpUpdateState.set(getContext(), "success", 100, "Aggiornamento completato.");
            else if (!running.get() && (phase.equals("downloading") || phase.equals("verifying")))
                SgpUpdateState.set(getContext(), "error", 0, "Scaricamento interrotto. Premi Riprova.");
            else if (phase.equals("confirmation") && SgpUpdateState.confirmation == null)
                SgpUpdateState.set(getContext(), "error", 100, "Conferma interrotta. Premi Riprova.");
            else if (phase.equals("installing") || phase.equals("confirming")) {
                int id = SgpUpdateState.prefs(getContext()).getInt("session", -1);
                long started = SgpUpdateState.prefs(getContext()).getLong("started", 0);
                if (getContext().getPackageManager().getPackageInstaller().getSessionInfo(id) == null || System.currentTimeMillis() - started > 600000)
                    SgpUpdateState.set(getContext(), "error", 100, "Installazione interrotta. Premi Riprova.");
            }
            call.resolve(SgpUpdateState.read(getContext()));
        } catch (Exception error) { call.reject("Impossibile verificare l’aggiornamento", error); }
    }
    @PluginMethod public void openSettings(PluginCall call) {
        if (Build.VERSION.SDK_INT < 26 || getContext().getPackageManager().canRequestPackageInstalls()) { call.resolve(); return; }
        getActivity().runOnUiThread(() -> {
            try { getActivity().startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + getContext().getPackageName()))); call.resolve(); }
            catch (Exception error) { call.reject("Apri le impostazioni Android e autorizza gli aggiornamenti per SGP.", error); }
        });
    }
    @PluginMethod public void start(PluginCall call) {
        String url = call.getString("url", ""), hash = call.getString("sha256", ""), version = call.getString("version", "");
        if (!SgpUpdatePolicy.allowedUrl(url) || !SgpUpdatePolicy.validHash(hash) || !version.matches("[0-9]+(?:\\.[0-9]+){1,3}")) {
            call.reject("Aggiornamento non valido. Contatta la segreteria."); return;
        }
        if (!running.compareAndSet(false, true)) { call.reject("Un aggiornamento è già in corso."); return; }
        String phase = SgpUpdateState.prefs(getContext()).getString("phase", "idle");
        if (phase.equals("installing") || phase.equals("confirming")) {
            running.set(false); call.resolve(SgpUpdateState.read(getContext())); return;
        }
        SgpUpdateState.prefs(getContext()).edit().putString("version", version).remove("targetCode").apply();
        if (Build.VERSION.SDK_INT >= 26 && !getContext().getPackageManager().canRequestPackageInstalls()) {
            running.set(false); SgpUpdateState.set(getContext(), "permission", 0, "Autorizza SGP ad aggiornarsi, poi torna qui.");
            call.resolve(SgpUpdateState.read(getContext())); return;
        }
        visible = true;
        worker.execute(() -> {
            int sessionId = -1;
            try {
                int previous = SgpUpdateState.prefs(getContext()).getInt("session", -1);
                SgpUpdateState.prefs(getContext()).edit().remove("token").remove("session").apply();
                if (previous >= 0) try { getContext().getPackageManager().getPackageInstaller().abandonSession(previous); } catch (Exception ignored) {}
                SgpUpdateState.confirmation = null;
                File folder = new File(getContext().getCacheDir(), "sgp-updates");
                if (!folder.isDirectory() && !folder.mkdirs()) throw new Exception("Spazio sul telefono non disponibile.");
                File apk = new File(folder, "sgp-update.apk");
                if (!apk.isFile() || !hash.equalsIgnoreCase(fileHash(apk))) download(url, hash, apk);
                SgpUpdateState.set(getContext(), "verifying", 100, "Verifico l’aggiornamento SGP…");
                PackageManager manager = getContext().getPackageManager();
                int flags = Build.VERSION.SDK_INT >= 28 ? PackageManager.GET_SIGNING_CERTIFICATES : PackageManager.GET_SIGNATURES;
                PackageInfo installed = manager.getPackageInfo(getContext().getPackageName(), flags);
                PackageInfo candidate = manager.getPackageArchiveInfo(apk.getAbsolutePath(), flags);
                if (candidate == null || !SgpUpdatePolicy.allowedIdentity(installed.packageName, versionCode(installed), candidate.packageName,
                    versionCode(candidate), candidate.versionName, version) || !SgpUpdatePolicy.sameSigners(signers(installed), signers(candidate)))
                    throw new Exception("Il file non è un aggiornamento autentico di questa app SGP.");
                PackageInstaller installer = manager.getPackageInstaller();
                PackageInstaller.SessionParams params = new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
                params.setAppPackageName(installed.packageName); params.setSize(apk.length());
                if (Build.VERSION.SDK_INT >= 26) params.setInstallReason(PackageManager.INSTALL_REASON_USER);
                if (Build.VERSION.SDK_INT >= 31) params.setRequireUserAction(PackageInstaller.SessionParams.USER_ACTION_NOT_REQUIRED);
                if (Build.VERSION.SDK_INT >= 33) params.setPackageSource(PackageInstaller.PACKAGE_SOURCE_DOWNLOADED_FILE);
                sessionId = installer.createSession(params);
                String token = UUID.randomUUID().toString();
                SgpUpdateState.prefs(getContext()).edit().putInt("session", sessionId).putString("token", token)
                    .putLong("targetCode", versionCode(candidate)).putLong("started", System.currentTimeMillis()).apply();
                try (PackageInstaller.Session session = installer.openSession(sessionId)) {
                    try (InputStream input = new FileInputStream(apk); OutputStream output = session.openWrite("base.apk", 0, apk.length())) {
                        byte[] buffer = new byte[65536]; int n;
                        while ((n = input.read(buffer)) != -1) output.write(buffer, 0, n);
                        session.fsync(output);
                    }
                    Intent result = new Intent(getContext(), SgpUpdateReceiver.class).setAction("it.ginnasticapordenonese.gestionale.UPDATE_RESULT")
                        .putExtra("sgpToken", token).putExtra("sgpSession", sessionId);
                    int pendingFlags = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 31 ? PendingIntent.FLAG_MUTABLE : 0);
                    PendingIntent callback = PendingIntent.getBroadcast(getContext(), sessionId, result, pendingFlags);
                    SgpUpdateState.set(getContext(), "installing", 100, "Installazione in corso. SGP potrebbe chiudersi: riaprila al termine.");
                    session.commit(callback.getIntentSender());
                }
                call.resolve(SgpUpdateState.read(getContext()));
            } catch (Exception error) {
                if (sessionId >= 0) try { getContext().getPackageManager().getPackageInstaller().abandonSession(sessionId); } catch (Exception ignored) {}
                String message = error instanceof java.io.IOException ? "Scaricamento non riuscito. Controlla la connessione e riprova." : error.getMessage();
                SgpUpdateState.set(getContext(), "error", 0, message == null ? "Aggiornamento non riuscito. Premi Riprova." : message);
                call.resolve(SgpUpdateState.read(getContext()));
            } finally { running.set(false); }
        });
    }
    private void download(String url, String expectedHash, File apk) throws Exception {
        SgpUpdateState.set(getContext(), "downloading", 0, "Scarico l’aggiornamento…");
        File partial = new File(apk.getParentFile(), "sgp-update.part");
        HttpURLConnection connection = (HttpURLConnection) new URL(url).openConnection();
        connection.setConnectTimeout(30000); connection.setReadTimeout(30000); connection.setInstanceFollowRedirects(false);
        connection.setRequestProperty("Accept-Encoding", "identity");
        try {
            if (connection.getResponseCode() != 200) throw new java.io.IOException("Download non disponibile");
            long size = connection.getContentLengthLong();
            if (size > SgpUpdatePolicy.MAX_BYTES) throw new Exception("Aggiornamento troppo grande.");
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            long total = 0, started = System.nanoTime(); int last = -1;
            try (InputStream input = connection.getInputStream(); OutputStream output = new FileOutputStream(partial)) {
                byte[] buffer = new byte[65536]; int n;
                while ((n = input.read(buffer)) != -1) {
                    total += n;
                    if (total > SgpUpdatePolicy.MAX_BYTES || System.nanoTime() - started > 180000000000L) throw new java.io.IOException("Download interrotto");
                    output.write(buffer, 0, n); digest.update(buffer, 0, n);
                    int progress = size > 0 ? (int) Math.min(99, total * 100 / size) : 0;
                    if (progress != last) { last = progress; SgpUpdateState.set(getContext(), "downloading", progress, "Scarico l’aggiornamento…"); }
                }
            }
            if (total == 0 || (size > 0 && total != size) || !expectedHash.equalsIgnoreCase(SgpUpdatePolicy.hex(digest.digest())))
                throw new Exception("Il file scaricato è incompleto o non corrisponde all’aggiornamento SGP. Riprova.");
            if (apk.exists() && !apk.delete()) throw new java.io.IOException("Cache occupata");
            if (!partial.renameTo(apk)) throw new java.io.IOException("Cache non disponibile");
        } finally { connection.disconnect(); if (partial.exists()) partial.delete(); }
    }
    private static long versionCode(PackageInfo info) { return Build.VERSION.SDK_INT >= 28 ? info.getLongVersionCode() : info.versionCode; }
    private static byte[][] signers(PackageInfo info) {
        Signature[] signatures = Build.VERSION.SDK_INT >= 28 && info.signingInfo != null ? info.signingInfo.getApkContentsSigners() : info.signatures;
        if (signatures == null) return null;
        byte[][] bytes = new byte[signatures.length][];
        for (int i = 0; i < signatures.length; i++) bytes[i] = signatures[i].toByteArray();
        return bytes;
    }
    private static String fileHash(File file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream input = new FileInputStream(file)) { byte[] buffer = new byte[65536]; int n; while ((n = input.read(buffer)) != -1) digest.update(buffer, 0, n); }
        return SgpUpdatePolicy.hex(digest.digest());
    }
}
