package it.ginnasticapordenonese.gestionale;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInstaller;

/** Explicit private callback. The per-session token also rejects stale callback results. */
public class SgpUpdateReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        SharedPreferences p = SgpUpdateState.prefs(context);
        String token = p.getString("token", "");
        if (!"it.ginnasticapordenonese.gestionale.UPDATE_RESULT".equals(intent.getAction()) || token.isEmpty()
            || !token.equals(intent.getStringExtra("sgpToken"))
            || intent.getIntExtra("sgpSession", -1) != p.getInt("session", -2)) return;
        int status = intent.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE);
        if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
            SgpUpdateState.confirmation = intent.getParcelableExtra(Intent.EXTRA_INTENT);
            if (SgpUpdateState.confirmation == null) {
                SgpUpdateState.set(context, "error", 100, "Android non ha fornito la conferma. Premi Riprova.");
            } else {
                SgpUpdateState.set(context, "confirmation", 100, "Completa la conferma richiesta da Android.");
                SgpUpdaterPlugin.showConfirmationIfVisible();
            }
        } else {
            SgpUpdateState.confirmation = null;
            p.edit().remove("token").apply();
            if (status == PackageInstaller.STATUS_SUCCESS) {
                SgpUpdateState.set(context, "success", 100, "Aggiornamento completato. Riapri SGP.");
            } else {
                String message = status == PackageInstaller.STATUS_FAILURE_ABORTED ? "Aggiornamento annullato. Puoi riprovare."
                    : status == PackageInstaller.STATUS_FAILURE_STORAGE ? "Spazio sul telefono insufficiente. Libera spazio e riprova."
                    : status == PackageInstaller.STATUS_FAILURE_BLOCKED ? "Il telefono ha bloccato l’installazione. Controlla le autorizzazioni."
                    : "Android non ha completato l’aggiornamento. Premi Riprova.";
                SgpUpdateState.set(context, "error", 100, message);
            }
        }
    }
}
