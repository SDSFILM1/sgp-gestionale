package it.ginnasticapordenonese.gestionale;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
