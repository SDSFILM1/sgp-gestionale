package it.ginnasticapordenonese.gestionale;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import com.getcapacitor.JSObject;

final class SgpUpdateState {
    static volatile Intent confirmation;
    static SharedPreferences prefs(Context context) { return context.getSharedPreferences("sgp-self-update", Context.MODE_PRIVATE); }
    static void set(Context context, String phase, int progress, String message) {
        prefs(context).edit().putString("phase", phase).putInt("progress", progress).putString("message", message).apply();
        SgpUpdaterPlugin.changed();
    }
    static JSObject read(Context context) {
        SharedPreferences p = prefs(context);
        JSObject out = new JSObject();
        out.put("phase", p.getString("phase", "idle"));
        out.put("progress", p.getInt("progress", 0));
        out.put("message", p.getString("message", ""));
        out.put("version", p.getString("version", ""));
        out.put("canInstall", android.os.Build.VERSION.SDK_INT < 26 || context.getPackageManager().canRequestPackageInstalls());
        return out;
    }
}
