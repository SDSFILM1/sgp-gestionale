import test from 'node:test';
import assert from 'node:assert/strict';
import{readFile}from'node:fs/promises';
import ts from'typescript';
import{normalizeBooking,normalizeOrder,normalizeBalance}from'../supabase/functions/wix-sync/normalization.ts';

test('Wix participant identity uses customer contact, not the staff creator, and inactivity uses creation date',()=>{
 const row=normalizeBooking({booking:{id:'booking',contactDetails:{contactId:'customer',firstName:'Anna',lastName:'Rossi'},createdBy:{memberId:'staff'},createdDate:'2026-09-01T10:00:00Z',startDate:'2026-10-20T10:00:00Z',endDate:'2026-10-20T11:00:00Z',bookedEntity:{slot:{serviceId:'service'}},status:'CONFIRMED'}});
 assert.equal(row.contact_id,'customer');assert.equal(row.name,'Anna Rossi');assert.equal(row.booked_at,'2026-09-01T10:00:00.000Z');assert.equal(row.starts_at,'2026-10-20T10:00:00.000Z');
});

test('Missing Wix identity or creation date stays unknown and course bookings do not become invented lessons',()=>{
 const row=normalizeBooking({booking:{id:'booking',createdBy:{memberId:'creator'},startDate:'2026-10-20T10:00:00Z',endDate:'2027-06-20T11:00:00Z',bookedEntity:{schedule:{serviceId:'course'}}}});
 assert.equal(row.contact_id,null);assert.equal(row.booked_at,null);assert.equal(row.starts_at,null);assert.equal(row.ends_at,null);assert.equal(row.service_id,'course');
 assert.equal(normalizeBooking({booking:{id:'booking',createdDate:'invalid'}}).booked_at,null);
 assert.throws(()=>normalizeBooking({booking:{}}),/identificativo/);
});

test('Pricing Plans preserve unlimited subscriptions and deferred cancellation without treating them as expired',()=>{
 const active=normalizeOrder({id:'plan-order',buyer:{contactId:'customer',memberId:'member'},status:'ACTIVE',startDate:'2026-09-01T00:00:00Z',planName:'Open 3'});
 assert.equal(active.contact_id,'customer');assert.equal(active.member_id,'member');assert.equal(active.end_date,null);assert.equal(active.status,'ACTIVE');assert.equal(active.auto_renew_canceled,false);
 const canceled=normalizeOrder({id:'canceling',status:'CANCELED',autoRenewCanceled:true,endDate:'2026-11-01T00:00:00Z',cancellation:{effectiveAt:'NEXT_PAYMENT_DATE'}});
 assert.equal(canceled.cancellation_effective_at,'NEXT_PAYMENT_DATE');assert.equal(canceled.end_date,'2026-11-01T00:00:00.000Z');assert.equal(canceled.auto_renew_canceled,true);
 assert.throws(()=>normalizeOrder({}),/identificativo/);
});

const source=(await readFile(new URL('../supabase/functions/wix-sync/index.ts',import.meta.url),'utf8')).replace(/^import[^\n]+\n/gm,'');
const compiled=ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.None}}).outputText;
async function syncWith(mockFetch){
 const calls=[];let handler;
 const admin={rpc:async(name,args)=>{calls.push({name,args});return{data:name==='begin_wix_sync'?true:2}},from:()=>({upsert:async()=>({}),update:()=>({eq:async()=>({})})})};
 const deno={env:{get:name=>({SUPABASE_URL:'https://test.invalid',SUPABASE_SERVICE_ROLE_KEY:'test',WIX_API_KEY:'test-wix',WIX_SITE_ID:'site',SGP_CRON_SECRET:'test-cron'}[name])},serve:fn=>{handler=fn}};
 new Function('createClient','Deno','fetch','normalizeBooking','normalizeOrder','normalizeBalance',compiled)(()=>admin,deno,mockFetch,normalizeBooking,normalizeOrder,normalizeBalance);
 const result=await handler(new Request('https://test.invalid',{method:'POST',headers:{Authorization:'Bearer test-cron','Content-Type':'application/json'},body:JSON.stringify({action:'sync'})}));
 return{status:result.status,body:await result.json(),calls};
}
const bookingsResponse=()=>Response.json({extendedBookings:[{booking:{id:'booking',contactDetails:{contactId:'customer'},createdDate:'2026-10-11T10:00:00Z',status:'CONFIRMED'}}]});

test('Bookings-only Wix key saves one atomic snapshot with unknown plans and a permission warning',async()=>{
 const fetched=[];
 const result=await syncWith(async(url,options)=>{fetched.push({url,options});return url.includes('/orders?')?new Response('{}',{status:403}):bookingsResponse()});
 assert.equal(result.status,200);assert.match(result.body.warning,/Read Orders/);
 const writes=result.calls.filter(c=>c.name!=='begin_wix_sync');assert.equal(writes.length,1);assert.equal(writes[0].name,'apply_wix_snapshot');assert.equal(writes[0].args.p_orders,null);assert.equal(writes[0].args.p_rows[0].contact_id,'customer');
 assert.equal(fetched[1].options.method,'GET');assert.equal(fetched[1].options.body,undefined);assert.match(fetched[1].url,/limit=50&offset=0/);
});

test('A successful empty plan list remains an empty snapshot, distinct from missing permission',async()=>{
 const result=await syncWith(async url=>url.includes('/orders?')?Response.json({orders:[]}):url.includes('/balances/')?Response.json({balances:[]}):bookingsResponse());
 assert.equal(result.status,200);assert.equal(result.body.warning,undefined);assert.deepEqual(result.calls.at(-1).args.p_orders,[]);
});

test('A failure on a later Wix order page writes no partial bookings or plan snapshot',async()=>{
 const result=await syncWith(async url=>{
  if(!url.includes('/orders?'))return bookingsResponse();
  if(url.endsWith('offset=0'))return Response.json({orders:Array.from({length:50},(_,n)=>({id:'order-'+n,status:'ACTIVE',buyer:{contactId:'contact-'+n}}))});
  return new Response('{}',{status:500});
 });
 assert.equal(result.status,400);assert.deepEqual(result.calls.map(c=>c.name),['begin_wix_sync']);
});

test('Malformed or repeated booking pages cannot clear the saved list',async()=>{
 const malformed=await syncWith(async()=>Response.json({}));
 assert.equal(malformed.status,400);assert.deepEqual(malformed.calls.map(c=>c.name),['begin_wix_sync']);
 const repeated=await syncWith(async()=>Response.json({extendedBookings:[{booking:{id:'same'}},{booking:{id:'same'}}]}));
 assert.equal(repeated.status,400);assert.deepEqual(repeated.calls.map(c=>c.name),['begin_wix_sync']);
});

test('Balances use all cursor pages and retain balances if a contact was deleted',async()=>{
 const contact='00000000-0000-4000-8000-000000000001';let pages=0;
 const r=await syncWith(async(url,options)=>{
  if(url.includes('/orders?'))return Response.json({orders:[{id:'order',status:'ACTIVE',buyer:{contactId:contact,memberId:'member'}}]});
  if(url.includes('/balances/')){pages++;const q=JSON.parse(options.body);return Response.json({balances:[{id:'pool-'+pages,beneficiary:{memberId:'member'},amount:{available:'7'},poolInfo:{externalProgramId:'order',creditAmount:'10'}}],metadata:pages===1?{cursors:{next:'next-page'}}:{}})}
  if(url.includes('/contacts/'))return new Response('{}',{status:404});return bookingsResponse();
 });
 assert.equal(r.status,200);assert.equal(pages,2);assert.equal(r.calls.at(-1).args.p_balances.length,2);assert.deepEqual(r.calls.at(-1).args.p_contacts,[]);
});
test('Unavailable contacts never discard valid balances; repeated balance pages never erase the previous snapshot',async()=>{
 const contact='00000000-0000-4000-8000-000000000001';
 for(const repeat of [false,true]){let pages=0;
  const r=await syncWith(async(url)=>{
   if(url.includes('/orders?'))return Response.json({orders:[{id:'order',status:'ACTIVE',buyer:{contactId:contact,memberId:'member'}}]});
   if(url.includes('/balances/')){pages++;return Response.json({balances:[{id:'pool',beneficiary:{memberId:'member'},amount:{available:'7'},poolInfo:{externalProgramId:'order',creditAmount:'10'}}],metadata:repeat?{cursors:{next:'repeated'}}:{}})}
   if(url.includes('/contacts/'))return new Response('{}',{status:403});return bookingsResponse();
  });
  assert.equal(r.status,200);const snapshot=r.calls.at(-1).args;
  assert.equal(snapshot.p_contacts,null);if(repeat)assert.equal(snapshot.p_balances,null);else assert.equal(snapshot.p_balances[0].available,7);
  assert.ok(r.body.warning);assert.equal(snapshot.p_rows.length,1);
 }
});
