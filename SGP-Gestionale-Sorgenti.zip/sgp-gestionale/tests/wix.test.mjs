import{test}from'node:test';import assert from'node:assert/strict';import{readFile}from'node:fs/promises';import{PGlite}from'@electric-sql/pglite';
test('Wix import is idempotent and preserves historical attendance on cancellation and move',async()=>{
 const db=new PGlite();await db.exec(`create role anon;create role authenticated;create role service_role;create schema auth;create table auth.users(id uuid primary key);create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid $$;`);
 for(const f of ['202609180001_initial.sql','202609180002_wix.sql'])await db.exec(await readFile(new URL('../supabase/migrations/'+f,import.meta.url),'utf8'));
 const c=(await db.query(`insert into public.courses(name,wix_service_id)values('Test','svc')returning id`)).rows[0].id;
 const ls=(await db.query(`insert into public.lessons(course_id,starts_at,ends_at)select $1,now()+d*interval '1 day',now()+d*interval '1 day'+interval '1 hour' from unnest(array[-7,7,14])d returning *`,[c])).rows;
 const row=(lesson,status='CONFIRMED',name='Persona test')=>({id:'booking',service_id:'svc',name,starts_at:lesson.starts_at,ends_at:lesson.ends_at,status,participants:1});
 const sync=async r=>db.query('select public.apply_wix_bookings($1::jsonb)',[JSON.stringify([r])]);
 await sync(row(ls[0]));await sync(row(ls[0]));assert.equal((await db.query('select * from public.lesson_participants')).rows.length,1);
 await db.exec(`update public.lesson_participants set status='present'`);await sync(row(ls[0],'CANCELED','Nome mutato'));
 let past=(await db.query('select * from public.lesson_participants')).rows[0];assert.equal(past.name,'Persona test');assert.equal(past.status,'present');assert.equal(past.excluded,false);
 await sync(row(ls[1]));await sync(row(ls[2]));
 assert.equal((await db.query('select excluded from public.lesson_participants where lesson_id=$1',[ls[1].id])).rows[0].excluded,true);
 await sync(row(ls[2],'CANCELED'));assert.equal((await db.query('select excluded from public.lesson_participants where lesson_id=$1',[ls[2].id])).rows[0].excluded,true);
 await sync(row(ls[2]));assert.equal((await db.query('select excluded from public.lesson_participants where lesson_id=$1',[ls[2].id])).rows[0].excluded,false);
 await db.exec('set role authenticated');await assert.rejects(()=>sync(row(ls[2])));await assert.rejects(()=>db.query('select public.begin_wix_sync()'));
 await db.close();
});
