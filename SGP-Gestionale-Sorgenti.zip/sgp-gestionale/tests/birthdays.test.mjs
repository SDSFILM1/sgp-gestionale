import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {runInNewContext} from 'node:vm';
import ts from 'typescript';
const code=ts.transpileModule(await readFile(new URL('../src/birthdays.ts',import.meta.url),'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
const context={exports:{},Intl,Date};runInNewContext(code,context);
const {birthdaysToday,birthdayDay,birthdayCourses}=context.exports;
const student=(id,birth_date,other={})=>({id,name:id,archived:false,notes:'',birth_date,...other});
test('A November 3 birthday is not announced on November 2',()=>{
 const rows=[student('Example','2022-11-03')];
 assert.equal(birthdaysToday(rows,'2026-11-02').length,0);
 assert.equal(birthdaysToday(rows,'2026-11-03').length,1);
});
test('Birthday follows Rome, including midnight and summer time',()=>{
 assert.equal(birthdayDay(new Date('2026-10-27T23:15:00Z')),'2026-10-28');
 assert.equal(birthdayDay(new Date('2026-07-01T22:15:00Z')),'2026-07-02');
 assert.equal(birthdayDay(new Date('2026-10-27T22:15:00Z')),'2026-10-27');
});
test('Includes enrolled and trial athletes once; ignores archived, unknown, invalid and future births',()=>{
 const rows=[student('Zoe','2010-10-28'),student('Anna','2014-10-28',{enrollment_state:'trial'}),student('Zoe','2010-10-28'),student('Archived','2010-10-28',{archived:true}),student('Unknown',null),student('Bad','2010-02-30'),student('Other','2010-10-27'),student('Future','2030-10-28')];
 assert.deepEqual(Array.from(birthdaysToday(rows,'2026-10-28'),s=>s.id),['Anna','Zoe']);
 assert.equal(birthdaysToday(rows,'2026-10-29').length,0);
});
test('Leap-day birthdays are shown on February 29 only; invalid dates never create notifications',()=>{
 const rows=[student('Leap','2012-02-29'),student('Invalid leap','2011-02-29'),student('Invalid format','29/02/2012')];
 assert.deepEqual(Array.from(birthdaysToday(rows,'2028-02-29'),s=>s.id),['Leap']);
 assert.equal(birthdaysToday(rows,'2027-02-28').length,0);
 assert.equal(birthdaysToday(rows,'2027-03-01').length,0);
});
test('Shows every current course once, without expired, future, archived or another athlete’s courses',()=>{
 const courses=['MS','MSP','Old','Future','Hidden'].map(id=>({id,name:id,archived:id==='Hidden'}));
 const enrollments=['MS','MSP','MS','Old','Future','Hidden'].map((course_id,i)=>({student_id:'one',course_id,valid_from:i===4?'2026-12-01':'2026-09-01',valid_to:i===3?'2026-10-28':null}));
 enrollments.push({student_id:'other',course_id:'Old',valid_from:'2026-09-01',valid_to:null});
 assert.deepEqual(Array.from(birthdayCourses('one',courses,enrollments,'2026-10-28')),['MS','MSP']);
});
