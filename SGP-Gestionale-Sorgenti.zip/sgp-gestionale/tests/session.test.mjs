import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {runInNewContext} from 'node:vm';
import ts from 'typescript';
const source=await readFile(new URL('../src/session.ts',import.meta.url),'utf8');
const code=ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
const storage=()=>{const data=new Map();return {getItem:k=>data.get(k)??null,setItem:(k,v)=>data.set(k,v),removeItem:k=>data.delete(k)};};
function setup(native=false,locked=false){
 const local=storage(),session=storage(),secure=storage();if(locked)local.setItem('sgp-biometric','true');
 const context={exports:{},localStorage:local,sessionStorage:session,window:{dispatchEvent(){}},Event:class{},require:name=>name==='@capacitor/core'?{Capacitor:{isNativePlatform:()=>native}}:name.includes('secure-storage')?{SecureStorage:{get:async k=>secure.getItem(k),set:async(k,v)=>secure.setItem(k,v),remove:async k=>secure.removeItem(k)}}:{BiometricAuth:{authenticate:async()=>{}}}};
 runInNewContext(code,context);return {...context.exports,local,session,secure};
}
test('Web: persistent session can switch to tab-only and logout clears both',async()=>{
 const s=setup();await s.sessionStorageAdapter.setItem('token','example');assert.equal(s.local.getItem('token'),'example');
 await s.setRememberSession(false);assert.equal(s.local.getItem('token'),null);assert.equal(s.session.getItem('token'),'example');
 await s.setRememberSession(true);assert.equal(s.session.getItem('token'),null);assert.equal(s.local.getItem('token'),'example');
 await s.sessionStorageAdapter.removeItem('token');assert.equal(await s.sessionStorageAdapter.getItem('token'),null);
});
test('Android: migrate previous APK session into secure storage and gate reads',async()=>{
 const s=setup(true,true);s.local.setItem('token','example');let resolved=false;
 const pending=s.sessionStorageAdapter.getItem('token').then(value=>{resolved=true;return value;});await Promise.resolve();assert.equal(resolved,false);
 s.unlockStorage();assert.equal(await pending,'example');assert.equal(s.local.getItem('token'),null);assert.equal(s.secure.getItem('token'),'example');
 await s.setRememberSession(false);assert.equal(s.secure.getItem('token'),null);assert.equal(s.session.getItem('token'),'example');assert.equal(s.biometricEnabled(),false);
});
test('Password fallback discards the saved native session before releasing the gate',async()=>{
 const s=setup(true,true),key='sb-ogtyuhgmmdajqqkrakhi-auth-token';s.secure.setItem(key,'example');
 const pending=s.sessionStorageAdapter.getItem(key);await s.forgetSavedSession();assert.equal(await pending,null);assert.equal(s.biometricEnabled(),false);
});
