import React,{useState} from 'react';
import{createRoot}from'react-dom/client';
import{BirthdayNotice}from'../src/BirthdayNotice';
import{birthdayDay}from'../src/birthdays';
import'../src/style.css';import'../src/mobile.css';
function Preview(){
 const[page,setPage]=useState('Calendario');const birth='2012'+birthdayDay().slice(4);
 const courses=['Medie e Superiori','Medie e Superiori Potenziato','Pulcini'].map((name,i)=>({id:String(i),name,audience:'ragazzi',location:'',color:'',wix_service_id:null,archived:false}));
 const enrollments=[['demo1','0'],['demo1','1'],['demo2','2']].map(([student_id,course_id],i)=>({id:String(i),student_id,course_id,valid_from:'2026-01-01',valid_to:null}));
 return <main className="content" style={{maxWidth:880,margin:'auto'}}><span className="eyebrow">ANTEPRIMA · DATI FITTIZI</span><h1>{page}</h1><BirthdayNotice accountId="birthday-preview" courses={courses} enrollments={enrollments} students={[{id:'demo1',name:'Anna Esempio',birth_date:birth,notes:'',archived:false},{id:'demo2',name:'Marco Esempio',birth_date:birth,notes:'',archived:false,enrollment_state:'trial'}]}/><button onClick={()=>setPage(page==='Calendario'?'Alunni':'Calendario')}>Cambia pagina</button><p>Il promemoria resta riapribile in tutte le pagine.</p></main>
};
createRoot(document.getElementById('root')!).render(<React.StrictMode><Preview/></React.StrictMode>);
