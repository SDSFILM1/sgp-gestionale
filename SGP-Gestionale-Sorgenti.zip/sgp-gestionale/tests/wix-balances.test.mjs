import {test} from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {runInNewContext} from 'node:vm';
import ts from 'typescript';
const source=await readFile(new URL('../supabase/functions/wix-sync/normalization.ts',import.meta.url),'utf8');
const ctx={exports:{},Date};runInNewContext(ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText,ctx);
const {normalizeBalance}=ctx.exports;
test('Wix balance preserves the authoritative pool/member IDs and available vs reserved credits',()=>{
 const b=normalizeBalance({id:'pool',beneficiary:{memberId:'member'},amount:{available:'7',reserved:'1'},poolInfo:{programId:'program',externalProgramId:'order',creditAmount:'10',status:'ACTIVE'}});
 assert.equal(b.member_id,'member');assert.equal(b.external_program_id,'order');assert.equal(b.available,7);assert.equal(b.reserved,1);assert.equal(b.credit_amount,10);
});
test('Unknown or invalid balances stay unknown rather than showing zero lessons',()=>{
 for(const value of [null,undefined,'','wrong',-1])assert.equal(normalizeBalance({id:'p',amount:{available:value}}).available,null);
 assert.equal(normalizeBalance({id:'p',amount:{available:'0'}}).available,0);
 assert.equal(normalizeBalance({id:'p',beneficiary:{wixUserId:'staff'}}).member_id,null);
 assert.throws(()=>normalizeBalance({}),/identificativo/);
});
