import React,{useMemo,useState}from'react';import{createRoot}from'react-dom/client';import{UpdateDialog}from'../src/UpdateNotice';import type{UpdateInstaller,InstallState}from'../src/nativeUpdate';import'../src/style.css';
function demo(mode:string):UpdateInstaller{
 let state:InstallState={phase:'idle',progress:0,message:'',version:'1.25',canInstall:mode!=='permission'};const listeners=new Set<(state:InstallState)=>void>();
 const set=(change:Partial<InstallState>)=>{state={...state,...change};for(const f of listeners)f(state)};
 return {getStatus:async()=>state,addListener:async(_,f)=>{listeners.add(f);return{remove:async()=>{listeners.delete(f)}}},openSettings:async()=>{set({canInstall:true,message:'Autorizzazione concessa nell’anteprima. Premi Continua aggiornamento.'})},start:async()=>{
  if(!state.canInstall){set({phase:'permission',message:'Autorizza SGP ad aggiornarsi, poi torna qui.'});return state}
  set({phase:'downloading',progress:35,message:'Scarico l’aggiornamento…'});
  setTimeout(()=>{if(mode==='error'){set({phase:'error',message:'Scaricamento non riuscito. Controlla la connessione e riprova.'});return}set({phase:'verifying',progress:100,message:'Verifico l’aggiornamento SGP…'});setTimeout(()=>{set({phase:'installing',message:'Installazione in corso. SGP potrebbe chiudersi: riaprila al termine.'});setTimeout(()=>set({phase:'success',message:'Simulazione completata: nessun file è stato installato.'}),2500)},1500)},7000);
  return state;
 }};
}
function Preview(){const[mode,setMode]=useState('direct'),[open,setOpen]=useState(true),[key,setKey]=useState(0);const installer=useMemo(()=>demo(mode),[mode,key]);return <main style={{padding:30}}><h1>Anteprima · Aggiornamento diretto</h1><p>Simulazione grafica: nessuna installazione reale.</p><label>Scenario <select value={mode} onChange={e=>setMode(e.target.value)}><option value="direct">Aggiornamento diretto</option><option value="permission">Prima autorizzazione</option><option value="error">Errore di connessione</option></select></label><button onClick={()=>{setKey(key+1);setOpen(true)}}>Mostra aggiornamento</button>{open&&<UpdateDialog key={key} update={{version:'1.25',apk:'https://sdsfilm1.github.io/sgp-gestionale/SGP-Gestionale-Android-1.25.apk',sha256:'a'.repeat(64)}} installer={installer} onLater={()=>setOpen(false)}/>}</main>};
createRoot(document.getElementById('root')!).render(<Preview/>);
