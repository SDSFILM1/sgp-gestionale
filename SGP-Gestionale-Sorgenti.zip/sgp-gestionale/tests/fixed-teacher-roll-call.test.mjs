import{test}from'node:test';import assert from'node:assert/strict';import{readFile}from'node:fs/promises';import{PGlite}from'@electric-sql/pglite';
const read=n=>readFile(new URL('../supabase/migrations/'+n,import.meta.url),'utf8');
test('Fixed teachers can open and save existing course lessons without rewriting historic teachers or granting other courses',async()=>{
 const db=new PGlite();try{
 await db.exec(`create role anon;create role authenticated;create role service_role;create schema auth;create table auth.users(id uuid primary key);create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;grant usage on schema auth to authenticated;`);
 for(const n of['202609180001_initial.sql','202609220005_jotform.sql','202609180002_wix.sql','202609270001_deduplicate_intake.sql'])await db.exec(await read(n));
 const excel=await read('202609270002_merge_excel_duplicates.sql');await db.exec(excel.slice(excel.indexOf('create or replace function public.student_name_key'),excel.indexOf('do $$')));await db.exec(excel.slice(excel.indexOf('create or replace function public.import_excel_student'),excel.indexOf('revoke all on function public.student_name_key')));
 for(const n of['202610040001_trial_students.sql','202610040001_course_fixed_teachers.sql','202610040002_staff_trial_import.sql','202610040004_fast_dataset.sql','202610110001_hide_enrolled_trial_reminders.sql','202610110002_wix_people.sql','202610150002_roll_call_editors.sql','202610150003_extra_substitutes.sql','202610150004_substitute_trial_counts.sql'])await db.exec(await read(n));
 const g=await read('202610040006_gpt_access.sql'),start=g.indexOf('create function public.sgp_gpt_name_key');await db.exec(g.slice(start,g.indexOf('create function public.sgp_gpt_classify',start)));
 for(const n of['202610270001_booking_packages.sql','202610270002_fast_package_snapshot.sql'])await db.exec(await read(n));
 const admin='00000000-0000-4000-8000-000000000001',fixed='00000000-0000-4000-8000-000000000002',old='00000000-0000-4000-8000-000000000003',sub='00000000-0000-4000-8000-000000000004';
 for(const[id,role]of[[admin,'secretary'],[fixed,'teacher'],[old,'teacher'],[sub,'teacher']]){await db.query('insert into auth.users values($1)',[id]);await db.query("insert into profiles(id,name,email,role,must_change_password) values($1,$2,'fixture@example.invalid',$3,false)",[id,'Staff '+id.slice(-1),role])}
 const course=(await db.query("insert into courses(name) values('Corso fisso') returning id")).rows[0].id;
 const foreign=(await db.query("insert into courses(name) values('Altro corso') returning id")).rows[0].id;
 const past=(await db.query("insert into lessons(course_id,starts_at,ends_at) values($1,(now() at time zone 'Europe/Rome')::date::timestamp at time zone 'Europe/Rome',((now() at time zone 'Europe/Rome')::date::timestamp at time zone 'Europe/Rome')+interval '1 second') returning id",[course])).rows[0].id;
 const previousDay=(await db.query("insert into lessons(course_id,starts_at,ends_at) values($1,now()-interval '2 days',now()-interval '1 day') returning id",[course])).rows[0].id;
 const future=(await db.query("insert into lessons(course_id,starts_at,ends_at) values($1,now()+interval '1 day',now()+interval '25 hours') returning id",[course])).rows[0].id;
 const unrelated=(await db.query("insert into lessons(course_id,starts_at,ends_at) values($1,now()+interval '1 day',now()+interval '25 hours') returning id",[foreign])).rows[0].id;
 const pupil=(await db.query("insert into students(name,birth_date,notes) values('Atleta esempio','2014-01-01','Nota privata') returning id")).rows[0].id;
 const outsider=(await db.query("insert into students(name) values('Altra persona') returning id")).rows[0].id;
 await db.query('insert into enrollments(course_id,student_id,valid_from) values($1,$2,current_date-7),($3,$4,current_date-7)',[course,pupil,foreign,outsider]);
 await db.query('insert into course_teachers(course_id,teacher_id) values($1,$2)',[course,fixed]);
 await db.query("insert into lesson_teachers(lesson_id,teacher_id,status,note) values($1,$2,'present','Storico insegnante')",[past,old]);
 await db.query("insert into lesson_participants(lesson_id,student_id,name,source,status) values($1,$2,'Atleta esempio','fixed','present')",[past,pupil]);
 const participant=(await db.query('select id from lesson_participants where lesson_id=$1',[past])).rows[0].id;
 const history=(await db.query('select * from lesson_teachers order by lesson_id,teacher_id')).rows;
 const login=async id=>{await db.exec('reset role');await db.query("select set_config('request.jwt.claim.sub',$1,false)",[id]);await db.exec('set role authenticated')};
 const dataset=async()=>(await db.query('select staff_dataset() d')).rows[0].d;
 await login(fixed);assert.equal((await db.query('select can_course($1) b',[course])).rows[0].b,true);
 assert.equal((await db.query('select can_lesson($1) b',[past])).rows[0].b,false,'reproduce fixed-course teacher denied an existing lesson');
 assert.equal((await dataset()).lessons.length,0);
 const previousRevision=(await db.query('select staff_dataset_refresh(null) d')).rows[0].d.revision;
 await db.exec('reset role');await db.exec(await read('202610290001_fixed_teacher_roll_call.sql'));
 await login(fixed);const data=await dataset();
 const refreshed=(await db.query('select staff_dataset_refresh($1) d',[previousRevision])).rows[0].d;
 assert.equal(refreshed.unchanged,undefined);assert.notEqual(refreshed.revision,previousRevision,'existing clients receive the newly authorized lessons on refresh');
 assert.deepEqual(new Set(data.lessons.map(l=>l.id)),new Set([past,future]));
 assert.equal((await db.query('select can_lesson($1) b',[previousDay])).rows[0].b,false,'a new fixed assignment does not expose older lessons');
 assert.deepEqual(data.students.map(s=>s.id),[pupil]);assert.equal(data.students[0].birth_date,null);assert.equal(data.students[0].notes,'');
 assert.equal(data.participants.find(p=>p.id===participant).status,'present','migration preserves attendance');
 assert.equal((await db.query('select can_lesson($1) b',[unrelated])).rows[0].b,false);
 const calendar=(await db.query('select * from substitute_calendar(current_date-2,current_date+2)')).rows;
 assert.equal(calendar.find(l=>l.id===past).is_assigned,true,'existing UI opens the roll call without a late substitute registration');
 await db.query('select save_roll_call($1,$2::jsonb)',[past,JSON.stringify([{id:participant,expected:'present',status:'absent'}])]);
 assert.equal((await dataset()).participants.find(p=>p.id===participant).status,'absent');
 assert.equal((await db.query('select * from staff_roll_call_editors()')).rows[0].actor_id,fixed);
 await assert.rejects(()=>db.query("select save_roll_call($1,'[]')",[unrelated]),/Accesso/);
 await login(sub);assert.equal((await dataset()).lessons.length,0);await db.query('select set_extra_substitute($1,true)',[future]);
 assert.deepEqual((await dataset()).lessons.map(l=>l.id),[future]);assert.equal((await db.query('select can_lesson($1) b',[past])).rows[0].b,false,'substitute remains limited to one lesson');
 await login(old);assert.deepEqual((await dataset()).lessons.map(l=>l.id),[past]);
 await db.exec('reset role');assert.deepEqual((await db.query('select * from lesson_teachers order by lesson_id,teacher_id')).rows,history,'no historical teacher rows are added or rewritten');
 await db.query('delete from course_teachers where course_id=$1 and teacher_id=$2',[course,fixed]);await login(fixed);
 assert.equal((await dataset()).lessons.length,0);assert.equal((await db.query('select can_lesson($1) b',[past])).rows[0].b,false);
 await db.exec('reset role');await db.query('insert into course_teachers values($1,$2)',[course,fixed]);await db.query('update profiles set active=false where id=$1',[fixed]);await login(fixed);
 assert.equal((await db.query('select can_lesson($1) b',[past])).rows[0].b,false);await assert.rejects(()=>dataset(),/Accesso/);
 await db.exec('set role anon');await assert.rejects(()=>db.query('select substitute_calendar(current_date,current_date+7)'),/permission denied/);
 await login(admin);assert.equal((await dataset()).lessons.length,4);
 // A different, non-fixed teacher must be able to register after today's class.
 await db.exec('reset role');
 const ended=(await db.query("insert into lessons(course_id,starts_at,ends_at) values($1,((now() at time zone 'Europe/Rome')::date::timestamp at time zone 'Europe/Rome')-interval '1 hour',(now() at time zone 'Europe/Rome')::date::timestamp at time zone 'Europe/Rome') returning id",[foreign])).rows[0].id;
 const older=(await db.query("insert into lessons(course_id,starts_at,ends_at) values($1,now()-interval '3 days',now()-interval '2 days') returning id",[foreign])).rows[0].id;
 const cancelled=(await db.query("insert into lessons(course_id,starts_at,ends_at,cancelled) values($1,now(),now()+interval '1 hour',true) returning id",[foreign])).rows[0].id;
 await db.query("insert into lesson_participants(lesson_id,student_id,name,source) values($1,$2,'Altra persona','fixed')",[ended,outsider]);
 const lateParticipant=(await db.query('select id from lesson_participants where lesson_id=$1',[ended])).rows[0].id;
 await login(sub);await assert.rejects(()=>db.query('select set_extra_substitute($1,true)',[ended]),/terminata/,'reproduce the after-class failure');
 await db.exec('reset role');await db.exec(await read('202610290002_same_day_substitute.sql'));await login(sub);
 await db.query('select set_extra_substitute($1,true)',[ended]);
 assert.equal((await db.query('select can_lesson($1) b',[ended])).rows[0].b,true);
 assert.equal((await db.query('select can_lesson($1) b',[unrelated])).rows[0].b,false,'same-day registration still grants only the chosen lesson');
 await db.query('select save_roll_call($1,$2::jsonb)',[ended,JSON.stringify([{id:lateParticipant,expected:'unmarked',status:'present'}])]);
 assert.equal((await dataset()).participants.find(p=>p.id===lateParticipant).status,'present');
 await assert.rejects(()=>db.query('select set_extra_substitute($1,true)',[older]),/giorni precedenti/);
 await assert.rejects(()=>db.query('select set_extra_substitute($1,true)',[cancelled]),/annullata/);
 await db.query('select set_extra_substitute($1,false)',[ended]);assert.equal((await db.query('select can_lesson($1) b',[ended])).rows[0].b,false);
 await login(admin);assert.equal((await dataset()).participants.find(p=>p.id===lateParticipant).status,'present','withdrawal preserves the saved roll call');
 // Package-query optimization must preserve the exact dataset and role boundaries.
 await db.exec('reset role');await db.query('update profiles set active=true where id=$1',[fixed]);
 const beforeTuning=new Map();
 for(const user of [admin,fixed,sub]){await login(user);beforeTuning.set(user,await dataset())}
 await db.exec('reset role');await db.exec(await read('202611020001_teacher_dataset_timeout.sql'));
 for(const user of [admin,fixed,sub]){await login(user);assert.deepEqual(await dataset(),beforeTuning.get(user),'optimization must not alter scoped data')}
 await db.exec('set role anon');await assert.rejects(()=>dataset(),/permission denied/);
 }finally{await db.close()}
});
