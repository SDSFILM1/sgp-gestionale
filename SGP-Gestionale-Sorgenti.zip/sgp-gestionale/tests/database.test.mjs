import {test} from 'node:test';import assert from 'node:assert/strict';import{readFile}from'node:fs/promises';import{PGlite}from'@electric-sql/pglite';
test('RLS, storico, cambi elenco e permessi insegnanti',async()=>{
 const db=new PGlite();await db.exec(`create role anon;create role authenticated;create role service_role;create schema auth;create table auth.users(id uuid primary key);create function auth.uid() returns uuid language sql stable as $$ select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid $$;grant usage on schema auth to authenticated;`);
 await db.exec(await readFile(new URL('../supabase/migrations/202609180001_initial.sql',import.meta.url),'utf8'));
 await db.exec(await readFile(new URL('../supabase/migrations/202609210004_attendance.sql',import.meta.url),'utf8'));
 const admin='00000000-0000-0000-0000-000000000001',teacher='00000000-0000-0000-0000-000000000002',other='00000000-0000-0000-0000-000000000003';
 for(const [id,name,role] of [[admin,'Segreteria test','secretary'],[teacher,'Insegnante test','teacher'],[other,'Altro test','teacher']]){await db.query(`insert into auth.users values($1)`,[id]);await db.query(`insert into public.profiles(id,name,email,role,must_change_password)values($1,$2,'test@example.invalid',$3,false)`,[id,name,role]);}
 await db.query(`select set_config('request.jwt.claim.sub',$1,false)`,[admin]);await db.exec('set role authenticated');
 const course=(await db.query(`select public.save_course('Corso test','ragazzi','Palestra') id`)).rows[0].id;
 const a=(await db.query(`select public.save_student('Alunno A') id`)).rows[0].id,b=(await db.query(`select public.save_student('Alunno B') id`)).rows[0].id;
 const days=(await db.query(`select (current_date-7)::text past,(current_date+7)::text next,(current_date+14)::text later`)).rows[0];
 await db.query(`select public.set_roster($1,current_date,array[$2::uuid])`,[course,a]);
 await db.query(`select public.create_lessons($1,$2,$3,'16:00','17:00',array[$4::uuid])`,[course,days.next,days.later,teacher]);
 // Add a past lesson then a single-lesson membership: must survive every future roster edit.
 await db.query(`select public.create_lessons($1,$2,$2,'16:00','17:00',array[$3::uuid],false)`,[course,days.past,teacher]);
 const lessons=(await db.query('select * from public.lessons order by starts_at')).rows;
 await db.query('select public.lesson_override($1,$2,false)',[lessons[0].id,a]);
 const pastParticipant=(await db.query('select * from public.lesson_participants where lesson_id=$1',[lessons[0].id])).rows[0];
 await db.query(`select public.set_attendance($1,'present')`,[pastParticipant.id]);
 await db.query(`select public.set_roster($1,$2,array[$3::uuid])`,[course,days.later,b]);
 assert.equal((await db.query('select name,status from public.lesson_participants where id=$1',[pastParticipant.id])).rows[0].status,'present');
 assert.equal((await db.query('select name from public.lesson_participants where lesson_id=$1',[lessons[1].id])).rows[0].name,'Alunno A');
 assert.equal((await db.query('select name from public.lesson_participants where lesson_id=$1',[lessons[2].id])).rows[0].name,'Alunno B');
 await db.query(`select public.save_student('Alunno A rinominato','',$1)`,[a]);assert.equal((await db.query('select name from public.lesson_participants where id=$1',[pastParticipant.id])).rows[0].name,'Alunno A');
 await db.query(`select set_config('request.jwt.claim.sub',$1,false)`,[teacher]);
 assert.equal((await db.query('select * from public.lessons')).rows.length,3);
 await db.query(`select public.set_attendance($1,'absent')`,[pastParticipant.id]);
 await assert.rejects(()=>db.query(`select public.set_roster($1,current_date,array[$2::uuid])`,[course,a]));
 await assert.rejects(()=>db.query(`update public.profiles set role='secretary' where id=$1`,[teacher]));
 await assert.rejects(()=>db.query(`update public.lesson_participants set name='Alterato' where id=$1`,[pastParticipant.id]));
 await assert.rejects(()=>db.query(`select public.refresh_roster($1,current_date)`,[course]));
 // Batch roll call preserves historical rows and checks each expected state atomically.
 const nextRows=(await db.query('select * from public.lesson_participants where lesson_id=$1',[lessons[1].id])).rows;
 const next=nextRows[0];
 await db.query('select public.save_roll_call($1,$2::jsonb)',[lessons[1].id,JSON.stringify([{id:next.id,expected:'unmarked',status:'present'}])]);
 assert.equal((await db.query('select status from public.lesson_participants where id=$1',[next.id])).rows[0].status,'present');
 await assert.rejects(()=>db.query('select public.save_roll_call($1,$2::jsonb)',[lessons[1].id,JSON.stringify([{id:next.id,expected:'unmarked',status:'absent'}])]),/altro utente/);
 await assert.rejects(()=>db.query('select public.save_roll_call($1,$2::jsonb)',[lessons[1].id,JSON.stringify([{id:next.id,expected:'present',status:'absent'},{id:pastParticipant.id,expected:'absent',status:'present'}])]),/Elenco cambiato/);
 assert.equal((await db.query('select status from public.lesson_participants where id=$1',[next.id])).rows[0].status,'present');
 assert.equal((await db.query('select status from public.lesson_participants where id=$1',[pastParticipant.id])).rows[0].status,'absent');
 await db.query(`select set_config('request.jwt.claim.sub',$1,false)`,[other]);
 await assert.rejects(()=>db.query('select public.save_roll_call($1,$2::jsonb)',[lessons[1].id,JSON.stringify([{id:next.id,expected:'present',status:'absent'}])]),/Accesso negato/);
 assert.equal((await db.query('select * from public.lessons')).rows.length,0);
 assert.equal((await db.query('select * from public.lesson_participants')).rows.length,0);
 await assert.rejects(()=>db.query(`select public.set_attendance($1,'present')`,[pastParticipant.id]));
 await db.exec('reset role');await db.query('update public.profiles set active=false where id=$1',[teacher]);await db.query(`select set_config('request.jwt.claim.sub',$1,false)`,[teacher]);await db.exec('set role authenticated');
 assert.equal((await db.query('select * from public.lessons')).rows.length,0);
 await db.close();
});
