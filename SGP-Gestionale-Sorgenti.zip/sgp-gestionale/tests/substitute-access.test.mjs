import{test}from'node:test';import assert from'node:assert/strict';import{readFile}from'node:fs/promises';import{runInNewContext}from'node:vm';import ts from'typescript';
const source=await readFile(new URL('../src/substituteAccess.ts',import.meta.url),'utf8');const context={exports:{},Intl,Date};runInNewContext(ts.transpileModule(source,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText,context);const{canRegisterSubstitute}=context.exports;
test('After-class access lasts until midnight in Rome, including daylight saving time',()=>{
 const slot={ends_at:'2026-10-29T17:00:00Z',cancelled:false};
 assert.equal(canRegisterSubstitute(slot,new Date('2026-10-29T20:00:00Z')),true,'Acro-power can be opened after 18:00');
 assert.equal(canRegisterSubstitute(slot,new Date('2026-10-29T22:59:59Z')),true);
 assert.equal(canRegisterSubstitute(slot,new Date('2026-10-29T23:00:00Z')),false);
 assert.equal(canRegisterSubstitute({ends_at:'2026-06-01T22:05:00Z',cancelled:false},new Date('2026-06-01T22:15:00Z')),true);
 assert.equal(canRegisterSubstitute({ends_at:'2026-06-01T21:50:00Z',cancelled:false},new Date('2026-06-01T22:15:00Z')),false);
 assert.equal(canRegisterSubstitute(slot,new Date('2026-10-28T20:00:00Z')),true,'future lessons remain available');
 assert.equal(canRegisterSubstitute({...slot,cancelled:true},new Date('2026-10-29T20:00:00Z')),false);
 assert.equal(canRegisterSubstitute({ends_at:'invalid',cancelled:false}),false);
});
