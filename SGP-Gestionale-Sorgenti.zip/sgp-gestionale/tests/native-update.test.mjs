import{test}from'node:test';import assert from'node:assert/strict';import{readFile}from'node:fs/promises';import{runInNewContext}from'node:vm';import ts from'typescript';
const text=await readFile(new URL('../src/nativeUpdate.ts',import.meta.url),'utf8');
const code=ts.transpileModule(text,{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
const context={exports:{},URL,require:name=>{assert.equal(name,'@capacitor/core');return{registerPlugin:()=>({}),Capacitor:{getPlatform:()=> 'web'}}}};runInNewContext(code,context);
const{parseAppUpdate,isNewerVersion}=context.exports;
const valid={version:'1.25',apk:'./SGP-Gestionale-Android-1.25.apk',sha256:'a'.repeat(64)};
test('Update manifest accepts existing releases and verified releases, and never remote or credential-bearing files',()=>{
 assert.equal(parseAppUpdate(valid).apk,'https://sdsfilm1.github.io/sgp-gestionale/SGP-Gestionale-Android-1.25.apk');
 assert.equal(parseAppUpdate({version:'1.23',apk:'./SGP-Gestionale-Android-1.23.apk'}).version,'1.23');
 for(const apk of['https://evil.example/update.apk','javascript:alert(1)','file:///data/file.apk','https://user@sdsfilm1.github.io/sgp-gestionale/SGP-Gestionale-Android-1.25.apk','./SGP-Gestionale-Android-1.25.apk?token=x','./SGP-Gestionale-Android-1.25.apk#fragment','../other.apk'])assert.equal(parseAppUpdate({...valid,apk}),null);
 for(const sha256 of['short',false,'g'.repeat(64),null])assert.equal(parseAppUpdate({...valid,sha256}),null);
 for(const value of[null,{},[],{...valid,version:'newest'}])assert.equal(parseAppUpdate(value),null);
});
test('Version ordering never offers a downgrade or repeats the current release',()=>{
 assert.equal(isNewerVersion('1.25','1.24'),true);assert.equal(isNewerVersion('1.24','1.25'),false);assert.equal(isNewerVersion('1.24','1.24.0'),false);assert.equal(isNewerVersion('1.10','1.9'),true);
});
